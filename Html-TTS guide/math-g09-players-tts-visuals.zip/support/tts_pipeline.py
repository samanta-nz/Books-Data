#!/usr/bin/env python3
"""Generate, transcode and embed authored math-lesson audio. Python 3.10+, ffmpeg + ffprobe.
No network request without --generate. Never place API credentials in an HTML or Markdown file.
"""
import argparse,base64,hashlib,json,os,re,subprocess,time,urllib.request
from pathlib import Path
from html.parser import HTMLParser

class TranscriptParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True);self.current=None;self.capture=False;self.buffer=[];self.transcripts={};self.audio_counts={};self.block_ids=[]
    def handle_starttag(self,tag,attrs):
        attr=dict(attrs)
        if tag=='div' and attr.get('data-audio-id'):
            self.current=attr['data-audio-id'];self.block_ids.append(self.current)
        if tag=='audio' and self.current:
            self.audio_counts[self.current]=self.audio_counts.get(self.current,0)+1
        if tag=='p' and 'tts-text' in attr.get('class','').split():
            if self.current in self.transcripts:raise SystemExit('Duplicate transcript slot: '+str(self.current))
            self.capture=True;self.buffer=[]
    def handle_data(self,data):
        if self.capture:self.buffer.append(data)
    def handle_endtag(self,tag):
        if tag=='p' and self.capture:
            self.transcripts[self.current]=''.join(self.buffer);self.capture=False

def manifest_from(source):
    match=re.search(r'<script id="tts-manifest" type="application/json">(.*?)</script>',source,re.S)
    if not match:raise SystemExit('Missing tts-manifest')
    data=json.loads(match[1])
    if data['schema']!='math-lesson-tts-v1':raise SystemExit('Unsupported manifest schema')
    parser=TranscriptParser();parser.feed(source)
    seen=set()
    for clip in data['clips']:
        if not re.fullmatch(r'M[A-Za-z0-9_-]{1,90}',clip['id']) or clip['id'] in seen:raise SystemExit('Invalid/duplicate audio ID')
        seen.add(clip['id'])
        if clip['file']!=clip['id']+'.weba':raise SystemExit('Invalid audio filename: '+clip['id'])
        if hashlib.sha256(clip['text'].encode()).hexdigest()!=clip['text_sha256']:raise SystemExit('Changed transcript: '+clip['id'])
        if parser.transcripts.get(clip['id'])!=clip['text']:raise SystemExit('HTML speech text differs from manifest: '+clip['id'])
    if len(parser.transcripts)!=len(seen):raise SystemExit('Unlisted or missing transcript slots')
    if len(parser.block_ids)!=len(seen) or set(parser.block_ids)!=seen:raise SystemExit('Unlisted or duplicate audio blocks')
    if any(parser.audio_counts.get(id)!=1 for id in seen):raise SystemExit('Each audio block must contain exactly one audio element')
    return data

def probe(path):
    result=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,channels,sample_rate:format=duration,format_name','-of','json',str(path)],check=True,capture_output=True,text=True)
    info=json.loads(result.stdout); streams=info.get('streams',[])
    if len(streams)!=1 or streams[0]['codec_name']!='opus' or streams[0]['channels']!=1:raise SystemExit('Expected one mono Opus stream: '+str(path))
    if str(streams[0].get('sample_rate'))!='48000':raise SystemExit('Expected 48 kHz audio: '+str(path))
    if 'webm' not in info['format'].get('format_name','').split(','):raise SystemExit('Expected a WebM container: '+str(path))
    if float(info['format'].get('duration',0))<=0:raise SystemExit('Empty audio: '+str(path))
    if path.read_bytes()[:4]!=b'\x1aE\xdf\xa3':raise SystemExit('Not a WebM container: '+str(path))
    return float(info['format']['duration'])

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('html',type=Path)
    ap.add_argument('--audio-dir',type=Path,default=None)
    ap.add_argument('--generate',action='store_true',help='Paid API requests; requires OPENAI_API_KEY')
    ap.add_argument('--embed',action='store_true',help='Offline: validate every audio file and embed Base64')
    ap.add_argument('--output',type=Path)
    ap.add_argument('--only',help='Comma-separated IDs for a small generation preview; embedding always requires all clips')
    ap.add_argument('--accept-imports',action='store_true',help='Bind externally generated audio to current text; only after manual transcript QA')
    args=ap.parse_args()
    source=args.html.read_text(encoding='utf-8');data=manifest_from(source)
    if args.audio_dir is None:args.audio_dir=Path(data.get('audio_folder','audio-math'))
    if not(args.generate or args.embed):
        print(json.dumps({'clips':len(data['clips']),'transcript_characters':sum(len(c['text']) for c in data['clips']),'network_requests':0},ensure_ascii=False,indent=2));return
    args.audio_dir.mkdir(parents=True,exist_ok=True)
    selected=set(args.only.split(',')) if args.only else None
    if selected and not selected <= {c['id'] for c in data['clips']}:raise SystemExit('Unknown ID in --only')
    for clip in data['clips']:
        if not args.generate or selected and clip['id'] not in selected:continue
        dest=args.audio_dir/clip['file'];meta=dest.with_suffix('.json')
        if dest.exists():
            if meta.exists() and json.loads(meta.read_text())['text_sha256']==clip['text_sha256']:
                record=json.loads(meta.read_text())
                if record.get('audio_sha256')!=hashlib.sha256(dest.read_bytes()).hexdigest():raise SystemExit('Existing audio file was modified: '+str(dest))
                probe(dest);continue
            raise SystemExit('Existing audio is not bound to this transcript; inspect it first: '+str(dest))
        key=os.environ.get('OPENAI_API_KEY')
        if not key:raise SystemExit('Set OPENAI_API_KEY in the shell; do not store it in the lesson')
        lang='Persian as spoken in Iran' if clip['lang']=='fa' else 'clear General American English'
        instructions=(data['synthesis_instructions']+' Language: '+lang+'. Speaker role: '+clip['speaker']+'. '+clip.get('delivery',''))
        body=json.dumps(dict(model=data['model'],voice=clip['voice'],input=clip['text'],instructions=instructions,response_format='mp3',speed=1.0)).encode()
        req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=body,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        raw=args.audio_dir/(clip['id']+'.source.mp3')
        with urllib.request.urlopen(req,timeout=180) as response:raw.write_bytes(response.read())
        temp=args.audio_dir/(clip['id']+'.tmp.weba')
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-vn','-map_metadata','-1','-af','loudnorm=I=-18:TP=-2:LRA=7','-ar','48000','-ac','1','-c:a','libopus','-b:a','40k','-vbr','on','-application','voip','-f','webm',str(temp)],check=True)
        duration=probe(temp);temp.replace(dest)
        meta.write_text(json.dumps(dict(id=clip['id'],text_sha256=clip['text_sha256'],audio_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),duration=duration,model=data['model'],voice=clip['voice'],qa='pending human listening'),ensure_ascii=False,indent=2),encoding='utf-8')
        print('Generated',clip['id'],round(duration,2),'seconds')
    if not args.embed:return
    if not args.output:raise SystemExit('--embed requires --output')
    if args.output.resolve()==args.html.resolve():raise SystemExit('Choose a new output path; preserve the authored source')
    uris={};total=0
    for clip in data['clips']:
        dest=args.audio_dir/clip['file'];meta=dest.with_suffix('.json')
        if not dest.exists():raise SystemExit('Missing clip: '+str(dest))
        duration=probe(dest);blob=dest.read_bytes();audio_hash=hashlib.sha256(blob).hexdigest()
        if not meta.exists():
            if not args.accept_imports:raise SystemExit('Missing provenance JSON; use --accept-imports only after exact-text QA: '+str(meta))
            meta.write_text(json.dumps(dict(id=clip['id'],text_sha256=clip['text_sha256'],audio_sha256=audio_hash,duration=duration,qa='manually imported by operator'),indent=2),encoding='utf-8')
        record=json.loads(meta.read_text())
        if record['text_sha256']!=clip['text_sha256'] or record['audio_sha256']!=audio_hash:raise SystemExit('Stale or modified clip: '+clip['id'])
        uris[clip['id']]='data:audio/webm;codecs=opus;base64,'+base64.b64encode(blob).decode();total+=len(blob)
    for id,uri in uris.items():
        pattern=r'(<div class="dialogue [^"]*audio-block" data-audio-id="'+re.escape(id)+r'"[\s\S]*?<audio\b)([^>]*)(>)'
        matches=list(re.finditer(pattern,source))
        if len(matches)!=1:raise SystemExit('Audio slot count is not one for '+id)
        def replace(m):
            attrs=re.sub(r'\s+src="[^"]*"','',m[2]);return m[1]+attrs+' src="'+uri+'"'+m[3]
        source=re.sub(pattern,replace,source,count=1)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    temporary=args.output.with_suffix(args.output.suffix+'.tmp')
    temporary.write_text(source,encoding='utf-8')
    temporary.replace(args.output)
    print('Embedded',len(uris),'clips;',round(total/1024/1024,2),'MiB audio;',round(args.output.stat().st_size/1024/1024,2),'MiB HTML')

if __name__=='__main__':main()

نسخهٔ دوم · 176 قطعهٔ صوتی · 18 بخش آموزشی · نام مدرس: آرتین؛ یادگیرنده: رها

# راهنمای تولید صوت و تزریق درس ۱ Personality

این سند متن صوت‌ها را از پیش دارد؛ ایجنت حق تألیف مجدد، خلاصه کردن، افزودن تشویق یا بازنویسی آن را ندارد. فایل HTML، منبع قطعی متن است. همهٔ قطعات زیر دقیقاً با متن داخل p.tts-text همان شناسه تطبیق دارند. تمام کادرهای راهنما، پاسخ‌های بازشونده و نکات تلفظی متن و آیکون صوت مستقل دارند. جدول‌های اصلی، رابط، پرسش‌های آزمون و پاسخ‌های پویا الزاماً روایت جدا ندارند؛ توضیح آموزشی آن‌ها در قطعات تدریس آمده است. TTS فقط قطعات مشخص‌شده را می‌خواند.

## خروجی مورد انتظار
برای هر L01-NNN دقیقاً یک فایل L01-NNN.weba و JSON منشأ بساز. هر فایل صوتی یک زبان و یک گوینده دارد؛ نوبت‌های گفت‌وگو را با هم ترکیب نکن. در پایان فایل جدید engl9-l01-personality-with-audio.html باید تمام صوت‌ها را با Base64 در پلیرهای همان شناسه داشته باشد. CSS، تصاویر، تمرین‌ها و متن آموزشی را عوض نکن. فایل مستقل است و به مسیر محلی صوت یا iframe نیاز ندارد.

## پرامپت اصلی TTS
Speak only the exact input text. Add no greeting, explanation, translation, speaker label, music, or filler. Use fluent standard Iranian Persian for fa and clear General American English for en. Read English terms inside Persian naturally and accurately. Keep the voices fixed across turns. Render dialogue as dialogue, not a narrated list. Use a moderate teaching pace, with short natural pauses at punctuation. Declarative English statements generally finish with a gentle falling contour; questions follow meaning. Read contractions naturally. Never expand or rewrite the text. Do not speak IDs, IPA metadata, arrows, or file names.

## صداها و دیالوگ

- teacher: آرتین، voice=sage؛ Teacher نیز sage است.
- student: رها، voice=coral.
- Samira و Mina: coral؛ در هر موقعیت نقش‌ها جدا هستند.
- Ehsan: echo؛ Parham: onyx؛ Sara: nova.
نام voice وابسته به سرویس است. اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود؛ زبان و هویت هر نقش در کل درس تغییر نکند. صدای ساختگیِ کودک یا تقلید فرد واقعی لازم نیست؛ صدای روشن و طبیعی کافی است. تلفظ فارسی و انگلیسیِ خروجی به بازبینی انسانی نیاز دارد.

## قالب و حجم صوت
WebA یعنی فایل WebM فقط صوتی با codec=Opus، نه تغییر پسوند MP3. تنظیم مرجع: تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s، application=voip؛ این نرخ برای تدریس و دیالوگ روشن مناسب است. loudness هدف تقریباً -18 LUFS و true peak حداکثر -2 dBTP؛ در اسکریپت loudnorm تک‌مرحله‌ای استفاده شده و مقدار نهایی باید شنیده و اندازه‌گیری شود. خام MP3 را برای بازبینی نگه دار؛ نسخهٔ قابل توزیع WebA است. Base64 حجم باینری صوت را تقریباً یک‌سوم بیشتر می‌کند. نرخ را پیش از شنیدن نمونه به حد نامفهوم پایین نیاور.

## اجرای پیشنهادی
نیازمند Python 3.10 یا جدیدتر، ffmpeg و ffprobe با libopus. راهنما، manifest و اسکریپت کنار HTML تحویل می‌شوند؛ هیچ بخش تولید صوت یا راهنمای مدرس داخل HTML دانش‌آموز وجود ندارد.

```bash
# فقط خواندن manifest و شمار قطعات؛ بدون شبکه و هزینه
python tts_pipeline.py engl9-l01-personality.html

# کلید را در محیط اجرا تنظیم کن؛ آن را داخل HTML یا Markdown ننویس.
# ابتدا پنج نمونه برای بررسی فارسی، انگلیسی و دو نقش گفت‌وگو:
python tts_pipeline.py engl9-l01-personality.html --generate --only L01-001,L01-002,L01-048,L01-049,L01-062 --audio-dir audio-l01

# بعد از شنیدن نمونه‌ها، تمام قطعات باقی‌مانده را بساز:
python tts_pipeline.py engl9-l01-personality.html --generate --audio-dir audio-l01

# پس از QA صوت‌ها، تزریق آفلاین در فایل تازه:
python tts_pipeline.py engl9-l01-personality.html --embed --audio-dir audio-l01 --output engl9-l01-personality-with-audio.html
```

--generate درخواست هزینه‌دار به سرویس می‌فرستد و به OPENAI_API_KEY نیاز دارد. --embed هیچ درخواست شبکه‌ای ندارد. نام مدل در manifest قابل تنظیم برای سرویس موجود است؛ پیش از اجرای کامل دسترسی سرویس و پشتیبانی زبان را با نمونه بررسی کن. در این تحویل هیچ صوت نهایی تولید نشده است.

### اگر ایجنت دیگری صوت خام را تولید کرد
برای هر قطعه متن دقیق زیر را به سرویس منتخب بده؛ نام فایل و نقش را حفظ کن. سپس آن را با دستور زیر واقعاً به Opus تبدیل کن:

```bash
ffmpeg -i L01-001.source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L01-001.weba
```

از script با --embed --accept-imports فقط پس از شنیدن و تطبیق دقیق همهٔ قطعات وارداتی استفاده کن؛ این گزینه گواه منشأ متن برای قطعات خارجی می‌سازد و تطبیق شنیداری خودکار نیست. یک بار ساخته شدن JSON به معنی تأیید تلفظ نیست.

## تزریق فنی
۱. manifest با id=tts-manifest را بخوان. hash متن UTF-8 را با text_sha256 مقایسه کن.
۲. دقیقاً یک audio-block با data-audio-id برابر همان ID باید وجود داشته باشد. audio داخل آن جای تزریق است.
۳. پس از کنترل WebM/Opus تک‌کاناله با ffprobe، ویژگی src را data:audio/webm;codecs=opus;base64,... قرار بده. اسکریپت تعداد slotها، hash متن و hash فایل صوت و وجود همهٔ قطعات را بررسی می‌کند.
۴. صوت غلط، ناقص یا متن تغییرکرده را تزریق نکن. اسکریپت در این حالت خطا می‌دهد و فایل خروجی نهایی نمی‌نویسد.
۵. بخش شنیداری A باید نوبت‌ها را پشت‌سرهم بدون باز کردن متن اجرا کند. B یک قطعهٔ مستقل است. هر پلیر هم جداگانه قابل کنترل است.
۶. تزریق فقط با اسکریپت خارجی انجام شود؛ پنل مونتاژ یا بارگذاری صوت داخل HTML دانش‌آموز وجود ندارد. دکمهٔ هر قسمت فقط audio امبد همان data-audio-id را پخش یا متوقف می‌کند؛ خوانش آزمایشی دستگاه حذف شده است.

## حفظ رابط نسخهٔ دوم
رابط HTML فقط برای دانش‌آموز است؛ بخش مدرس، تولید صوت، خوانش دستگاه و چاپ را به آن برنگردان. نام راهنما آرتین و نام یادگیرنده رها است. تمام بخش‌های اصلی در منبع بسته‌اند؛ در اجرا حداکثر یک بخش باز و آخرین انتخاب در حافظه نگه داشته می‌شود. تزریق صوت نباید این رفتار یا منوی تمام‌صفحهٔ وب‌ویو را عوض کند.

هر آیکونِ داخل audio-block فقط صوت امبد همان شناسه را پخش/مکث می‌کند. کادرهای کمکی و پاسخ‌ها نیز آیکون‌های خود را دارند؛ برای آزمودن آن‌ها اول بخش اصلی و سپس همان کادر را باز کن. توضیح‌ها و مدل‌های انگلیسی در بخش pronunciation-tips نیز باید جداگانه پخش شوند. ترتیب تدریس، ترتیب clips در manifest و همین Markdown است؛ شناسه‌ها را عددی مرتب یا دوباره شماره‌گذاری نکن. متن بعضی قطعات در این نسخه عوض شده؛ تنها برابری شناسه برای استفادهٔ مجدد کافی نیست و SHA256 متن باید برابر باشد.

## کنترل کیفی پیش از تحویل صوت‌دار
- متن هیچ قطعه کم یا زیاد نشده باشد؛ شماره، نام گوینده و توضیح صحنه خوانده نشود.
- IPA، املای واژه، معنی و خود تلفظ را با هم بررسی کن؛ مخصوصاً quiet, patient, nervous, generous, talkative, hard-working, cruel, there, they و contractionها.
- دیالوگ Ehsan/Parham و Teacher/Samira و Mina/Sara با صداهای ثابت و متمایز اجرا شود؛ فاصلهٔ طبیعی نوبت‌ها حفظ شود.
- جمله‌های خبریِ بخش آهنگ افت مناسب داشته باشند؛ افت صدا را با نجوا اشتباه نگیر.
- ابتدا و انتهای کلمه قطع نشده، سکوت طولانی و کلیک وجود نداشته باشد. اگر سرعت 0.85 خواندن را نامفهوم کرد، متن/تولید را اصلاح کن، نه با افکت سنگین.
- در دسکتاپ و موبایل پخش، pause، seek، سرعت و عدم پخش همزمان را امتحان کن. مرورگرهای قدیمی ممکن است Opus در WebM را نپذیرند؛ تغییر پسوند این مشکل را رفع نمی‌کند.
- شمار audioهای دارای src امبد با شمار قطعات manifest برابر باشد؛ همهٔ آیکون‌ها باید aria-disabled=false داشته باشند. HTML را با شبکهٔ قطع‌شده دوباره باز کن؛ عکس‌ها و صوت‌ها باید موجود باشند.

## متن کامل قطعات به ترتیب تدریس
زبان fa فارسی ایران و en انگلیسی عمومی آمریکایی است. متن داخل کادر تنها ورودی گفتار است؛ خط‌های بیرون کادر metadata هستند.

### L01-001 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: متن اصلی
- فایل: `L01-001.weba`
- voice: `sage`
- slot: `data-audio-id="L01-001"`
- SHA256 متن UTF-8: `a7271c0099f6eb970dd7448b1083c826d737d336fbdc778f4039fcf037739049`

```text
سلام! من آرتین، راهنمای یادگیری تو هستم. امروز یاد می‌گیری دربارهٔ ویژگی‌های رفتاری خودت و دیگران حرف بزنی. اول پایه‌ها را آماده می‌کنیم، بعد با هم جمله می‌سازیم و در پایان خودت گفت‌وگو می‌کنی. لازم نیست از اول همه‌چیز را بدانی؛ هر جا دشوار شد یک گام کوچک‌تر برمی‌داریم.
```

### L01-002 — آرتین — en

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: متن اصلی
- فایل: `L01-002.weba`
- voice: `sage`
- slot: `data-audio-id="L01-002"`
- SHA256 متن UTF-8: `dd19212d011cf2264530aa1d7abaaf655c7b1145fbe48e1a7e7e4a7eec9abd82`

```text
Welcome! In this lesson, you will describe people, ask about personality, and give short answers. Think first, try, and then check.
```

### L01-003 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: متن اصلی
- فایل: `L01-003.weba`
- voice: `sage`
- slot: `data-audio-id="L01-003"`
- SHA256 متن UTF-8: `5788ddc1228bf2d220d0ff60de140aa231aa58b5b06c91baad8d7eb9b0ed0b55`

```text
شخصیت یعنی الگوی رفتار یک فرد؛ مثلاً مهربان بودن یا منظم بودن. از یک عکس یا یک رفتار نمی‌توان دربارهٔ تمام شخصیت یک انسان حکم داد. تصاویر این درس فقط به یادگیری معنی واژه‌ها کمک می‌کنند. دربارهٔ افراد واقعی محترمانه حرف می‌زنیم.
```

### L01-135 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: متن اصلی
- فایل: `L01-135.weba`
- voice: `sage`
- slot: `data-audio-id="L01-135"`
- SHA256 متن UTF-8: `f0c3741a42b55dbe3d10aa98af923d3eaf6c0cc835d6571acb85bc0e3cadcfcf`

```text
زمان پیشنهادی منعطف: ۴ جلسهٔ ۴۵ تا ۶۰ دقیقه‌ای؛ برای شروع ضعیف، جلسهٔ پل پیش‌نیاز را اضافه کن. عجله لازم نیست. درصد منوی شناور فقط میزان پیمایش صفحه است؛ امتیاز یادگیری جداگانه نمایش داده می‌شود.
```

### L01-136 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: روش استفاده و مسیر متناسب با سطح تو
- فایل: `L01-136.weba`
- voice: `sage`
- slot: `data-audio-id="L01-136"`
- SHA256 متن UTF-8: `63754e2e6001e0346ac096bf017c646df929b6c265f9d45d13f09de9386f2282`

```text
سنجش ورودی را انجام بده. زیر ۷۵٪: پل پیش‌نیاز را کامل بخوان؛ ۷۵٪ و بالاتر: سریع مرور کن.
```

### L01-137 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: روش استفاده و مسیر متناسب با سطح تو
- فایل: `L01-137.weba`
- voice: `sage`
- slot: `data-audio-id="L01-137"`
- SHA256 متن UTF-8: `21629e89843b40bee62cb945bf592246081d388619b9ba30955ddb06e1282b1c`

```text
در هر بخش، اول مثال را ببین، پیش از بازکردن پاسخ تلاش کن و یک نمونهٔ شخصی بساز.
```

### L01-138 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: روش استفاده و مسیر متناسب با سطح تو
- فایل: `L01-138.weba`
- voice: `sage`
- slot: `data-audio-id="L01-138"`
- SHA256 متن UTF-8: `e53d7df17173dc7fa3857c97965ed1977fcdcf88d2488b94c3a1eb35e9e4da0f`

```text
پس از محتوای کتاب، مثال‌های تازه و تمرین‌های سه‌سطحی را انجام بده.
```

### L01-139 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: روش استفاده و مسیر متناسب با سطح تو
- فایل: `L01-139.weba`
- voice: `sage`
- slot: `data-audio-id="L01-139"`
- SHA256 متن UTF-8: `870c2e5d6707508b41dfa8f1030f2ed278eba0a71be08729c70e29a5766ac147`

```text
آزمون ۱۲ سؤالی را مستقل حل کن. گفتار و نوشتار با rubric خودسنجی ارزیابی می‌شوند، نه تشخیص خودکار ساختگی.
```

### L01-140 — آرتین — fa

- بخش: نقشهٔ راه: از جملهٔ ساده تا گفت‌وگوی مستقل (`goals`)
- کادر: روش استفاده و مسیر متناسب با سطح تو
- فایل: `L01-140.weba`
- voice: `sage`
- slot: `data-audio-id="L01-140"`
- SHA256 متن UTF-8: `17bcd3190ce33fd9f519539bf841f8fcd3641ae05165b5902523490f6a72e9e4`

```text
روز بعد و سه و هفت روز بعد، بدون نگاه کردن مرور کن.
```

### L01-004 — آرتین — fa

- بخش: سنجش ورودی؛ چه چیزهایی را از قبل بلدم؟ (`entry`)
- کادر: متن اصلی
- فایل: `L01-004.weba`
- voice: `sage`
- slot: `data-audio-id="L01-004"`
- SHA256 متن UTF-8: `94b9e120a757e9dafcfdb1ca787bae8ec65771a56184c079ab45ec211d9670dd`

```text
این سنجش نمرهٔ مدرسه ندارد. برای هر پرسش یک گزینه انتخاب کن و سپس نتیجه را بگیر. اگر جواب را نمی‌دانی، همان هم به ما می‌گوید کدام قسمت را باید تمرین کنی.
```

### L01-005 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-005.weba`
- voice: `sage`
- slot: `data-audio-id="L01-005"`
- SHA256 متن UTF-8: `0b7ebb581b37bfb327ac7cfad731892ee8380f8d23c1c0bba4633ea6e124f13f`

```text
از پایهٔ هفتم، سلام و معرفی خود، خواندن نام‌ها، ضمیرها، خانواده و جمله‌های کوتاه را لازم داریم. از پایهٔ هشتم، پرسیدن اطلاعات، شناخت مفرد و جمع، واژه‌های پرسشی و خواندن واژه‌ها به کمک صداها را مرور می‌کنیم. این یک مرور کاربردی از دانسته‌های لازم است، نه ادعای نقل صفحه‌به‌صفحه از کتاب‌های قبلی.
```

### L01-006 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-006.weba`
- voice: `sage`
- slot: `data-audio-id="L01-006"`
- SHA256 متن UTF-8: `97cd66a3f3ed43ccfa10850457bf8a32082c3f61c7bd7eb7ebf686da84262e7f`

```text
Hello. My name is Sara. I am a student. This is my brother. We are friends.
```

### L01-007 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-007.weba`
- voice: `sage`
- slot: `data-audio-id="L01-007"`
- SHA256 متن UTF-8: `97fca6e09a2e7876fceb431e17aafe50d92aa37b38f98714579fdaea0f916bfb`

```text
من در فارسی می‌گویم «او مهربان است». در انگلیسی، «است» حذف نمی‌شود: She is kind. ضمیر را انتخاب کن، فعل مناسب را بگذار، بعد ویژگی را اضافه کن. برای تو و شما هر دو you داریم و هر دو با are می‌آیند.
```

### L01-008 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-008.weba`
- voice: `sage`
- slot: `data-audio-id="L01-008"`
- SHA256 متن UTF-8: `75167be4c31d70414f399273ccf21c7b97ed192956269d92a6b8877372a4c2ae`

```text
I am a student. You are a student. He is a student. She is a student. We are students. They are students.
```

### L01-141 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: اگر هنوز ضمیرها دشوار است؛ گام کوچک‌تر
- فایل: `L01-141.weba`
- voice: `sage`
- slot: `data-audio-id="L01-141"`
- SHA256 متن UTF-8: `875f29c3156ec50a610a91c23de731bf927552812256ced4991e86c60f27326e`

```text
به خودت اشاره کن: I. به مخاطب: you. به علی: he. به سارا: she. به خودت و دوستت: we. به دو نفر دیگر: they. حالا برای هرکدام یک جمله با جدول بساز.
```

### L01-142 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: اگر هنوز ضمیرها دشوار است؛ گام کوچک‌تر
- فایل: `L01-142.weba`
- voice: `sage`
- slot: `data-audio-id="L01-142"`
- SHA256 متن UTF-8: `fad4872e24c53fed88daa6f7e4851f69e6e2fd925153be99f23bd87067c7f05e`

```text
Sara → she → She is a student.
Ali and Reza → they → They are students.
```

### L01-009 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-009.weba`
- voice: `sage`
- slot: `data-audio-id="L01-009"`
- SHA256 متن UTF-8: `1f7c687569deb107d2e487f89c1569825b6476e2540d87a57324e10d42b68979`

```text
my، your، his، her، our و their قبل از اسم می‌آیند و صاحب آن را نشان می‌دهند. he یعنی او؛ his friend یعنی دوستِ او. she یعنی او؛ her friend یعنی دوستِ او. برای ساخت جمله، اول هستهٔ فاعل را پیدا کن: my mother یک نفر است؛ my parents دو نفر هستند.
```

### L01-010 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-010.weba`
- voice: `sage`
- slot: `data-audio-id="L01-010"`
- SHA256 متن UTF-8: `4023eb52e185552f5227e87060c11a3c67d5f565a1ec410fac12eafc6a4cc3d5`

```text
My mother is kind. Her friend is patient. Our parents are helpful. Their teacher is careful.
```

### L01-011 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-011.weba`
- voice: `sage`
- slot: `data-audio-id="L01-011"`
- SHA256 متن UTF-8: `6d7ff58687dae076b79dc73638ff4f5d553b30366827aee9d3743ac5c060e34a`

```text
فاعل فقط یک ضمیر نیست. Ali به he تبدیل می‌شود و is می‌گیرد. Zahra and Nadia به they تبدیل می‌شود و are می‌گیرد. عبارت my family یک گروه به‌عنوان واحد است؛ برای جمع روشن و ساده، در این درس می‌گوییم my family members are. members یعنی اعضا.
```

### L01-012 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-012.weba`
- voice: `sage`
- slot: `data-audio-id="L01-012"`
- SHA256 متن UTF-8: `00f9324834e4a540a53065dc629e08d25560002e9968995187226f70a9e84de1`

```text
a یا an یعنی یک، قبل از اسم شمارش‌پذیر مفرد. a book، an apple. جمع معمولاً s می‌گیرد: books و students. صفت با جمع شدن اسم s نمی‌گیرد. اگر از دیکشنری استفاده می‌کنی، ابتدا املای واژه را بررسی کن، بعد معنی مناسب جمله و تلفظش را بخوان.
```

### L01-013 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-013.weba`
- voice: `sage`
- slot: `data-audio-id="L01-013"`
- SHA256 متن UTF-8: `cf8ef0f9397c93c92c6394ef14e39eb80f6669793a248328492790ce76db8566`

```text
A book. An apple. Two books. Three students. Kind students. Let me check it in the dictionary.
```

### L01-014 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-014.weba`
- voice: `sage`
- slot: `data-audio-id="L01-014"`
- SHA256 متن UTF-8: `8db0654416d61566463c17d09bd871ca9690a06e775a73450f4956be4810896b`

```text
Who یعنی چه کسی، what یعنی چه یا چه چیزی، how یعنی چگونه و where یعنی کجا. عبارت What is he like? را بعداً به‌عنوان یک الگوی کامل یاد می‌گیریم. حروف بزرگ و کوچک را تشخیص بده؛ I همیشه بزرگ نوشته می‌شود و ابتدای جمله حرف بزرگ می‌خواهد.
```

### L01-015 — آرتین — en

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: متن اصلی
- فایل: `L01-015.weba`
- voice: `sage`
- slot: `data-audio-id="L01-015"`
- SHA256 متن UTF-8: `e03ef46d2023191a478b39588f2436e004bf9075fcb99eb41b6c013804e644cf`

```text
Who is she? She is Mina. Where is she? She is at school.
```

### L01-143 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: تمرین تکمیلی پیش‌نیاز با پاسخ
- فایل: `L01-143.weba`
- voice: `sage`
- slot: `data-audio-id="L01-143"`
- SHA256 متن UTF-8: `293a2ebb4536df870277a7bee269ef5f4c9d4e49407c7660f892ed50f69c35d8`

```text
به ترتیب ضمیر و فعل را بگو: my father؛ Sara and I؛ you؛ the book.
```

### L01-144 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: تمرین تکمیلی پیش‌نیاز با پاسخ
- فایل: `L01-144.weba`
- voice: `sage`
- slot: `data-audio-id="L01-144"`
- SHA256 متن UTF-8: `e53999d73bd64ff3651824e8291e55223da2403c86bee18619cfcb37b53eb2f9`

```text
پاسخ: he is / we are / you are / it is
```

### L01-145 — آرتین — fa

- بخش: پل هفتم و هشتم؛ پیش از شروع کتاب (`bridge`)
- کادر: تمرین تکمیلی پیش‌نیاز با پاسخ
- فایل: `L01-145.weba`
- voice: `sage`
- slot: `data-audio-id="L01-145"`
- SHA256 متن UTF-8: `a106f09cfab9f8c366f39c0d59d35375ac3ec8013b3589c6e191d1e1e6394059`

```text
اگر هنوز در دو مورد خطا داری، همین چهار الگو را با نام‌های دیگر تکرار کن. پس از توانایی ساخت ۴ جملهٔ درست به بخش بعد برو.
```

### L01-016 — آرتین — fa

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-016.weba`
- voice: `sage`
- slot: `data-audio-id="L01-016"`
- SHA256 متن UTF-8: `3851d1140b3ed8bebc75512e1e502b1fa6e9649d1a71fd6e1d613c7728cab9b1`

```text
به‌جای حفظ فهرست، هر واژه را به یک موقعیت وصل کن. اول تصویر و موقعیت را ببین، معنی را حدس بزن، واژه را بگو و بعد یک جمله بساز. angry، nervous و upset می‌توانند حالت موقتی باشند؛ آن‌ها همیشه ویژگی ثابت شخصیت نیستند.
```

### L01-017 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-017.weba`
- voice: `sage`
- slot: `data-audio-id="L01-017"`
- SHA256 متن UTF-8: `153cf385c020a059656036d9201a253b8437ae0ad1cbed461869688fcb40d312`

```text
Look, think, say the word, and use it in a sentence. A person can be nervous today and confident tomorrow.
```

### L01-018 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-018.weba`
- voice: `sage`
- slot: `data-audio-id="L01-018"`
- SHA256 متن UTF-8: `69a45d310dda8f2e65b0537c30f396b8ac373d94c40fc099a8ca0d49e56d0001`

```text
angry. She is angry now.
```

### L01-019 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-019.weba`
- voice: `sage`
- slot: `data-audio-id="L01-019"`
- SHA256 متن UTF-8: `d434bea6c03c7ca8fd7e42d62407ba51b08314ca2fc449c9faf471d8b5f4e5df`

```text
brave. The firefighter is brave.
```

### L01-020 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-020.weba`
- voice: `sage`
- slot: `data-audio-id="L01-020"`
- SHA256 متن UTF-8: `2e39be03c606e5bafc4b4c32e1794f8f747e51ab3ed78630ff9fbcc0081c218c`

```text
careless. He is careless with his books.
```

### L01-021 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-021.weba`
- voice: `sage`
- slot: `data-audio-id="L01-021"`
- SHA256 متن UTF-8: `aa2cf8c170daeeb5fe092ab9972b6c988359182ffe71e58f065490ce630a6820`

```text
cruel. The man in the story is cruel.
```

### L01-022 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-022.weba`
- voice: `sage`
- slot: `data-audio-id="L01-022"`
- SHA256 متن UTF-8: `71203003dea36b0ea72af30d854afe3a2d6739182e0c321188f5c665a7f2e52f`

```text
rude. That rude answer is not kind.
```

### L01-023 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-023.weba`
- voice: `sage`
- slot: `data-audio-id="L01-023"`
- SHA256 متن UTF-8: `16658e35979caef6e09ce3af5efd30eb83e5f9f89fcb0bb7e4a28890fcd92710`

```text
nervous. I am nervous before a test.
```

### L01-024 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-024.weba`
- voice: `sage`
- slot: `data-audio-id="L01-024"`
- SHA256 متن UTF-8: `2476dbac47f9eb6999984d4ae0e13b84681222c229f5ff900e91df0e26582d54`

```text
quiet. My friend is quiet in class.
```

### L01-025 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-025.weba`
- voice: `sage`
- slot: `data-audio-id="L01-025"`
- SHA256 متن UTF-8: `36629e3fa3b2c16d8aa1f7e4d6dedfea2d48e005331435362fbd030401e59aac`

```text
funny. My uncle is funny.
```

### L01-026 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-026.weba`
- voice: `sage`
- slot: `data-audio-id="L01-026"`
- SHA256 متن UTF-8: `b3826ada268fe7c0626d65e77c8e0b00fcdadcf1159e504d17e0143fe8a0e209`

```text
selfish. The selfish boy does not share.
```

### L01-027 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-027.weba`
- voice: `sage`
- slot: `data-audio-id="L01-027"`
- SHA256 متن UTF-8: `c5a2f10a47765f73251bf2bfa4f0786364bbde65ca85609ddaebb9f46383e4e6`

```text
neat. Her desk is neat.
```

### L01-028 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-028.weba`
- voice: `sage`
- slot: `data-audio-id="L01-028"`
- SHA256 متن UTF-8: `adb9c6fa09c26946a20116bae188ac36f5e4b1b08422990621db8d1a6e788b08`

```text
clever. She is a clever student.
```

### L01-029 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-029.weba`
- voice: `sage`
- slot: `data-audio-id="L01-029"`
- SHA256 متن UTF-8: `74497de7781ba8448bae82594d69723ffdbbd59768104a84ac35080b32ee3cfa`

```text
kind. Our teacher is kind.
```

### L01-030 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-030.weba`
- voice: `sage`
- slot: `data-audio-id="L01-030"`
- SHA256 متن UTF-8: `fc62b020851c1c61dab48e3d34f8d0c56fb10ecf4da7fa68ea91d7a667c297b3`

```text
hard-working. They are hard-working.
```

### L01-031 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-031.weba`
- voice: `sage`
- slot: `data-audio-id="L01-031"`
- SHA256 متن UTF-8: `a822c31ce3eaf4103650137e0a203a1bdfdfc9414824418a3bea1ba9d688b0a4`

```text
helpful. My sister is helpful.
```

### L01-032 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-032.weba`
- voice: `sage`
- slot: `data-audio-id="L01-032"`
- SHA256 متن UTF-8: `519457131886e9a2e89a8b0aa5fc1d41458fa95cee88952869557daa1a033362`

```text
talkative. My cousin is talkative.
```

### L01-033 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-033.weba`
- voice: `sage`
- slot: `data-audio-id="L01-033"`
- SHA256 متن UTF-8: `e529b47606a86cea6638bbeb6b7b985b8982c7f7a84618a2e063fe841c92b3d9`

```text
upset. He is upset today.
```

### L01-034 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-034.weba`
- voice: `sage`
- slot: `data-audio-id="L01-034"`
- SHA256 متن UTF-8: `42063b1d3874ee31b3c28230d3002c8be06ae37b5876fe01aabf4fa71ead4ba8`

```text
patient. My mother is patient.
```

### L01-035 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-035.weba`
- voice: `sage`
- slot: `data-audio-id="L01-035"`
- SHA256 متن UTF-8: `96fec03824479ced3db32550a7efcfef8b3d6c8d107cee5e965c787315a01e2b`

```text
serious. I am a bit serious.
```

### L01-036 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-036.weba`
- voice: `sage`
- slot: `data-audio-id="L01-036"`
- SHA256 متن UTF-8: `594dc71257fe252e25bfc53837c3dee78ccf0c50ed027efe0e394bf68df131dc`

```text
shy. The new student is shy.
```

### L01-037 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-037.weba`
- voice: `sage`
- slot: `data-audio-id="L01-037"`
- SHA256 متن UTF-8: `c52f8fde6c2bb465ee945cd8670df79b16c4a8a1b8d7b358970b20aed89f1636`

```text
careful. Be careful with the glass.
```

### L01-038 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-038.weba`
- voice: `sage`
- slot: `data-audio-id="L01-038"`
- SHA256 متن UTF-8: `c043a1edf52fc346bec09016cfb072cb77da1322ce686934d31ab638904950c3`

```text
generous. My aunt is generous.
```

### L01-039 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-039.weba`
- voice: `sage`
- slot: `data-audio-id="L01-039"`
- SHA256 متن UTF-8: `25427a51c544fecbccaadd35c2e9dc6b5b6fa6e3368cb4e5bbe60f51ff2daa5b`

```text
polite. The students are polite.
```

### L01-040 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-040.weba`
- voice: `sage`
- slot: `data-audio-id="L01-040"`
- SHA256 متن UTF-8: `30573329d7a0f9cab3066979d55c9166a57c179d35944a2089aa20a06da1073a`

```text
friendly. Our neighbor is friendly.
```

### L01-041 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-041.weba`
- voice: `sage`
- slot: `data-audio-id="L01-041"`
- SHA256 متن UTF-8: `3e60a9ff06e28ab9c6ac16964cf7ac73dd89c267598e7dcde2753a008f298aa3`

```text
happy. We are happy today.
```

### L01-042 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-042.weba`
- voice: `sage`
- slot: `data-audio-id="L01-042"`
- SHA256 متن UTF-8: `52eb9b0c12fa246aa3e9a811ab66ecd226af56207d503ff97fcc3b36f86c6d8e`

```text
good. He is a good friend.
```

### L01-043 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-043.weba`
- voice: `sage`
- slot: `data-audio-id="L01-043"`
- SHA256 متن UTF-8: `65ddb0531f5b082dbfb96a4b8b9eb7b7014c65c7ea5f3f10205dab0aa6ac9cbf`

```text
great. She is a great friend.
```

### L01-044 — آرتین — fa

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-044.weba`
- voice: `sage`
- slot: `data-audio-id="L01-044"`
- SHA256 متن UTF-8: `6ee6f131677b28381b63e6c3ab8ac8a1ed3b9ffcc49f5fb891a3ea80a0a43e96`

```text
از یک ویژگی برای ساخت صفتِ مخالف استفاده نکن مگر شکل درستش را بلد باشی. careful و careless یک جفت کاربردی‌اند؛ polite و rude، kind و cruel، quiet و talkative هم در موقعیت مناسب مقابل هم قرار می‌گیرند. helpful یعنی به دیگران کمک می‌کند؛ hard-working یعنی با تلاش کار می‌کند. این دو یک معنی ندارند.
```

### L01-045 — آرتین — en

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: متن اصلی
- فایل: `L01-045.weba`
- voice: `sage`
- slot: `data-audio-id="L01-045"`
- SHA256 متن UTF-8: `b29ca3a17069b44cc0f30bae73d749bb429efa4fa42c2639017dc1b0b810d218`

```text
A helpful friend helps you. A hard-working student studies carefully. Quiet does not always mean shy. Funny does not mean happy.
```

### L01-146 — آرتین — fa

- بخش: واژگان در بافت؛ معنی، تلفظ و رفتار (`vocabulary`)
- کادر: بازی یادآوری بدون نگاه کردن
- فایل: `L01-146.weba`
- voice: `sage`
- slot: `data-audio-id="L01-146"`
- SHA256 متن UTF-8: `0b1660ae2376cbfcbd91d0b12717db0cf9a8f53fbb4586c9ea22b67fae8abed4`

```text
معنی کارت‌ها را بپوشان. برای هر واژه یک رفتار بگو. سپس از حافظه ۵ واژهٔ مثبت و ۲ حالت موقتی بنویس. برای افراد واقعی برچسب منفی نساز؛ از شخصیت‌های فرضی یا رفتار مشخص مثال بزن.
```

### L01-046 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-046.weba`
- voice: `sage`
- slot: `data-audio-id="L01-046"`
- SHA256 متن UTF-8: `dd6b1ef87a0e38362b5fcf30821d5609f4177d9b2afc1bfea61b1d90caf6dc6d`

```text
دو پسرعمو یا دو خویشاوند دربارهٔ بهترین دوست در مدرسه صحبت می‌کنند. بار اول فقط دنبال اسم و ویژگی‌ها باش. بار دوم عبارت‌های پرسشی را پیدا کن. بار سوم نقش یکی از آن‌ها را بگیر و پاسخ طرف مقابل را خودت بگو.
```

### L01-047 — آرتین — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-047.weba`
- voice: `sage`
- slot: `data-audio-id="L01-047"`
- SHA256 متن UTF-8: `6929c0ca1a29a3dd8743018ff3396031515cd8ee9120bf98d3074f0969d2c29c`

```text
Who are they talking about? What is he like? Read the conversation once, then answer without looking.
```

### L01-048 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-048.weba`
- voice: `echo`
- slot: `data-audio-id="L01-048"`
- SHA256 متن UTF-8: `8a554113e413649017f6f5959ab0dcfc5e3d614d25440091fba5b397ce99a688`

```text
Who is your best friend at school?
```

### L01-049 — Parham — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-049.weba`
- voice: `onyx`
- slot: `data-audio-id="L01-049"`
- SHA256 متن UTF-8: `70de77b78d1cf1d9177c2833ddc402e110d3274c1dbdb9e9dc78fd484dbd1649`

```text
Reza.
```

### L01-050 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-050.weba`
- voice: `echo`
- slot: `data-audio-id="L01-050"`
- SHA256 متن UTF-8: `62b86bc1092a3716afb7c491f8eb1db0a2fdcf050a842f7df457f80289a9de26`

```text
What’s he like?
```

### L01-051 — Parham — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-051.weba`
- voice: `onyx`
- slot: `data-audio-id="L01-051"`
- SHA256 متن UTF-8: `47414300e7aebebca60e647cf0222628aa13afda5f37596eb96c22bf731a427a`

```text
Oh, he is really great! He’s clever and kind.
```

### L01-052 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-052.weba`
- voice: `echo`
- slot: `data-audio-id="L01-052"`
- SHA256 متن UTF-8: `1701e350077c88221db48914858c949cb83e6abe6973d7c88c7ee5043aeb46f6`

```text
Is he hard-working too?
```

### L01-053 — Parham — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-053.weba`
- voice: `onyx`
- slot: `data-audio-id="L01-053"`
- SHA256 متن UTF-8: `90237f0f03c0cffc8cd31ce6b484c83b839f197f35ee89ebb1cd8bbf547f934b`

```text
Yes! And he’s always very helpful.
```

### L01-054 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-054.weba`
- voice: `echo`
- slot: `data-audio-id="L01-054"`
- SHA256 متن UTF-8: `0ea5977074d19b323a93e0a94cb9a5d4abeb75418234455cf38e6293403fe236`

```text
How?
```

### L01-055 — Parham — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-055.weba`
- voice: `onyx`
- slot: `data-audio-id="L01-055"`
- SHA256 متن UTF-8: `5473b4c5d001336b0ee596066829b9fa10cc2130add63725fbfd88264807eeac`

```text
He always helps me with my lessons.
```

### L01-056 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-056.weba`
- voice: `sage`
- slot: `data-audio-id="L01-056"`
- SHA256 متن UTF-8: `e930c915e0e658282d5b3a326e9bc9c3bd9037c9d2b8dbfe701c5d4d3012004c`

```text
Who is your best friend? هویت می‌پرسد و پاسخ آن رضاست. What’s he like? ویژگی می‌پرسد و پاسخ می‌تواند باهوش و مهربان باشد. How? در این گفت‌وگو یعنی «چطور کمک می‌کند؟». در He always helps me فعل اصلی helps است؛ این جمله را به‌صورت یک تکهٔ کاربردی می‌آموزیم. قواعد کامل فعل‌های اصلی موضوع اصلی این درس نیست.
```

### L01-057 — آرتین — en

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: متن اصلی
- فایل: `L01-057.weba`
- voice: `sage`
- slot: `data-audio-id="L01-057"`
- SHA256 متن UTF-8: `8efa4311dd82fea8f9bc41e68a61dd393a45ef3bd3ca528aac194397555dd2cc`

```text
Who is your best friend? Reza. What’s he like? He’s clever and kind. How is he helpful? He helps me with my lessons.
```

### L01-147 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: نقش‌آفرینی در سه دور
- فایل: `L01-147.weba`
- voice: `sage`
- slot: `data-audio-id="L01-147"`
- SHA256 متن UTF-8: `f0d7af310601bb9eb7d83facbb1aa40c5b3a5322fb577c5fe7f094604e3736f5`

```text
متن باز: هر خط را بخوان و معنی آن را بگو.
```

### L01-148 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: نقش‌آفرینی در سه دور
- فایل: `L01-148.weba`
- voice: `sage`
- slot: `data-audio-id="L01-148"`
- SHA256 متن UTF-8: `7efdd073bde4d8b4be912ea86d06b40a622bfa3fd068cebf5d990bb1bef6d379`

```text
ترجمه‌ها را پنهان کن؛ فقط نقش Ehsan را بخوان و جواب Parham را از حافظه بگو.
```

### L01-149 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ از فهم کلی تا نقش‌آفرینی (`conversation`)
- کادر: نقش‌آفرینی در سه دور
- فایل: `L01-149.weba`
- voice: `sage`
- slot: `data-audio-id="L01-149"`
- SHA256 متن UTF-8: `6f7ef3136fb7155dc5ef4eab6037a4a3b76b212892e0b1aadcabd1cd2f8fb3b8`

```text
متن را ببند و با نام و دو ویژگی تازه، یک مکالمه بساز. این بار دلیل helpful یا hard-working بودن را هم اضافه کن.
```

### L01-058 — آرتین — fa

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-058.weba`
- voice: `sage`
- slot: `data-audio-id="L01-058"`
- SHA256 متن UTF-8: `c5af1bfd5212e768cb0b83e6a63e0386036f814f65ac9555d3f5e3e88418b915`

```text
وقتی می‌خواهی درستی یک ویژگی را بررسی کنی، با am، is یا are سؤال بساز. وقتی خودِ ویژگی را نمی‌دانی، از الگوی What ... like? استفاده کن. در این الگو like فعلِ «دوست داشتن» نیست؛ بخشی از پرسشِ «چه جور است؟» است.
```

### L01-059 — آرتین — en

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-059.weba`
- voice: `sage`
- slot: `data-audio-id="L01-059"`
- SHA256 متن UTF-8: `c7094140e0d596c494978bb40b1fa2272d9ad18a810ab4e54670a0685657f343`

```text
Is he clever? Yes, he is. What’s he like? He’s clever and kind.
```

### L01-060 — آرتین — en

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-060.weba`
- voice: `sage`
- slot: `data-audio-id="L01-060"`
- SHA256 متن UTF-8: `7a96101271d4f69d0eb9bad1623d3f4970cccc106e6fadbeadd5aabc805defb1`

```text
Are you hard-working? Yes, I am. Is he clever? Yes, he is. Is Zahra talkative? No, she isn’t. Are they neat? Yes, they are. Are they upset? No, they’re not.
```

### L01-061 — آرتین — en

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-061.weba`
- voice: `sage`
- slot: `data-audio-id="L01-061"`
- SHA256 متن UTF-8: `31056c2aea1a3557a6328d9104addb8d219bef49ff30dc80c9e39dc9edd2d8fb`

```text
What’s your friend like? He’s very funny. What’s your mother like? She’s very kind and patient. What are you like? I’m a bit serious. What are they like? They are very kind.
```

### L01-062 — رها — fa

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-062.weba`
- voice: `coral`
- slot: `data-audio-id="L01-062"`
- SHA256 متن UTF-8: `03f04ce72f15b6d40dbcd6ecfd361584abfc31b0d5993f37cf7d0d78f6f9977c`

```text
من What does he like? را با What is he like? قاطی می‌کنم. هر دو دربارهٔ او نیستند؟
```

### L01-063 — آرتین — fa

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-063.weba`
- voice: `sage`
- slot: `data-audio-id="L01-063"`
- SHA256 متن UTF-8: `3975daa4c85b3f01fdf31a8ff1ab632f4b6f3caab123522eaeacc6575eb5b38a`

```text
هر دو دربارهٔ یک نفرند، اما اطلاعات متفاوت می‌خواهند. What is he like? دربارهٔ شخصیت است: او مهربان است. What does he like? دربارهٔ علاقه است: او فوتبال را دوست دارد. What does he look like? دربارهٔ ظاهر است: او قدبلند است. دو پرسش آخر را فقط برای تشخیص تفاوت می‌بینیم.
```

### L01-064 — آرتین — en

- بخش: دو شیوهٔ پرسیدن دربارهٔ شخصیت (`patterns`)
- کادر: متن اصلی
- فایل: `L01-064.weba`
- voice: `sage`
- slot: `data-audio-id="L01-064"`
- SHA256 متن UTF-8: `e4a319fc827838ae7a6fde925ee0ff663ab2d651744196dcc229f41c861b7414`

```text
What is he like? He is kind. What does he like? He likes football. What does he look like? He is tall.
```

### L01-065 — آرتین — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-065.weba`
- voice: `sage`
- slot: `data-audio-id="L01-065"`
- SHA256 متن UTF-8: `47cad3884c88e68ee8cdc9d5fa0c318409b157fb9a1e32e9340fcc54b9f1c515`

```text
جملهٔ مثبت سه جایگاه دارد: فاعل، شکل مناسب be و مکمل. در توصیف شخصیت، مکمل معمولاً صفت است. I با am، he و she و it با is، و you و we و they با are می‌آیند. صفت نه s جمع می‌گیرد و نه به مؤنث یا مذکر تبدیل می‌شود.
```

### L01-066 — آرتین — en

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-066.weba`
- voice: `sage`
- slot: `data-audio-id="L01-066"`
- SHA256 متن UTF-8: `85dac3bbe21ae261f964c50c29a26317ac5b73298ca41f79bf725a3f1b1fb62d`

```text
I am happy. He is happy. She is happy. We are happy. You are happy. They are happy.
```

### L01-067 — آرتین — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-067.weba`
- voice: `sage`
- slot: `data-audio-id="L01-067"`
- SHA256 متن UTF-8: `25b107337fbdc276270ca03aca9b6721e859bff52788de4d21fb074da7685e15`

```text
برای منفی کردن، not را بعد از be می‌گذاریم؛ جای فاعل تغییر نمی‌کند. برای سؤال بله یا خیر، be به اول جمله می‌رود و فاعل بعد از آن می‌آید. برای این جمله‌ها do و does اضافه نمی‌کنیم.
```

### L01-068 — آرتین — en

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-068.weba`
- voice: `sage`
- slot: `data-audio-id="L01-068"`
- SHA256 متن UTF-8: `84e5725ec83b73dc2d64ba2a2cea8f44052a58399edb90431c7fd453c389135d`

```text
She is shy. She is not shy. Is she shy? They are rude. They are not rude. Are they rude?
```

### L01-069 — رها — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-069.weba`
- voice: `coral`
- slot: `data-audio-id="L01-069"`
- SHA256 متن UTF-8: `13e612aafcf1ba4565189340c9b34f706de5f55b11149493372deed6335e087c`

```text
چرا نمی‌توانم بگویم Does she is kind؟
```

### L01-070 — آرتین — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-070.weba`
- voice: `sage`
- slot: `data-audio-id="L01-070"`
- SHA256 متن UTF-8: `f549ec4aae875872fdeda847d1ec6dac95421c04472d00717d1c2ea244646ac1`

```text
چون همین is می‌تواند سؤال را بسازد. آن را از بعدِ she به قبلِ she می‌بریم. Does she is kind دو سازوکار را با هم مخلوط کرده است؛ شکل درست Is she kind? است. اگر فعل اصلی مثل help داشته باشیم، قاعدهٔ دیگری لازم است.
```

### L01-071 — آرتین — en

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-071.weba`
- voice: `sage`
- slot: `data-audio-id="L01-071"`
- SHA256 متن UTF-8: `8a5b8fc4b7259281a06b58a6b287818cce90d5c8fe4476990b8cb2daa1b0ac3f`

```text
She is kind. Is she kind? Yes, she is. No, she isn’t.
```

### L01-072 — آرتین — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-072.weba`
- voice: `sage`
- slot: `data-audio-id="L01-072"`
- SHA256 متن UTF-8: `de80540a626f2aa035b0a2834e8a7eb564cb26c0b58822fb717af02fdfd5dc52`

```text
در پاسخ کوتاه، نام را معمولاً به ضمیر تبدیل می‌کنیم: Is Ali polite? Yes, he is. اگر پرسش با you خطاب به تو باشد، با I جواب بده؛ اگر خطاب به چند نفر شامل تو باشد، we مناسب است. Are we ready? از طرف همان گروه با Yes, we are جواب می‌گیرد.
```

### L01-073 — آرتین — en

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: متن اصلی
- فایل: `L01-073.weba`
- voice: `sage`
- slot: `data-audio-id="L01-073"`
- SHA256 متن UTF-8: `b8dc1492957de53a8c9aa0f9e8d9e1532c75924d0354c60035f03f95e6acc01a`

```text
Is Mina patient? Yes, she is. Are Sara and Mina neat? No, they aren’t. Are you kind? Yes, I am.
```

### L01-150 — آرتین — fa

- بخش: دستور زبان؛ منطق جمله‌های be (`grammar`)
- کادر: چالش فنی؛ نام‌ها و گروه‌ها
- فایل: `L01-150.weba`
- voice: `sage`
- slot: `data-audio-id="L01-150"`
- SHA256 متن UTF-8: `14faae9021dcab7b5048b574b386e267e71bf7275d9261bd0221265bcfcb8934`

```text
My mother and father are kind. چون دو نفرند. My best friend is kind. چون هستهٔ فاعل friend مفرد است. Everybody is ready. چون everybody از نظر دستوری مفرد است. در متن آهنگ، Everybody likes her یک جمله با فعل اصلی است؛ به آن is اضافه نکن.
```

### L01-074 — آرتین — fa

- بخش: شکل‌های کوتاه؛ خواندن طبیعی و نوشتن درست (`contractions`)
- کادر: متن اصلی
- فایل: `L01-074.weba`
- voice: `sage`
- slot: `data-audio-id="L01-074"`
- SHA256 متن UTF-8: `205b055a0429199610e9b79d9a9abc3c83cc2a809d3a49cae088499036945273`

```text
آپاستروف جای حرف‌های حذف‌شده را نشان می‌دهد. I am به I’m و she is به she’s تبدیل می‌شود. معنی عوض نمی‌شود؛ شکل کوتاه در گفت‌وگو طبیعی‌تر است. در نوشتار رسمی ممکن است شکل کامل را ترجیح بدهیم.
```

### L01-075 — آرتین — en

- بخش: شکل‌های کوتاه؛ خواندن طبیعی و نوشتن درست (`contractions`)
- کادر: متن اصلی
- فایل: `L01-075.weba`
- voice: `sage`
- slot: `data-audio-id="L01-075"`
- SHA256 متن UTF-8: `c24efa0e801ddc89c14b588510da746b53c15a1aa9308e2ec07e18562280a626`

```text
I am, I’m. He is, he’s. She is, she’s. It is, it’s. We are, we’re. You are, you’re. They are, they’re.
```

### L01-076 — آرتین — fa

- بخش: شکل‌های کوتاه؛ خواندن طبیعی و نوشتن درست (`contractions`)
- کادر: متن اصلی
- فایل: `L01-076.weba`
- voice: `sage`
- slot: `data-audio-id="L01-076"`
- SHA256 متن UTF-8: `efe3f8047d164a9e2f7daa62aca573ae554faa54c60752d4eb68720958453b92`

```text
در انگلیسی معیار این درس، amn’t نداریم؛ می‌گوییم I’m not. جواب کوتاه مثبت را با شکل کامل تمام کن: Yes, I am. در منفی می‌توانی بگویی No, I’m not. آپاستروف را با s مالکیت اشتباه نگیر؛ در He’s kind، معنی he is است.
```

### L01-077 — آرتین — en

- بخش: شکل‌های کوتاه؛ خواندن طبیعی و نوشتن درست (`contractions`)
- کادر: متن اصلی
- فایل: `L01-077.weba`
- voice: `sage`
- slot: `data-audio-id="L01-077"`
- SHA256 متن UTF-8: `b78d69a696ead40605f531bd9e8d710e7ac41205be04fe9992a0ca81a77391ee`

```text
Are you shy? Yes, I am. Are you rude? No, I’m not. Is he shy? No, he isn’t. They’re not upset.
```

### L01-078 — آرتین — fa

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-078.weba`
- voice: `sage`
- slot: `data-audio-id="L01-078"`
- SHA256 متن UTF-8: `0785dac229fd66a699ba356e44c1342f66530a7115eb4f5a1e8c847f3d158f32`

```text
برای خبر دادن از وجود چیزی، جمله را با There شروع می‌کنیم. There is برای یک چیز یا یک نفر، There are برای چند چیز یا چند نفر است. این there در این الگو لزوماً «آنجا» معنی نمی‌دهد؛ کل عبارت یعنی «وجود دارد» یا «هست».
```

### L01-079 — آرتین — en

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-079.weba`
- voice: `sage`
- slot: `data-audio-id="L01-079"`
- SHA256 متن UTF-8: `da24b0c32807be4e7943eddb93d97a2ba045d1a46965ecf44906d40411e42e79`

```text
There is a computer in the classroom. There is an eraser in the classroom. There are two students in the classroom.
```

### L01-080 — آرتین — fa

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-080.weba`
- voice: `sage`
- slot: `data-audio-id="L01-080"`
- SHA256 متن UTF-8: `04881a2913fc950abc1ac675cf9d3903be4ccdd44a173b7621a91540f501327e`

```text
در پاسخ کوتاه به Is there از Yes, there is یا No, there isn’t استفاده کن. برای Are there می‌گویی Yes, there are یا No, there aren’t. many یعنی تعداد زیاد و با اسم جمعِ شمارش‌پذیر می‌آید. some در جملهٔ مثبت یعنی مقداری یا تعدادی؛ در مثال دانش‌آموزان، یعنی تعدادی.
```

### L01-081 — آرتین — en

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-081.weba`
- voice: `sage`
- slot: `data-audio-id="L01-081"`
- SHA256 متن UTF-8: `855b61664da8b365a48cf4915d998cb3e579ab1b49999cb3329f41b1d24d3770`

```text
Is there an apple on the table? Yes, there is. Are there many students? No, there aren’t.
```

### L01-082 — رها — fa

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-082.weba`
- voice: `coral`
- slot: `data-audio-id="L01-082"`
- SHA256 متن UTF-8: `1f3e0d1841edb22d0bdacbd60ba21a6ad723068c8c2ad836832ff5548cf92fd7`

```text
پس در He is kind و There is a book هر دو is داریم، ولی کاربردشان یکی نیست؟
```

### L01-083 — آرتین — fa

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-083.weba`
- voice: `sage`
- slot: `data-audio-id="L01-083"`
- SHA256 متن UTF-8: `86c0cc4871e7e73cf5b3e43baef13681e9bc7be7115c71966074455b2853ea70`

```text
در He is kind دربارهٔ ویژگیِ فرد شناخته‌شده حرف می‌زنیم؛ در There is a book وجود یک کتاب را معرفی می‌کنیم. پیش از صفتِ تنها a نمی‌گذاریم، ولی book یک اسم شمارش‌پذیر مفرد است و a می‌خواهد.
```

### L01-084 — آرتین — en

- بخش: There is / There are؛ گفتنِ «وجود دارد» (`existence`)
- کادر: متن اصلی
- فایل: `L01-084.weba`
- voice: `sage`
- slot: `data-audio-id="L01-084"`
- SHA256 متن UTF-8: `e4bdc2329ee098dac4af73a6d2cc8fda7c219fa1fcb82ec65929492fbcec17dc`

```text
He is kind. There is a kind student in our class. There are two kind students in our class.
```

### L01-085 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-085.weba`
- voice: `sage`
- slot: `data-audio-id="L01-085"`
- SHA256 متن UTF-8: `a923ba4cd26aeab433d127a05a406d84f6ea4d3e63d49c656ef45b3585123643`

```text
نشانه‌های بین دو خط مورب راهنمای آوایی‌اند، نه املای تازه. علامت ˈ پیش از هجای پُرتکیه می‌آید. تلفظ فارسی‌نویسی نشده، چون صداهایی مثل th و واکه‌های انگلیسی را دقیق منتقل نمی‌کند. برای هر واژه، اول شکل آهسته و سپس نمونهٔ طبیعی را بشنو؛ بعد بدون نگاه کردن تکرار کن.
```

### L01-086 — آرتین — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-086.weba`
- voice: `sage`
- slot: `data-audio-id="L01-086"`
- SHA256 متن UTF-8: `05b7bad6ff05abb0ca4b3c2a25cf7df388247d48f1e50239b7d01cb6400a1f7b`

```text
We. Very. We. Very. Three. They. There. Kind. Shy. Brave. Patient. Neat. Selfish. Hard-working.
```

### L01-087 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-087.weba`
- voice: `sage`
- slot: `data-audio-id="L01-087"`
- SHA256 متن UTF-8: `819f525ddf724bda05c5fe4dec978d7f6d06da6fb9884aa98f6d1a9e2ad4a47e`

```text
در patient، صدای بخش میانی ش است؛ آن را بر اساس حروف جداگانه نخوان. quiet دو هجا دارد؛ quite واژهٔ دیگری است. funny در هجای اول تکیه دارد، polite در هجای دوم. هدف وضوح و فهم‌پذیری است، نه شبیه شدن اجباری به یک فرد خاص.
```

### L01-088 — آرتین — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-088.weba`
- voice: `sage`
- slot: `data-audio-id="L01-088"`
- SHA256 متن UTF-8: `e4685fd615dad30aa3bd9e815aba1a56fcbd10be6fe75085ad00f5eeb7598073`

```text
Patient. Quiet. Funny. Polite. Generous. Nervous. Helpful. Talkative.
```

### L01-089 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-089.weba`
- voice: `sage`
- slot: `data-audio-id="L01-089"`
- SHA256 متن UTF-8: `793ec8cda14559379a461b81bf0855005dc327a35f6d6c62ba41dddec34847ec`

```text
موضوع آهنگ در این درس، افتان بودن جمله‌های خبریِ مثبت است. روی کلمهٔ مهم تکیه بگذار و در پایان صدا را آرام پایین بیاور. افتان یعنی افتِ زیر و بمی، نه کم کردن سرعت یا بلندی تا حد نامفهوم شدن. سؤال‌های بله یا خیر اغلب آهنگ خیزان دارند؛ فعلاً تمرکز اصلی ما جملهٔ خبری است.
```

### L01-090 — آرتین — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-090.weba`
- voice: `sage`
- slot: `data-audio-id="L01-090"`
- SHA256 متن UTF-8: `24ebd823f95cc105d6b9bc060ebf353802f43220abf975b50c79af6ddbb97c3f`

```text
He’s very kind. She’s very patient. You are very clever. Everybody likes her. I do my homework. She works for a company.
```

### L01-091 — Teacher — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-091.weba`
- voice: `sage`
- slot: `data-audio-id="L01-091"`
- SHA256 متن UTF-8: `f306e9d9cb0c0b5f1987a816d6337123c75ad8ba17a8d6bba6560dc109ee7be7`

```text
Farzaneh is a clever student. Everybody likes her.
```

### L01-092 — Samira — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-092.weba`
- voice: `coral`
- slot: `data-audio-id="L01-092"`
- SHA256 متن UTF-8: `b81476247830a839bf54427a74b84b109c682fa5d41bceebc3ad71942400edfb`

```text
Yes. I know. She is also very helpful.
```

### L01-093 — Teacher — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-093.weba`
- voice: `sage`
- slot: `data-audio-id="L01-093"`
- SHA256 متن UTF-8: `0ec3c78e7792c180a2d0dea36050f64e5c302c9a9eaeeadab28a85b4bcb70902`

```text
Well, you can ask her for help.
```

### L01-094 — Samira — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-094.weba`
- voice: `coral`
- slot: `data-audio-id="L01-094"`
- SHA256 متن UTF-8: `cafc119d8eb3cad1d8245a23bee786c628399e79f2a001f3095f410dbbb75610`

```text
Ok, I’ll ask her to help me with my English.
```

### L01-095 — آرتین — en

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: متن اصلی
- فایل: `L01-095.weba`
- voice: `sage`
- slot: `data-audio-id="L01-095"`
- SHA256 متن UTF-8: `8ae16005e398b7ad066083e0bf6abf5e02bcb8cd74cfdbcb434317f74088352d`

```text
Let me check it in the dictionary.
```

### L01-151 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: تمرین سایه‌خوانی و خودسنجی
- فایل: `L01-151.weba`
- voice: `sage`
- slot: `data-audio-id="L01-151"`
- SHA256 متن UTF-8: `798753b47064658b00fb4931db520be3f08e691283908d618b57a957d8726602`

```text
یک جملهٔ کوتاه انتخاب کن؛ فقط گوش بده.
```

### L01-152 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: تمرین سایه‌خوانی و خودسنجی
- فایل: `L01-152.weba`
- voice: `sage`
- slot: `data-audio-id="L01-152"`
- SHA256 متن UTF-8: `f31c3bf7a8b4e5bf6a7333df36969c075d73489a474cd9d9c3eea45b84abd3ea`

```text
دوباره پخش کن؛ کمی پس از گوینده همان جمله را بگو.
```

### L01-153 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: تمرین سایه‌خوانی و خودسنجی
- فایل: `L01-153.weba`
- voice: `sage`
- slot: `data-audio-id="L01-153"`
- SHA256 متن UTF-8: `2326e486cd79dcf1cdb333b9e699871b5eaeafb96bb04bf0e033e043183e7969`

```text
صوت را متوقف کن و جمله را مستقل اجرا کن.
```

### L01-154 — آرتین — fa

- بخش: آزمایشگاه تلفظ؛ صدا، تکیه و آهنگ (`pronunciation`)
- کادر: تمرین سایه‌خوانی و خودسنجی
- فایل: `L01-154.weba`
- voice: `sage`
- slot: `data-audio-id="L01-154"`
- SHA256 متن UTF-8: `671a3827dc2bdcb685ab244f088663b6d32308ff3031519afa8dd9fd9775606f`

```text
با ابزار ضبط تلفن یا دکمهٔ ضبط این بخش، اجرای خود را بشنو. آیا kind واضح بود؟ پایان جمله افت داشت؟ یک بار دیگر فقط همان مشکل را اصلاح کن.
```

### L01-125 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-125.weba`
- voice: `sage`
- slot: `data-audio-id="L01-125"`
- SHA256 متن UTF-8: `4a858a8ecdd83327d6164525de9eea31bab5b57e694563d0c20db9e9ad2482ff`

```text
در helpful و careful، بخش آخر کوتاه و بی‌تکیه است. اگر ful را مثل واژهٔ مستقل full محکم بگویی، ریتم کلمه عوض می‌شود. تکیه را روی هجای اول نگه دار؛ بخش پایانی را سبک تمام کن.
```

### L01-126 — آرتین — en

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-126.weba`
- voice: `sage`
- slot: `data-audio-id="L01-126"`
- SHA256 متن UTF-8: `fa6d5d8373331697973c1e0f25be93c016ad29760c459a2b34341d683c720ef2`

```text
Helpful. Careful. A helpful friend. A careful student.
```

### L01-127 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-127.weba`
- voice: `sage`
- slot: `data-audio-id="L01-127"`
- SHA256 متن UTF-8: `cfb35632cd3141de1a8e178ad85824cb8116426c14f2c1dc7ee9f9eaba578f93`

```text
در hard-working، پس از صدای آخر hard مستقیم به صدای آغاز working برو. میان این دو بخش واکهٔ اضافی نگذار. در پایان working، زبان عقب دهان بسته می‌شود؛ صدای گ جداگانه‌ای پس از آن نیاور.
```

### L01-128 — آرتین — en

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-128.weba`
- voice: `sage`
- slot: `data-audio-id="L01-128"`
- SHA256 متن UTF-8: `db50649e13f21134de036de0cdb59ef7e92e9b706c685639a383dabd6a2f0e9a`

```text
Hard-working. He is hard-working. They are hard-working students.
```

### L01-129 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-129.weba`
- voice: `sage`
- slot: `data-audio-id="L01-129"`
- SHA256 متن UTF-8: `468cd929e025a514be7c04130aaa1d332414877f01e24ac2af2456314b6afd63`

```text
در quiet، صدای آغاز با لب گرد ساخته می‌شود و سپس زبان به واکهٔ اول می‌رود. واژه دو هجا دارد. quite یک هجا دارد و واژهٔ دیگری است؛ این دو را از روی تعداد هجا تشخیص بده.
```

### L01-130 — آرتین — en

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-130.weba`
- voice: `sage`
- slot: `data-audio-id="L01-130"`
- SHA256 متن UTF-8: `a0f7407605d8fa89de0eb16f3d9978d9cf8473c186df23469545f1a5906b1771`

```text
Quiet. Quite. She is quiet. A quiet classroom.
```

### L01-131 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-131.weba`
- voice: `sage`
- slot: `data-audio-id="L01-131"`
- SHA256 متن UTF-8: `e2f294f9fa4450f529c83eae73725fc8d86224b11af73c2536a3cac356e9137c`

```text
در nervous، هجای اول برجسته است؛ در polite، هجای دوم برجسته می‌شود. بلند گفتن همهٔ هجاها تشخیص واژه را دشوار می‌کند. یک بار فقط هجای برجسته را پیدا کن، سپس کل عبارت را با همان ریتم بگو.
```

### L01-132 — آرتین — en

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-132.weba`
- voice: `sage`
- slot: `data-audio-id="L01-132"`
- SHA256 متن UTF-8: `e00bdc979f7bc8cb86939d9bb35476029c7128e76ece90b301ddd25c39f96b38`

```text
Nervous. Polite. He is nervous. She is polite.
```

### L01-133 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-133.weba`
- voice: `sage`
- slot: `data-audio-id="L01-133"`
- SHA256 متن UTF-8: `6b8ffce3c5802b5a8f85f4f1b9caec097d6d14d08ae2c10f0fba92a87aeab6ae`

```text
در He’s very kind، شکل He’s را یک واحد کوتاه بگو؛ حروف آن را جداگانه نخوان. در پاسخ Yes, he is، فعل پایانی کامل می‌ماند. روی ویژگی اصلی جمله تکیه بگذار؛ پس از هر واژه مکث جداگانه نساز.
```

### L01-134 — آرتین — en

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: متن اصلی
- فایل: `L01-134.weba`
- voice: `sage`
- slot: `data-audio-id="L01-134"`
- SHA256 متن UTF-8: `7cebf732d5872595f5679261202d74362ab94871d7988104f7b86a0dee324af4`

```text
He’s very kind. Is he kind? Yes, he is. They’re very helpful.
```

### L01-155 — آرتین — fa

- بخش: نکات تلفظی ویژهٔ درس ۱؛ از واژه تا جمله (`pronunciation-tips`)
- کادر: تمرین شنیدن و اصلاحِ یک خطای مشخص
- فایل: `L01-155.weba`
- voice: `sage`
- slot: `data-audio-id="L01-155"`
- SHA256 متن UTF-8: `0f369d0a289c0f39da83a11f26a348018c748d440c570da8ae57b26022577700`

```text
یکی از پنج نمونه را پخش کن و اجرای خودت را ضبط کن. فقط همان نکته را مقایسه کن: تکیه، تعداد هجا یا صدای پایانی. پس از اصلاح، همان واژه را در جمله‌ای با نام یک دوست فرضی به کار ببر.
```

### L01-096 — آرتین — en

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: متن اصلی
- فایل: `L01-096.weba`
- voice: `sage`
- slot: `data-audio-id="L01-096"`
- SHA256 متن UTF-8: `7f947aac1d88d009e27dbb8febec11bbe78fc153a19701ff45efb3acdce5e8a2`

```text
I’m Mohsen. This is my classroom. There are 25 students in my class. I have a lot of friends. My best friend is Vahid. He’s a good student. He is helpful and hard-working, but he is not very careful. He usually forgets important things. It’s a big problem.
```

### L01-156 — آرتین — fa

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: ترجمهٔ دقیق متن
- فایل: `L01-156.weba`
- voice: `sage`
- slot: `data-audio-id="L01-156"`
- SHA256 متن UTF-8: `ba82e8afc22bbaef17ff9c2e1d3595cb146ccaa5ceb01092c2e4c00fcd376391`

```text
من محسن هستم. این کلاس من است. در کلاسم ۲۵ دانش‌آموز هستند. دوستان زیادی دارم. بهترین دوستم وحید است. او دانش‌آموز خوبی است. او یاری‌رسان و سخت‌کوش است، اما خیلی بادقت نیست. معمولاً چیزهای مهم را فراموش می‌کند. این یک مشکل بزرگ است.
```

### L01-097 — آرتین — fa

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: متن اصلی
- فایل: `L01-097.weba`
- voice: `sage`
- slot: `data-audio-id="L01-097"`
- SHA256 متن UTF-8: `286293c3b07b271fcab04d22e155e3d6d3dc64b1b989729e808e8b24cb2617a7`

```text
متن را در دو دور بخوان: بار اول نام دوست و دو ویژگی مثبتش را پیدا کن. بار دوم فقط شکل‌های am، is و are را مشخص کن. در I’m، am پنهان شده و در He’s و It’s، is کوتاه شده است. have و forgets فعل‌اند، ولی از خانوادهٔ be نیستند.
```

### L01-157 — آرتین — fa

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: کلید Find it، پس از تلاش خودت
- فایل: `L01-157.weba`
- voice: `sage`
- slot: `data-audio-id="L01-157"`
- SHA256 متن UTF-8: `4e4d3a459d7dd3a76ee27631ccd180ada0225f4a46f09edd09e621f6da914c10`

```text
۹ مورد به ترتیب: I’m (am), is, are, is, He’s (is), is, is, is, It’s (is). در عبارت he is not very careful فقط is فعل be است. have و forgets را انتخاب نکن.
```

### L01-158 — آرتین — en

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: الگو و چک‌لیست نوشتن
- فایل: `L01-158.weba`
- voice: `sage`
- slot: `data-audio-id="L01-158"`
- SHA256 متن UTF-8: `57a621b730165e6dc24e3eec609e038fab0edebfd4c4ecf9d4a5d11bf4f7c546`

```text
I am a bit quiet. My sister is helpful. My father is patient. My friends are friendly. We are happy.
```

### L01-159 — آرتین — fa

- بخش: متن خواندنی؛ پیدا کردن be و استناد به متن (`reading`)
- کادر: الگو و چک‌لیست نوشتن
- فایل: `L01-159.weba`
- voice: `sage`
- slot: `data-audio-id="L01-159"`
- SHA256 متن UTF-8: `a07aefff579ddd1661188ba397b3787112482aaab8ef267385c8c88fa09da512`

```text
نمونهٔ تألیفی است؛ دربارهٔ زندگی خودت مجبور نیستی اطلاعات خصوصی بنویسی. فاعل روشن، فعل هماهنگ، صفت درست، حرف بزرگ و نقطه را بررسی کن.
```

### L01-098 — آرتین — fa

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن اصلی
- فایل: `L01-098.weba`
- voice: `sage`
- slot: `data-audio-id="L01-098"`
- SHA256 متن UTF-8: `b971d79433e0c82f373a47b17a911ac6bede0251dca83b862e9f38a97a641d03`

```text
صفحهٔ ۲۴ جدولی برای نام و شخصیت دارد، اما متن ضبط‌شدهٔ رسمی در PDF نیست. برای تمرین همین مهارت، گفت‌وگوی تازهٔ زیر آماده شده است. در دور اول فقط نام‌ها را بنویس؛ در دور دوم ویژگی‌ها را کامل کن. متن زیرنویس تا وقتی خودت بازش نکنی پنهان می‌ماند.
```

### L01-099 — Mina — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن شنیداری A؛ بعد از تلاش باز کن
- فایل: `L01-099.weba`
- voice: `coral`
- slot: `data-audio-id="L01-099"`
- SHA256 متن UTF-8: `68876b798b22f0ce34e50116bfbfd6b6223018d04d4589d12c21062927b5dd9c`

```text
Who is your best friend?
```

### L01-100 — Sara — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن شنیداری A؛ بعد از تلاش باز کن
- فایل: `L01-100.weba`
- voice: `nova`
- slot: `data-audio-id="L01-100"`
- SHA256 متن UTF-8: `5986d3ef13b280a53b18d63140f367f3f45e0a06f41d06c20484eeafbe782e82`

```text
My best friend is Neda. She is quiet and patient.
```

### L01-101 — Mina — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن شنیداری A؛ بعد از تلاش باز کن
- فایل: `L01-101.weba`
- voice: `coral`
- slot: `data-audio-id="L01-101"`
- SHA256 متن UTF-8: `91958e082caf13e8407c6cf01b67d4c6894c339611add23bbac0b4047754cc96`

```text
Is she helpful too?
```

### L01-102 — Sara — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن شنیداری A؛ بعد از تلاش باز کن
- فایل: `L01-102.weba`
- voice: `nova`
- slot: `data-audio-id="L01-102"`
- SHA256 متن UTF-8: `5b600b96b43b838271c4b63fb7b2640b9379e5511e00f1f11bd019c01fee3e54`

```text
Yes, she is. My brother, Amir, is helpful too, but he is a bit talkative.
```

### L01-103 — آرتین — fa

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن اصلی
- فایل: `L01-103.weba`
- voice: `sage`
- slot: `data-audio-id="L01-103"`
- SHA256 متن UTF-8: `29a9417d62051844af91d35b91d58bfced00e110c99312a2cb3cbc2ed257cb7e`

```text
در فعالیت B باید کشور را توصیف کنی و ویژگی‌های مردم را از صوت برداری. متن تألیفی زیر فقط یک توصیف مثبت آموزشی است؛ ویژگی‌های فردیِ همهٔ مردم یک کشور یکسان نیست. دو بار گوش بده و یک صفت برای کشور و چهار صفت برای مردم بنویس.
```

### L01-104 — آرتین — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: متن شنیداری B؛ پس از پاسخ باز کن
- فایل: `L01-104.weba`
- voice: `sage`
- slot: `data-audio-id="L01-104"`
- SHA256 متن UTF-8: `fa4b4bfcf299e29ef0d4aa93b0ae10f49e9b26948c72fe19ae6de30a6fbf609d`

```text
Iran is a beautiful country. Many Iranian people are kind, friendly, helpful, and generous. Of course, people have different personalities.
```

### L01-160 — آرتین — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: کلید فعالیت‌های شنیداری تألیفی
- فایل: `L01-160.weba`
- voice: `sage`
- slot: `data-audio-id="L01-160"`
- SHA256 متن UTF-8: `8b332d8e06d4c5ac94c6393b9bc3febaba24a0629c71ed416305e570e38b5508`

```text
A: Neda: quiet, patient, helpful. Amir: helpful, a bit talkative.
```

### L01-161 — آرتین — en

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: کلید فعالیت‌های شنیداری تألیفی
- فایل: `L01-161.weba`
- voice: `sage`
- slot: `data-audio-id="L01-161"`
- SHA256 متن UTF-8: `dde36ba9cb3cb709e8097992ab48733b63b968149f2a6b3dcb613fdcf65ed553`

```text
B: beautiful; kind, friendly, helpful, generous.
```

### L01-162 — آرتین — fa

- بخش: شنیداری‌های هدفمند؛ شنیدن، ثبت و نتیجه‌گیری (`listening`)
- کادر: کلید فعالیت‌های شنیداری تألیفی
- فایل: `L01-162.weba`
- voice: `sage`
- slot: `data-audio-id="L01-162"`
- SHA256 متن UTF-8: `da9d6bba5c72bdc0ce94295a9df46aa1747252966793211cce76290bc818721a`

```text
اگر نام‌ها را گرفتی ولی صفت‌ها را جا انداختی، فقط نوبت سارا را تکرار کن. اگر صفت‌ها آشنا نبودند، به کارت همان واژه برگرد.
```

### L01-105 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-105.weba`
- voice: `sage`
- slot: `data-audio-id="L01-105"`
- SHA256 متن UTF-8: `4da6a19c73bdcef1db9cef3cc553fdb5e79a05fd3d75d7aafb8903cd7262b578`

```text
در صفحهٔ ۲۶، هر پرسش را از یک هم‌کلاسی بپرس و جوابش را ثبت کن؛ اگر تنها درس می‌خوانی، نقش هر دو نفر را اجرا کن. برای سؤال Who is brave? نام یا گروه اسمی لازم است؛ برای What’s your father like? یک یا چند ویژگی لازم است.
```

### L01-106 — آرتین — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-106.weba`
- voice: `sage`
- slot: `data-audio-id="L01-106"`
- SHA256 متن UTF-8: `230ff7ba04de5c53ad1088eadb915f67addf1866d8f026c629d58682b4ba2574`

```text
Are you brave? Is your brother talkative? Are your family members neat? Who is brave? Who is friendly? What’s your father like?
```

### L01-163 — آرتین — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: پاسخ‌های نمونهٔ مصاحبه
- فایل: `L01-163.weba`
- voice: `sage`
- slot: `data-audio-id="L01-163"`
- SHA256 متن UTF-8: `278ed218223d68fd45ddebbba2b524719de80a794c82f3e259e0ca98da960495`

```text
1. Yes, I am. 2. No, he isn’t. 3. Yes, they are. 4. My sister is brave. 5. My teacher is friendly. 6. He is patient and helpful.
```

### L01-164 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: پاسخ‌های نمونهٔ مصاحبه
- فایل: `L01-164.weba`
- voice: `sage`
- slot: `data-audio-id="L01-164"`
- SHA256 متن UTF-8: `e9ef12e50708eb830fdb401c1c7305ca3712bc3f61efff588cde3f6125faaa4a`

```text
جواب‌های شخصی تو می‌توانند متفاوت و درست باشند. نسبت خویشاوندی و ضمیر پاسخ را هماهنگ کن.
```

### L01-107 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-107.weba`
- voice: `sage`
- slot: `data-audio-id="L01-107"`
- SHA256 متن UTF-8: `50c2ba544174dda4d014b3fa1c57f3d47c439737145b84c65f7154fe6aa3b0c2`

```text
برای نقش‌آفرینی صفحهٔ ۲۷، یک دوست، هم‌کلاسی، معلم یا خویشاوند را انتخاب کن. هدف، معرفی قابل‌فهم و گرفتن اطلاعات است. حداقل یک پرسش باز، یک پرسش بله یا خیر و یک پاسخ با دو صفت داشته باش. سپس نقش‌ها را عوض کن.
```

### L01-108 — Mina — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-108.weba`
- voice: `coral`
- slot: `data-audio-id="L01-108"`
- SHA256 متن UTF-8: `08a8f04e487d62cad6ad9877371f27e8fe58efc334a063206491bef8dd31fbac`

```text
Who is your new classmate?
```

### L01-109 — Sara — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-109.weba`
- voice: `nova`
- slot: `data-audio-id="L01-109"`
- SHA256 متن UTF-8: `fd656b98f46d5bc237224b6cbf04c64d453238a028c30fbe4270a68a6d21d596`

```text
Her name is Hasti.
```

### L01-110 — Mina — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-110.weba`
- voice: `coral`
- slot: `data-audio-id="L01-110"`
- SHA256 متن UTF-8: `0e6d9ec1a5ff4a28307f227048b30e201850f3584a5c7cc337f752818f78c5c2`

```text
What’s she like?
```

### L01-111 — Sara — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-111.weba`
- voice: `nova`
- slot: `data-audio-id="L01-111"`
- SHA256 متن UTF-8: `5c8d23b97359923dbeb6d1fe1303ff523a108785dadbd9ed3b30053d59af652a`

```text
She’s friendly and careful.
```

### L01-112 — Mina — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-112.weba`
- voice: `coral`
- slot: `data-audio-id="L01-112"`
- SHA256 متن UTF-8: `7fb59b2db3b82dec656bbd6ec02276bfb3de7a7c5433ce495f8ba695d3fbdfa3`

```text
Is she talkative?
```

### L01-113 — Sara — en

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: متن اصلی
- فایل: `L01-113.weba`
- voice: `nova`
- slot: `data-audio-id="L01-113"`
- SHA256 متن UTF-8: `007449ff9312086dca4f0372975e26c21622987c9d951435987165812390a1a8`

```text
No, she isn’t. She’s a bit quiet.
```

### L01-165 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: سه سطحِ اجرا
- فایل: `L01-165.weba`
- voice: `sage`
- slot: `data-audio-id="L01-165"`
- SHA256 متن UTF-8: `bbda76ab7d37305e508ca8c9fa76beeb019e50af24f5108c1865c7d6144c18c5`

```text
آغاز: فقط اسم و صفت‌ها را جایگزین کن و از الگو کمک بگیر.
```

### L01-166 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: سه سطحِ اجرا
- فایل: `L01-166.weba`
- voice: `sage`
- slot: `data-audio-id="L01-166"`
- SHA256 متن UTF-8: `286a464043ff58e84da4a15368e35957dfe3f6b138ec277b85b69ff0aaa90b4a`

```text
میانی: بدون دیدن متن، چهار پرسش و پاسخ بساز؛ یکی از جواب‌ها منفی باشد.
```

### L01-167 — آرتین — fa

- بخش: مصاحبه و ایفای نقش؛ گفتار با هدف (`roleplay`)
- کادر: سه سطحِ اجرا
- فایل: `L01-167.weba`
- voice: `sage`
- slot: `data-audio-id="L01-167"`
- SHA256 متن UTF-8: `5e0c968cee4259b0d67a36f89b74ff13999e3bde40f13b6ea22e20fc1be1b389`

```text
پیشرفته: دو شخصیت را با but مقایسه کن و برای helpful بودن یک رفتار شاهد بیاور؛ از متنی که کتاب نگفته، نقل قول نساز.
```

### L01-114 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-114.weba`
- voice: `sage`
- slot: `data-audio-id="L01-114"`
- SHA256 متن UTF-8: `a8fd8ecebf3124bb52a08011b2dcf2bb6558f9ea76da5d44209cbf5992349253`

```text
می‌خواهی بگویی «من خجالتی نیستم، ولی کمی کم‌حرفم». ابتدا I و شکل am را انتخاب می‌کنی؛ برای منفی not می‌گذاری.
```

### L01-115 — آرتین — en

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-115.weba`
- voice: `sage`
- slot: `data-audio-id="L01-115"`
- SHA256 متن UTF-8: `93abd32df4d8ddf20d56d14603fb6a2565cea0f41e06ca1a814891c225bcd7f9`

```text
I’m not shy, but I’m a bit quiet.
```

### L01-168 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: تحلیل پاسخ
- فایل: `L01-168.weba`
- voice: `sage`
- slot: `data-audio-id="L01-168"`
- SHA256 متن UTF-8: `8dded5102d57b95ccfa55576df909074012a8c9adadf955a9b4ffc301e61fae0`

```text
کم‌حرف بودن همیشه خجالتی بودن نیست؛ دو ویژگی را با but مقایسه کردیم.
```

### L01-116 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-116.weba`
- voice: `sage`
- slot: `data-audio-id="L01-116"`
- SHA256 متن UTF-8: `da1ff8474cfaa3f9af53e7fd175fa6298fb0683b53b5afe358bad8a11b514b0e`

```text
دربارهٔ دو دوست، یاسمن و نرگس، می‌پرسی آیا سخت‌کوش‌اند. دو نام یعنی they؛ پس پرسش با Are آغاز می‌شود.
```

### L01-117 — آرتین — en

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-117.weba`
- voice: `sage`
- slot: `data-audio-id="L01-117"`
- SHA256 متن UTF-8: `629785352f9036ab8b540282f1ec91dbbdb9024bee09b03d2e29a74e70423c7d`

```text
Are Yasaman and Narges hard-working? Yes, they are.
```

### L01-169 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: تحلیل پاسخ
- فایل: `L01-169.weba`
- voice: `sage`
- slot: `data-audio-id="L01-169"`
- SHA256 متن UTF-8: `51a2c86cba3519b45175f73d2f2ae0cd66dea61845a16692b1516de0b3e37c9f`

```text
در پاسخ کوتاه، دو نام با they جایگزین شدند و are کامل ماند.
```

### L01-118 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-118.weba`
- voice: `sage`
- slot: `data-audio-id="L01-118"`
- SHA256 متن UTF-8: `d847c152e2057709791599f3a96e6b5aaff011edaf4130596d50d4752a6ba52a`

```text
می‌خواهی بگویی در کلاس دو دانش‌آموز یاری‌رسان هستند. فاعل معرفی وجود، There و اسم students جمع است.
```

### L01-119 — آرتین — en

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-119.weba`
- voice: `sage`
- slot: `data-audio-id="L01-119"`
- SHA256 متن UTF-8: `f5fd2498d1d43507f7657ee1f9306cd865c6043d36d613a7b87f843d7e41d880`

```text
There are two helpful students in our class.
```

### L01-170 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: تحلیل پاسخ
- فایل: `L01-170.weba`
- voice: `sage`
- slot: `data-audio-id="L01-170"`
- SHA256 متن UTF-8: `1e0942add7a1379904713cc46de96d9c685165c6ece544d9d25a58d1bedeee16`

```text
helpful قبل از اسم آمده، ولی s نگرفته است. students علامت جمع دارد.
```

### L01-120 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-120.weba`
- voice: `sage`
- slot: `data-audio-id="L01-120"`
- SHA256 متن UTF-8: `aa5be71c4f9a8b38c1b90b146d0a1a03737f0be64cd98017c55924469c7508f7`

```text
دوستت باهوش است اما گاهی بی‌دقتی می‌کند. یک وصف مثبت و یک محدودیت را بدون برچسب‌زدن کلی به فرد بیان کن.
```

### L01-121 — آرتین — en

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: متن اصلی
- فایل: `L01-121.weba`
- voice: `sage`
- slot: `data-audio-id="L01-121"`
- SHA256 متن UTF-8: `86a13417ec6c9fa09fd8c6db5b809d05fb81b587bc596879af26f12add10d1db`

```text
He is clever, but he is sometimes careless.
```

### L01-171 — آرتین — fa

- بخش: مثال‌های تازه؛ انتقال یادگیری به موقعیت جدید (`examples`)
- کادر: تحلیل پاسخ
- فایل: `L01-171.weba`
- voice: `sage`
- slot: `data-audio-id="L01-171"`
- SHA256 متن UTF-8: `aa2dfa94b46658e4decdcb8fd40fe78a89e392176963dda61fb06d0edfc723b1`

```text
sometimes یعنی گاهی؛ پس از be قرار گرفته و قید تکمیلی این نمونه است.
```

### L01-172 — آرتین — fa

- بخش: تمرین مستقل؛ از تشخیص تا ساختن (`practice`)
- کادر: متن اصلی
- فایل: `L01-172.weba`
- voice: `sage`
- slot: `data-audio-id="L01-172"`
- SHA256 متن UTF-8: `85b27cfa1488114633c5da762d0ab9bf349d0fac6a4acb105175b7d21904051d`

```text
هر پاسخ خودکار همراه دلیل بررسی می‌شود. در پاسخ نوشتنی، تفاوت حروف بزرگ، نوع آپاستروف و نشانهٔ پایانی نادیده گرفته می‌شود؛ تغییر معنی یا فعل پذیرفته نمی‌شود. متن آزاد را با معیارهای پایین بسنج.
```

### L01-173 — آرتین — en

- بخش: تمرین مستقل؛ از تشخیص تا ساختن (`practice`)
- کادر: نمونهٔ تألیفی و معیار بازبینی
- فایل: `L01-173.weba`
- voice: `sage`
- slot: `data-audio-id="L01-173"`
- SHA256 متن UTF-8: `2b3a8d8c49e6fb8013634e240f5b6fd8562731888792198386a70a8c426d8946`

```text
My friends are Diba and Maryam. Diba is clever and quiet. She is not talkative. Maryam is friendly, but she is a bit careless. They are both helpful. There are two good friends in my class.
```

### L01-174 — آرتین — fa

- بخش: تمرین مستقل؛ از تشخیص تا ساختن (`practice`)
- کادر: نمونهٔ تألیفی و معیار بازبینی
- فایل: `L01-174.weba`
- voice: `sage`
- slot: `data-audio-id="L01-174"`
- SHA256 متن UTF-8: `86e314f9165c759b2489e2db350f30c3b7272057cac31ac9a5033a225c25187f`

```text
both یعنی هر دو؛ واژهٔ تکمیلی است. برای هر مورد یک امتیاز: معنی روشن، هماهنگی be، منفی درست، جملهٔ وجودی درست، نشانه‌گذاری. ۴ یا ۵: آمادهٔ آزمون؛ ۳ یا کمتر: فقط الگوی مشکل‌دار را مرور کن.
```

### L01-122 — آرتین — fa

- بخش: آزمون کوچک پایان درس؛ ۱۲ سؤال و دو عملکرد کوتاه (`exam`)
- کادر: متن اصلی
- فایل: `L01-122.weba`
- voice: `sage`
- slot: `data-audio-id="L01-122"`
- SHA256 متن UTF-8: `a9314f154ec33c2618a98ac105f016a431cb0ee1f1b1d14c687f274835529dd8`

```text
این بار پاسخ‌ها را تا زمان ثبت آزمون نمی‌بینی. حدود ده دقیقه برای دوازده سؤال کافی است. بعد از نتیجه، خطاها را بر اساس موضوع مرور کن؛ نمرهٔ گفتار و نوشتار را جدا از سؤال‌های خودکار ثبت می‌کنیم.
```

### L01-175 — آرتین — fa

- بخش: آزمون کوچک پایان درس؛ ۱۲ سؤال و دو عملکرد کوتاه (`exam`)
- کادر: متن اصلی
- فایل: `L01-175.weba`
- voice: `sage`
- slot: `data-audio-id="L01-175"`
- SHA256 متن UTF-8: `fd296e2bbaad831b2ad7691a5062e939f636cb0085fab767f12efe8c4fce25a7`

```text
امتیاز خودکار از ۱۲ است؛ معیارهای عملکردی جمعاً از ۸ هستند و با خودسنجی یا معلم ثبت می‌شوند. فایل، تلفظ یا متن آزاد را به‌صورت خودکار و قطعی تصحیح نمی‌کند. هدف پیشنهادی: حداقل ۱۰ از ۱۲ و حداقل ۶ از ۸.
```

### L01-123 — آرتین — fa

- بخش: مرور فاصله‌دار و کارت جمع‌بندی (`summary`)
- کادر: متن اصلی
- فایل: `L01-123.weba`
- voice: `sage`
- slot: `data-audio-id="L01-123"`
- SHA256 متن UTF-8: `c78df457fb181f7e5f3b70b2abe46d3c85ff8e7d125e08d62d036cd1a2e68d04`

```text
برای توصیف، فاعل و be و صفت را کنار هم بگذار. برای منفی، not پس از be؛ برای سؤال، be پیش از فاعل. What ... like? ویژگی می‌پرسد. There is و There are وجود چیزی را معرفی می‌کنند. در جواب کوتاه مثبت، be را کامل نگه دار.
```

### L01-124 — آرتین — en

- بخش: مرور فاصله‌دار و کارت جمع‌بندی (`summary`)
- کادر: متن اصلی
- فایل: `L01-124.weba`
- voice: `sage`
- slot: `data-audio-id="L01-124"`
- SHA256 متن UTF-8: `0db9a4b555a078e984ab9b6970371556f033b2f4857a7babbf8c62cf47890a1b`

```text
She is helpful. She is not selfish. Is she patient? Yes, she is. What’s she like? She’s kind. There are two students here.
```

### L01-177 — آرتین — fa

- بخش: مرور فاصله‌دار و کارت جمع‌بندی (`summary`)
- کادر: متن اصلی
- فایل: `L01-177.weba`
- voice: `sage`
- slot: `data-audio-id="L01-177"`
- SHA256 متن UTF-8: `f4be3cc7a7146b073c4dcb23d78a546b3294d075845ff03be4d986301959d0ba`

```text
یادداشت‌ها در همین مرورگر ذخیره می‌شوند، اگر مرورگر ذخیرهٔ محلی را اجازه دهد. هیچ پاسخ یا صدایی از این فایل به سرور ارسال نمی‌شود.
```

# راهنمای کامل تولید و تزریق صوت؛ درس 6 — سلامت و آسیب‌ها

تعداد قطعات: 157. این فایل تمام متن‌های گفتاری را دارد؛ ایجنت متن تازه ننویسد، تکرار یا خلاصه نکند. هر متن دقیقاً با p.tts-text در HTML برابر است. متن اصلی کتاب و شنیداری‌های تألیفی با هم اشتباه نشوند.

## پرامپت TTS

Read only the exact input. Do not add an introduction, summary, translation, music, or speaker label. Use fluent Iranian Persian for fa and clear General American English for en. Keep each character's voice fixed. Read dialogue as conversation. Use meaningful short pauses and a moderate teaching pace. Follow the delivery field for pronunciation and intonation. Never pronounce IDs, arrows or metadata.

## رابط و قرارداد فایل

نام مدرس آرتین و نام یادگیرنده رها است. کنترل ترجمه در همان ناحیه قرار دارد. همهٔ بخش‌های اصلی در منبع بسته‌اند؛ در اجرا فقط یکی باز و آخرین انتخاب ذخیره می‌شود. پنل فلوتر در وب‌ویو تمام‌صفحه است. هیچ پنل مدرس، تولید صوت، خوانش دستگاه، چاپ یا دانلود یادداشت به HTML اضافه نکن. هر آیکون داخل audio-block باید فقط صوت همان ID را پخش/مکث کند. پخش تازه باید صوت قبلی، از جمله ضبط شخصی، را متوقف کند.

متن‌های کادرهای کمکی، پاسخ‌های بازشونده و نکات تلفظی هم قطعات مستقل دارند. ترتیب clips ترتیب تدریس است؛ شماره‌ها را تغییر نده. برای هر قطعه یک فایل L06-NNN.weba و JSON منشأ لازم است. hash متن و فایل را کنترل کن؛ یکسان بودن نام فایل به‌تنهایی کافی نیست.

## کیفیت و حجم

ظرف WebM فقط صوتی، codec Opus، تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s و application=voip. تغییر پسوند MP3 به WebA تبدیل نیست. loudness هدف حدود -18 LUFS و true peak حداکثر -2 dBTP؛ اسکریپت از loudnorm تک‌مرحله‌ای استفاده می‌کند. خروجی را برای قطع نشدن کلمات، وضوح صداها و ثبات نقش‌ها بشنو. Base64 تقریباً یک‌سوم به حجم باینری اضافه می‌کند. موسیقی و افکت اضافه نکن.

## اجرا

نیازمند Python 3.10+، ffmpeg و ffprobe با libopus است. OPENAI_API_KEY فقط در محیطِ ایجنت تولیدکننده قرار بگیرد؛ در HTML و Markdown نوشته نشود. --generate درخواست شبکه‌ای هزینه‌دار دارد؛ --embed آفلاین است. در این تحویل هنوز صوت آموزشی نهایی تولید نشده است.

```bash
python tts_pipeline.py engl9-l06-health-and-injuries.html
python tts_pipeline.py engl9-l06-health-and-injuries.html --generate --only L06-001,L06-002 --audio-dir audio-l06
python tts_pipeline.py engl9-l06-health-and-injuries.html --generate --audio-dir audio-l06
python tts_pipeline.py engl9-l06-health-and-injuries.html --embed --audio-dir audio-l06 --output engl9-l06-health-and-injuries-with-audio.html
```

ابتدا فارسی و انگلیسی و دو نقشِ گفت‌وگو را نمونه‌گیری و شنیداری کنترل کن. صداهای سرویس مطابق voice هر قطعه‌اند؛ اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود. فایل خام را برای QA نگه دار. برای صوت وارداتی از ایجنت دیگر، پس از تطبیق انسانی متن می‌توان --accept-imports را هنگام embed به کار برد؛ این گزینه تشخیص خودکار صحت گفتار نیست.

```bash
ffmpeg -i source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L06-001.weba
```

## تزریق دقیق

manifest داخلی با id=tts-manifest را بخوان. اسکریپت متن HTML، SHA256 متن و SHA256 فایل را بررسی می‌کند. هر data-audio-id دقیقاً یک audio مخفی دارد. src آن باید data:audio/webm;codecs=opus;base64,... باشد. تمام صوت‌ها داخل همان HTML هستند؛ مسیر خارجی یا iframe نگذار. اسکریپت فایل ناقص را تحویل نمی‌دهد و منبع اصلی را بازنویسی نمی‌کند.

پس از تزریق، شمار audioهای دارای src باید با شمار manifest برابر باشد. یک بخش و یک کادر کمکی را باز کن؛ دکمه باید صوت همان قسمت را اجرا کند. پخش دو قسمت پشت‌سرهم باید اولی را قطع کند. شنیداری A و B بدون باز کردن متن قابل پخش‌اند. گوشی و دسکتاپ، سرعت، توقف، منوی تمام‌صفحه و حالت آفلاین را بررسی کن. تلفظ و نوبت دیالوگ به بازبینی انسانی نیاز دارند؛ آزمون فنیِ پخش به معنی تأیید تلفظ نیست.

## متن کامل قطعات

فقط متن کادر text را به سرویس بده؛ عنوان و metadata خوانده نشوند.

### L06-001 — آرتین — fa

- بخش: درس 6؛ سلامت و آسیب‌ها و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L06-001.weba`
- voice: `sage`
- slot: `data-audio-id="L06-001"`
- SHA256 متن UTF-8: `46faecef46c18e85c11b467e41161275442e319cc069015e04fe7db711c0846d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس «سلامت و آسیب‌ها» می‌آموزی یک حادثهٔ گذشته را با فعل‌های بی‌قاعده شرح بدهی، دربارهٔ زمان و علت آن بپرسی و مفعول را با ضمیر جایگزین کنی.
```

### L06-002 — آرتین — en

- بخش: درس 6؛ سلامت و آسیب‌ها و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L06-002.weba`
- voice: `sage`
- slot: `data-audio-id="L06-002"`
- SHA256 متن UTF-8: `d7182b94012fe416ce9e883222fcba75e16e6f0c7ed621e8332887e4ddd86cce`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Lesson 6. Health and Injuries. Use the language in a new situation.
```

### L06-134 — آرتین — fa

- بخش: درس 6؛ سلامت و آسیب‌ها و هدف یادگیری (`goals`)
- کادر: مسیر پیشنهادی همین درس
- فایل: `L06-134.weba`
- voice: `sage`
- slot: `data-audio-id="L06-134"`
- SHA256 متن UTF-8: `e12c8a9d29a0e1bc109e5409a0fda65bc4006929e89d06833874e889aac56bff`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پیش از شروعِ سلامت و آسیب‌ها، سنجش ورودی را انجام بده. کمتر از شش پاسخ درست از هشت یعنی مرور پل پیش‌نیاز لازم است. سپس به ترتیبِ فهرست پیش برو؛ پس از هر الگو، پاسخ خودت را پیش از باز کردن راه‌حل بساز.
```

### L06-003 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-003.weba`
- voice: `sage`
- slot: `data-audio-id="L06-003"`
- SHA256 متن UTF-8: `dd2532ba9f1372d4eaf527a7759d71962c87465154d55792b28c668012be60a5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از پایه‌های هفتم و هشتم، اعضای بدن، درخواست کمک و ضمیرهای فاعلی را لازم داری. از درس پنج، سؤال و منفی با did و وضعیت گذشته با was/were را مرور می‌کنیم؛ اینجا مهم است بعد از did دوباره فعل گذشته نیاوری.
```

### L06-004 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-004.weba`
- voice: `sage`
- slot: `data-audio-id="L06-004"`
- SHA256 متن UTF-8: `e15c74270ce7b55036e0c4bca16cf13f29a965c3132eb87bd1d2004aff19a357`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گذشتهٔ باقاعده، به فعل ed می‌افزودی؛ فعل بی‌قاعده شکل جداگانه دارد. هر دو نوع در سؤال با did به شکل پایه برمی‌گردند.
```

### L06-005 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-005.weba`
- voice: `sage`
- slot: `data-audio-id="L06-005"`
- SHA256 متن UTF-8: `468870f4fb60a7e773fe76032dd9d9e481464bcf4c7cac7e2bf59cadb21d5d06`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She played. Did she play? She fell. Did she fall?
```

### L06-006 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-006.weba`
- voice: `sage`
- slot: `data-audio-id="L06-006"`
- SHA256 متن UTF-8: `cd4a5bf4e05740340bf1ebfd0e0b9c7e9f8c8bec95187bddbe2c334c530fc4e6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای گزارش حادثه، ترتیب اطلاعات را روشن کن: چه کسی، چه اتفاقی، کجا و چه وقت. واژه‌های دست، پا، سر و زانو را پیش از ساخت جمله بازیابی کن.
```

### L06-007 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-007.weba`
- voice: `sage`
- slot: `data-audio-id="L06-007"`
- SHA256 متن UTF-8: `01fd25b6b84c8a88588804e9b01b115f3222cfe881a32e5d395224eb25aae133`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Hand. Leg. Head. Knee. My brother hurt his knee yesterday.
```

### L06-008 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-008.weba`
- voice: `sage`
- slot: `data-audio-id="L06-008"`
- SHA256 متن UTF-8: `d144154d1fce7df8516269e11ec140935dd7c1bc13e353d96dececb7a6b205d8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فاعل انجام‌دهندهٔ کار است؛ مفعول کسی یا چیزی است که کار به او مربوط می‌شود. در He helped me، او کمک می‌کند و من کمک می‌گیرم.
```

### L06-009 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L06-009.weba`
- voice: `sage`
- slot: `data-audio-id="L06-009"`
- SHA256 متن UTF-8: `e2945e1a7cbb4312714eff8384b0554397b2d181c226f4e9f1b543a27256ce6b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He helped me. I helped him.
```

### L06-135 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L06-135.weba`
- voice: `sage`
- slot: `data-audio-id="L06-135"`
- SHA256 متن UTF-8: `766fb95cdca5374d4e6fe411d9f61aaf3a96454b66f81681838ba3b98fb245be`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فعل‌های watched و went را ببین؛ هر دو گذشته‌اند، اما یکی باقاعده است. برای هر دو با did سؤال بساز و بررسی کن که فعل اصلی دوباره به پایه برگشته باشد.
```

### L06-136 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L06-136.weba`
- voice: `sage`
- slot: `data-audio-id="L06-136"`
- SHA256 متن UTF-8: `468870f4fb60a7e773fe76032dd9d9e481464bcf4c7cac7e2bf59cadb21d5d06`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She played. Did she play? She fell. Did she fall?
```

### L06-010 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-010.weba`
- voice: `sage`
- slot: `data-audio-id="L06-010"`
- SHA256 متن UTF-8: `6dfef98e4390d965459ba98990c81f1607921c7c34a54b45c9c1c946610762e9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She burned her hand yesterday.
```

### L06-011 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-011.weba`
- voice: `sage`
- slot: `data-audio-id="L06-011"`
- SHA256 متن UTF-8: `53cb1f23bed474473f9611f43711e3c5cf0e31f86eafd4093a8cc81fbd9ee0dc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He broke his leg last winter.
```

### L06-012 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-012.weba`
- voice: `sage`
- slot: `data-audio-id="L06-012"`
- SHA256 متن UTF-8: `96e09b2f76c9b14a4ce507d49e07943732d65473d8290e918c1cc953d3fa6a78`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He hit his head on the door.
```

### L06-013 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-013.weba`
- voice: `sage`
- slot: `data-audio-id="L06-013"`
- SHA256 متن UTF-8: `e002b06c3ca1cd307416d32a0bcfe7c1629a99f6877d3e743b524a761de0b46c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
His finger is bleeding.
```

### L06-014 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-014.weba`
- voice: `sage`
- slot: `data-audio-id="L06-014"`
- SHA256 متن UTF-8: `f2dbe483dce076ad7f74253ab69c0be3f07770c7e9438830654af4a1425e263c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My knee hurts a lot.
```

### L06-015 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-015.weba`
- voice: `sage`
- slot: `data-audio-id="L06-015"`
- SHA256 متن UTF-8: `c10eabdb87d705b0ce690cb5a99e15a161372f82bd14c34350bdc6c5ee663eb9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She cut her finger this morning.
```

### L06-016 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-016.weba`
- voice: `sage`
- slot: `data-audio-id="L06-016"`
- SHA256 متن UTF-8: `402fd929fa1df1468006d7b433b8677aca55741f93ec332e98d44c116a5f95bf`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
There is a plaster on his finger.
```

### L06-017 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-017.weba`
- voice: `sage`
- slot: `data-audio-id="L06-017"`
- SHA256 متن UTF-8: `bcaeed3ca2ff5f30b98625f62e50f4ac85455ca54fe7ec107c6b948c316d19c4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I hurt my knee in the park.
```

### L06-018 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-018.weba`
- voice: `sage`
- slot: `data-audio-id="L06-018"`
- SHA256 متن UTF-8: `0cf2cffd85212815d91691a07e6f2700a15bc8ce3c0973423cf1ae851274dc08`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He takes care of his father.
```

### L06-019 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L06-019.weba`
- voice: `sage`
- slot: `data-audio-id="L06-019"`
- SHA256 متن UTF-8: `2e58d21e61d6943e2248c26968fc00186656ee3bbfe1ea15825e54a5cbe4a4fb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She has a bruise on her arm.
```

### L06-020 — Reza — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-020.weba`
- voice: `onyx`
- slot: `data-audio-id="L06-020"`
- SHA256 متن UTF-8: `66b51abdb59436435ae7cbcabca6fc3729a7807fc5a1c8ff015d187c05d3cb9c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We plan to go to the lake. Do you want to come?
```

### L06-021 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-021.weba`
- voice: `echo`
- slot: `data-audio-id="L06-021"`
- SHA256 متن UTF-8: `28e6d49a613fc1c013fe829b546e583430d68f3a948bd5c6683adfbe4af3b700`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I don’t think so. I don’t like school trips. Last summer I fell and broke my leg.
```

### L06-022 — Reza — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-022.weba`
- voice: `onyx`
- slot: `data-audio-id="L06-022"`
- SHA256 متن UTF-8: `1f4adf6b6d7d276910f480f7eef3926bd37f3332d46551c6d5e27aa928937105`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It sometimes happens. I twisted my ankle last winter. I stayed home for two weeks!
```

### L06-023 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-023.weba`
- voice: `echo`
- slot: `data-audio-id="L06-023"`
- SHA256 متن UTF-8: `e1a6599dc411d0cb7d3bf13e74731f60f1dad038e73a9a9eda9ee270ab84e861`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
That’s too bad! I didn’t know that.
```

### L06-024 — Reza — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-024.weba`
- voice: `onyx`
- slot: `data-audio-id="L06-024"`
- SHA256 متن UTF-8: `9c46a946ce53e9c4e0c94958116815c8ad13e4ae160d7f3e8bd2e1f980d79924`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yeah…, but after that, I participated in Helal-e-Ahmar first aid classes. I learned how to take care of myself.
```

### L06-025 — Ehsan — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-025.weba`
- voice: `echo`
- slot: `data-audio-id="L06-025"`
- SHA256 متن UTF-8: `ebc37b6b89270540514461f79347bf2fb20cda1c5ae08ecbe674047d67c5ba4d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I like that. Can you give me some advice?
```

### L06-026 — Reza — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L06-026.weba`
- voice: `onyx`
- slot: `data-audio-id="L06-026"`
- SHA256 متن UTF-8: `1976e7477a26b6802bad7bcaa8915ab5ac8cd493ee46a065ae282e58ac75015d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Sure!
```

### L06-137 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: اجرای گفت‌وگو بدون وابستگی به متن
- فایل: `L06-137.weba`
- voice: `sage`
- slot: `data-audio-id="L06-137"`
- SHA256 متن UTF-8: `a64192bf0d3648d368438566c54d436b779e638a79d641e91f83ae8f876e4f76`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در نقش‌آفرینی آسیب، دو کارت جدا برای حادثهٔ رضا و احسان بساز. وقتی نقش عوض می‌شود، زمان و عضو آسیب‌دیده را هم عوض کن؛ به‌جای حفظ متن، ترتیب اتفاق و نوع کمک را منتقل کن.
```

### L06-027 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-027.weba`
- voice: `sage`
- slot: `data-audio-id="L06-027"`
- SHA256 متن UTF-8: `6ae74ac2c591b937d1250c669b6d28da5b6a56a84b2a8a39ea5186d5a014c771`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did Mina have an accident?
```

### L06-028 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-028.weba`
- voice: `coral`
- slot: `data-audio-id="L06-028"`
- SHA256 متن UTF-8: `f222983a2fdfb67dc71f50cb0cf9cbf3efb82e18ee169987f52e01265c9f5a10`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, she did.
```

### L06-029 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-029.weba`
- voice: `sage`
- slot: `data-audio-id="L06-029"`
- SHA256 متن UTF-8: `e231ed9217e9b3d4d1324cc2a1512eed74d7956f17059aa27a7395911ab22f08`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did Ali cut his finger?
```

### L06-030 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-030.weba`
- voice: `coral`
- slot: `data-audio-id="L06-030"`
- SHA256 متن UTF-8: `1e6d072c6e566a4653cd14458383e3b91553988bc6a86d3bc07fddc8e6b73903`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, he didn’t.
```

### L06-031 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-031.weba`
- voice: `sage`
- slot: `data-audio-id="L06-031"`
- SHA256 متن UTF-8: `7d829dd18f42ba396f172355cbbfa7e11f76771574678e96a28ca58fbe11bbc0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you break your leg?
```

### L06-032 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-032.weba`
- voice: `coral`
- slot: `data-audio-id="L06-032"`
- SHA256 متن UTF-8: `715683b825e0beb668a630bcd2e89520e482aacfd7c7c5594f1ecdbf92aa7505`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I broke my leg.
```

### L06-033 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-033.weba`
- voice: `sage`
- slot: `data-audio-id="L06-033"`
- SHA256 متن UTF-8: `b7a6c01266dd3070ed55b738c6974c028db2fdf376812f68b13a77f8d4bd207e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you hurt your back?
```

### L06-034 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-034.weba`
- voice: `coral`
- slot: `data-audio-id="L06-034"`
- SHA256 متن UTF-8: `010a77cfa42cb98198d1d82056b30898abb2d7782567936068912b86f44c2c4e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, I didn’t hurt my back.
```

### L06-035 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-035.weba`
- voice: `sage`
- slot: `data-audio-id="L06-035"`
- SHA256 متن UTF-8: `5b302e07bbc1d499f39268e7caba4ebedd7604e0a705013845fc15e88a6fc87c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who had an accident?
```

### L06-036 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-036.weba`
- voice: `coral`
- slot: `data-audio-id="L06-036"`
- SHA256 متن UTF-8: `70de77b78d1cf1d9177c2833ddc402e110d3274c1dbdb9e9dc78fd484dbd1649`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Reza.
```

### L06-037 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-037.weba`
- voice: `sage`
- slot: `data-audio-id="L06-037"`
- SHA256 متن UTF-8: `0802faa2a2643c8430c9a307123f177598bf8fdb0a55a302b273edcdea61dc29`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did she break her leg?
```

### L06-038 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-038.weba`
- voice: `coral`
- slot: `data-audio-id="L06-038"`
- SHA256 متن UTF-8: `5509f48cc9e15912b8319c7dc5b5d25e676b59abd8a33083a9c1979208ceeea3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She broke her leg in the park.
```

### L06-039 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-039.weba`
- voice: `sage`
- slot: `data-audio-id="L06-039"`
- SHA256 متن UTF-8: `575df5a27f92caf85f97323da0721d2c3833950ddbd16700925039e082e07da0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How did Amir hurt his head?
```

### L06-040 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-040.weba`
- voice: `coral`
- slot: `data-audio-id="L06-040"`
- SHA256 متن UTF-8: `96e09b2f76c9b14a4ce507d49e07943732d65473d8290e918c1cc953d3fa6a78`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He hit his head on the door.
```

### L06-041 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-041.weba`
- voice: `sage`
- slot: `data-audio-id="L06-041"`
- SHA256 متن UTF-8: `5203ff06ce166908e511683b9381fb6733c44a196bb67f64008edf10ac086710`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why did they have an accident?
```

### L06-042 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L06-042.weba`
- voice: `coral`
- slot: `data-audio-id="L06-042"`
- SHA256 متن UTF-8: `0ba58b0c650830c7e424ba6a22e99e573f9449da929d3d70428efeb7214197a9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Because they drove fast.
```

### L06-043 — آرتین — fa

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-043.weba`
- voice: `sage`
- slot: `data-audio-id="L06-043"`
- SHA256 متن UTF-8: `cf0b76ff4b7ce3646e1df3f11d61f9320f6fa302dc48e2b9679b70e2898c4b79`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فعل بی‌قاعده با افزودن ed ساخته نمی‌شود. go به went و break به broke تبدیل می‌شود. شکل گذشته برای همهٔ فاعل‌ها یکسان است؛ he و they در این بخش تفاوتی ندارند.
```

### L06-044 — آرتین — en

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-044.weba`
- voice: `sage`
- slot: `data-audio-id="L06-044"`
- SHA256 متن UTF-8: `7c6c34645a8a955b8f06d9fa05c1b37154dc623f4d29994263fbaded49e38d16`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He went home. They went home. She broke her leg.
```

### L06-045 — آرتین — fa

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-045.weba`
- voice: `sage`
- slot: `data-audio-id="L06-045"`
- SHA256 متن UTF-8: `8f40102d1a224a6e1072f086db50606ebf1e84a5c2ddac440645077bfc179c47`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در سؤال و منفی، did یا didn’t گذشته را نشان می‌دهد و فعل اصلی به پایه برمی‌گردد. بنابراین Did he broke نادرست و Did he break درست است.
```

### L06-046 — آرتین — en

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-046.weba`
- voice: `sage`
- slot: `data-audio-id="L06-046"`
- SHA256 متن UTF-8: `2e96cd4537a2f7e656c479cdd21b44564b4280ad5f92e73151c8da29f8e20c10`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did he break his leg? He didn’t break his leg.
```

### L06-047 — آرتین — fa

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-047.weba`
- voice: `sage`
- slot: `data-audio-id="L06-047"`
- SHA256 متن UTF-8: `8ade45312ca6b118b4078b895f7181ad758952a34d3c7065b5f3bfc881ca781b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در cut و hit و hurt، شکل پایه و گذشته یکسان نوشته می‌شود. از نشانهٔ زمان و بافت کمک بگیر. در read، املای گذشته ثابت است اما تلفظ آن تغییر می‌کند.
```

### L06-048 — آرتین — en

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: متن اصلی
- فایل: `L06-048.weba`
- voice: `sage`
- slot: `data-audio-id="L06-048"`
- SHA256 متن UTF-8: `0506dd7a084521d1f37ed9cf50a5c2e98e6cd1269a1141bfbcf1acc48fbbb545`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I hurt my knee yesterday. She cut her finger. He read the book last night.
```

### L06-138 — آرتین — fa

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-138.weba`
- voice: `sage`
- slot: `data-audio-id="L06-138"`
- SHA256 متن UTF-8: `ac9e125aa6f92a0d7fb8be57b1b5a72a2dc40cb7e553d68a6aa80be3d6f63636`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای go، break و hurt سه جملهٔ گذشته بساز. تغییر نکردن hurt به معنی حال بودنِ اجباری نیست؛ یک نشانهٔ زمان اضافه کن. بعد برای هر جمله سؤال با did بنویس.
```

### L06-139 — آرتین — en

- بخش: گذشتهٔ بی‌قاعده؛ شکل را از معنی جدا نکن (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-139.weba`
- voice: `sage`
- slot: `data-audio-id="L06-139"`
- SHA256 متن UTF-8: `7c6c34645a8a955b8f06d9fa05c1b37154dc623f4d29994263fbaded49e38d16`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He went home. They went home. She broke her leg.
```

### L06-049 — آرتین — fa

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-049.weba`
- voice: `sage`
- slot: `data-audio-id="L06-049"`
- SHA256 متن UTF-8: `6b4f981a08d3f761b21093e7918965655e69d91a577656d212652249d319cf6f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای مکان می‌گویی Where did ... و برای علت Why did ... . در هر دو، فعل اصلی به پایه برمی‌گردد. جواب because باید علت مرتبط بدهد، نه فقط دوباره صورتِ حادثه را تکرار کند.
```

### L06-050 — آرتین — en

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-050.weba`
- voice: `sage`
- slot: `data-audio-id="L06-050"`
- SHA256 متن UTF-8: `0bbd45ffb2c9aed689700e8b05c5e5f93f247c64cfaaa9a26b6021f9a8e43a87`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did he fall? In the yard. Why did he fall? Because he didn’t see the step.
```

### L06-051 — آرتین — fa

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-051.weba`
- voice: `sage`
- slot: `data-audio-id="L06-051"`
- SHA256 متن UTF-8: `0dd8b5d9fbb76f4f2d909c827fcd062c05ab00b2ed861b254e0aef135da56f9f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
Who helped you? فاعلِ نامعلوم را می‌پرسد و فعل گذشته می‌ماند. Who did you help? مفعول را می‌پرسد؛ فاعل you معلوم است و did لازم است.
```

### L06-052 — آرتین — en

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-052.weba`
- voice: `sage`
- slot: `data-audio-id="L06-052"`
- SHA256 متن UTF-8: `67caa0c195cde5ff9154016fd81bb4dca78e689c4e2de992bb38f4c8eb29fc3e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helped you? My teacher. Who did you help? My friend.
```

### L06-053 — آرتین — fa

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-053.weba`
- voice: `sage`
- slot: `data-audio-id="L06-053"`
- SHA256 متن UTF-8: `dc7aa2ae21fa6faa87b254bca7a5d6f3233d195c315eea928c4bda8834e425f3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
وقتی دربارهٔ وضعیت گذشته حرف می‌زنی، was و were را نگه دار. پرسش Where were you? مکان تو را در گذشته می‌پرسد؛ Where did you go? مقصد رفتنت را می‌پرسد.
```

### L06-054 — آرتین — en

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: متن اصلی
- فایل: `L06-054.weba`
- voice: `sage`
- slot: `data-audio-id="L06-054"`
- SHA256 متن UTF-8: `0c5c6e5e9c447df6b8f2bb6735eebed72af68ef650b6e4ae66257b94a18b6ec6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where were you? At home. Where did you go? To school.
```

### L06-140 — آرتین — fa

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-140.weba`
- voice: `sage`
- slot: `data-audio-id="L06-140"`
- SHA256 متن UTF-8: `32720ba69dea15a71523c603f1da0caf4943874374e6d74a15a6c3ff55db760a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
با پاسخ‌های in the park، yesterday و my teacher سه پرسش دربارهٔ حادثه بساز. اگر سؤال دربارهٔ فاعل است، گذشتهٔ فعل را نگه دار و did اضافه نکن.
```

### L06-141 — آرتین — en

- بخش: پرسش از حادثه؛ زمان، مکان، علت (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-141.weba`
- voice: `sage`
- slot: `data-audio-id="L06-141"`
- SHA256 متن UTF-8: `0bbd45ffb2c9aed689700e8b05c5e5f93f247c64cfaaa9a26b6021f9a8e43a87`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did he fall? In the yard. Why did he fall? Because he didn’t see the step.
```

### L06-055 — آرتین — fa

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-055.weba`
- voice: `sage`
- slot: `data-audio-id="L06-055"`
- SHA256 متن UTF-8: `dfa190a113fa55f6c5e09f15a0d72bcef8585d07187f701fde1e218bf8eb208e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
ضمیر مفعولی جای شخص یا چیزِ دریافت‌کنندهٔ کار می‌آید. پس از فعل‌هایی مثل help و call یا حرف اضافه‌هایی مثل to و with می‌توانیم me، him یا them بیاوریم؛ شکل فاعلی را در آن جایگاه نمی‌گذاریم.
```

### L06-056 — آرتین — en

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-056.weba`
- voice: `sage`
- slot: `data-audio-id="L06-056"`
- SHA256 متن UTF-8: `8008e9552d02a2e64d0d2286496601a804f1896fe4100f9177c896720d457ca8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He called me. I talked to him. We helped them.
```

### L06-057 — آرتین — fa

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-057.weba`
- voice: `sage`
- slot: `data-audio-id="L06-057"`
- SHA256 متن UTF-8: `f31fce4112b9d7d2c90f2fda974bbeeed510262212ee6749ceca4fb96a16db11`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
she در جای فاعل و her در جای مفعول می‌آید. her می‌تواند پیش از اسم نیز صفت ملکی باشد. با جایگاه تشخیص بده: در I helped her مفعول است؛ در her mother، صاحبِ اسم را نشان می‌دهد.
```

### L06-058 — آرتین — en

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-058.weba`
- voice: `sage`
- slot: `data-audio-id="L06-058"`
- SHA256 متن UTF-8: `b834360f5bf8ea112b2dc060bd85ff69901ea2c85193642d3a5e94b3eacde2a4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She helped me. I helped her. Her mother called us.
```

### L06-059 — آرتین — fa

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-059.weba`
- voice: `sage`
- slot: `data-audio-id="L06-059"`
- SHA256 متن UTF-8: `0edb7eeec6253695490d2f97d4b359212545a7efff4ab91d6ac653af7cb3dd36`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در متن شیرینی، them به cookies و it به یک cookie برمی‌گردد. برای ضمیر، مرجع و مفرد یا جمع بودن را مشخص کن؛ نزدیک‌ترین اسم همیشه مرجع درست نیست.
```

### L06-060 — آرتین — en

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: متن اصلی
- فایل: `L06-060.weba`
- voice: `sage`
- slot: `data-audio-id="L06-060"`
- SHA256 متن UTF-8: `6ff530223746d8ecb2d3c7212dbde886bb9ef4b99544d0074b870608ca05a7c1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She put the cookies on the table. She put them on the table.
```

### L06-142 — آرتین — fa

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-142.weba`
- voice: `sage`
- slot: `data-audio-id="L06-142"`
- SHA256 متن UTF-8: `c7a904b564cbb9eccafa25091e479648e089a088ea58f02e9d5118fed228d6ca`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در I helped Sara and Ali، دو اسم را با them عوض کن. سپس در Sara helped me فاعل را she کن؛ جای فاعل و مفعول را با هم عوض نکن.
```

### L06-143 — آرتین — en

- بخش: ضمیر مفعولی؛ چه کسی کمک دریافت کرد؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-143.weba`
- voice: `sage`
- slot: `data-audio-id="L06-143"`
- SHA256 متن UTF-8: `8008e9552d02a2e64d0d2286496601a804f1896fe4100f9177c896720d457ca8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He called me. I talked to him. We helped them.
```

### L06-061 — آرتین — fa

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-061.weba`
- voice: `sage`
- slot: `data-audio-id="L06-061"`
- SHA256 متن UTF-8: `ee2f380761234b8bf624ef0e8aec7a1cc3b8050b466adb9998a92461955457a6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای روایت کوتاه، ترتیب اتفاق‌ها را رعایت کن: ابتدا موقعیت، بعد حادثه، سپس کمک و نتیجه. اتفاق‌های خیالی هم برای این تمرین پذیرفته‌اند؛ لازم نیست سابقهٔ واقعیِ آسیب خودت را بنویسی.
```

### L06-062 — آرتین — en

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-062.weba`
- voice: `sage`
- slot: `data-audio-id="L06-062"`
- SHA256 متن UTF-8: `69461e2c6d0f8b63fac0ea9df513931fc261eb0b75a3ec535f9aa3dc92bb66ae`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I fell in the park. I hurt my knee. My father helped me.
```

### L06-063 — آرتین — fa

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-063.weba`
- voice: `sage`
- slot: `data-audio-id="L06-063"`
- SHA256 متن UTF-8: `1de6fcf50a2973ebb464cc3604ebf9c73e3627b7a40b64f08105ed5ff69e1fc4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در واژگان کتاب، burned و burnt هر دو برای گذشتهٔ burn دیده می‌شوند و درست‌اند. برای twist گذشتهٔ باقاعدهٔ twisted می‌آید؛ همهٔ فعل‌های این درس بی‌قاعده نیستند.
```

### L06-064 — آرتین — en

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-064.weba`
- voice: `sage`
- slot: `data-audio-id="L06-064"`
- SHA256 متن UTF-8: `68b73e18a07cadd2b63cb25ce87c62c24d61f94178ee77e95059be8cffbdab0c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She burned her hand. She burnt her hand. He twisted his ankle.
```

### L06-065 — آرتین — fa

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-065.weba`
- voice: `sage`
- slot: `data-audio-id="L06-065"`
- SHA256 متن UTF-8: `79bb6f1a0058c2e5a43f98bdf6422f9377d09003d0764f7f4e01facd5888540b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
advice در این کاربرد اسمِ غیرقابل‌شمارش است. می‌گویی some advice، نه an advice. برای درخواست کمک، Can you help me? یا Do you need help? را به‌عنوان یک الگوی کامل به کار ببر.
```

### L06-066 — آرتین — en

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: متن اصلی
- فایل: `L06-066.weba`
- voice: `sage`
- slot: `data-audio-id="L06-066"`
- SHA256 متن UTF-8: `365e979b76eb59c053a4f1e8b9d54874fe4267ea4edd07e5d3c4c9b6b2d30d3a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Can you give me some advice? Do you need help?
```

### L06-144 — آرتین — fa

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-144.weba`
- voice: `sage`
- slot: `data-audio-id="L06-144"`
- SHA256 متن UTF-8: `a01ea5e1d42cef55809d864179f80148899c255e9e7a8ee6d10b7d0184e9570a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
یک حادثهٔ خیالی را در سه گامِ قبل از حادثه، خود اتفاق و کمکِ بعد از آن روایت کن. عضو بدن و زمان را مشخص کن، بدون اینکه برای تمرین زبان به شرح درمان نیاز باشد.
```

### L06-145 — آرتین — en

- بخش: شرح روشن حادثه و درخواست کمک (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L06-145.weba`
- voice: `sage`
- slot: `data-audio-id="L06-145"`
- SHA256 متن UTF-8: `69461e2c6d0f8b63fac0ea9df513931fc261eb0b75a3ec535f9aa3dc92bb66ae`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I fell in the park. I hurt my knee. My father helped me.
```

### L06-067 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-067.weba`
- voice: `sage`
- slot: `data-audio-id="L06-067"`
- SHA256 متن UTF-8: `843c3c82578bf64ad395a64ad5f0792da5cc5238b81175ba692d7904a97525ac`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در knee، حرف k خوانده نمی‌شود. حرف‌های نوشته‌شده همیشه به همان تعداد صدا تولید نمی‌کنند؛ knee را با صدای ن آغاز کن.
```

### L06-068 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-068.weba`
- voice: `sage`
- slot: `data-audio-id="L06-068"`
- SHA256 متن UTF-8: `b4092e93ab553872d7479c71727543f875cce19e29dbbd1213c1bc7035ef1c42`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Knee. My knee. I hurt my knee.
```

### L06-069 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-069.weba`
- voice: `sage`
- slot: `data-audio-id="L06-069"`
- SHA256 متن UTF-8: `f0613d9fea94fcffd695b154d5e345ba83c99f6f13316b9bbf6cacc9f0f181d4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
read در حال و گذشته یک املا دارد، ولی تلفظش عوض می‌شود. برای معنیِ خواندم یا خواند، با واژهٔ red به معنی قرمز هم‌آواست؛ در حال ساده، واکهٔ بلند شنیده می‌شود.
```

### L06-070 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-070.weba`
- voice: `sage`
- slot: `data-audio-id="L06-070"`
- SHA256 متن UTF-8: `5766c8806e26a37888dece1f40a2088f056fb051d75c8790d8eb4813958147e2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I read every day. I read the book yesterday.
```

### L06-071 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-071.weba`
- voice: `sage`
- slot: `data-audio-id="L06-071"`
- SHA256 متن UTF-8: `a5481feaa1587752da161cbb84d0f53dac7383a7465bc4b92806835562e78c6c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
cut، hit و hurt در گذشته تغییر ظاهری ندارند. زمان و بافت را بشنو؛ وجود yesterday یا last week نشان می‌دهد جمله می‌تواند گذشته باشد.
```

### L06-072 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-072.weba`
- voice: `sage`
- slot: `data-audio-id="L06-072"`
- SHA256 متن UTF-8: `b952e09c8127110963a77ff2e7550e4bf242781ee16929c5375fd0c1ef068fa6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I cut my finger yesterday. He hit his head last week.
```

### L06-073 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-073.weba`
- voice: `sage`
- slot: `data-audio-id="L06-073"`
- SHA256 متن UTF-8: `74933eb2f47625e2d76e48f49318a08ae6958f84a8c890fc087d942aec18475b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مرور آهنگ این درس، سؤال بله یا خیر معمولاً خیزان، پرسش Wh معمولاً افتان و جملهٔ خبری کامل معمولاً افتان است. جملهٔ تعجبی بسته به حس گوینده تغییر می‌کند.
```

### L06-074 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 6 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L06-074.weba`
- voice: `sage`
- slot: `data-audio-id="L06-074"`
- SHA256 متن UTF-8: `c15d1b5432a90fd2dead809a6db58510c0a39828cea404a74b11f418b394287f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did he fall? Where did he fall? He fell in the park.
```

### L06-075 — Student 1 — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-075.weba`
- voice: `nova`
- slot: `data-audio-id="L06-075"`
- SHA256 متن UTF-8: `7cac19b38441d394922f17a962433caed0b91ca91752798d4c6fdfee648e5363`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Excuse me teacher! Hamid cut his finger.
```

### L06-076 — Teacher — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-076.weba`
- voice: `sage`
- slot: `data-audio-id="L06-076"`
- SHA256 متن UTF-8: `132ca0293020dd6afa39883df6fd631fd46c4d74762a8eb994b6f78632050148`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What?! Let me see. Oh, does anyone have a plaster?
```

### L06-077 — Student 2 — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-077.weba`
- voice: `echo`
- slot: `data-audio-id="L06-077"`
- SHA256 متن UTF-8: `9e9d7d62334f06cfbb6f37027a889827b1141168a0c6439ae6977bc7d6332336`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I think I have one. Just a second!
```

### L06-078 — Teacher — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-078.weba`
- voice: `sage`
- slot: `data-audio-id="L06-078"`
- SHA256 متن UTF-8: `95526ff8dee1be052f132e2977d67faaed1b1a99234fdd7880e8d403d2c77adb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Please hurry up! It’s bleeding.
```

### L06-079 — Student 2 — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-079.weba`
- voice: `echo`
- slot: `data-audio-id="L06-079"`
- SHA256 متن UTF-8: `64ca8f6990d34cc5e7712a2e51a26cc8636434ecee59c23b1a8e54978e027b11`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I found it. Here you are.
```

### L06-080 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-080.weba`
- voice: `sage`
- slot: `data-audio-id="L06-080"`
- SHA256 متن UTF-8: `578c2d1ecaf39ba8068017dfcd26191b96d4307a42316b25ea035485628bb1da`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is he clever?
```

### L06-081 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-081.weba`
- voice: `sage`
- slot: `data-audio-id="L06-081"`
- SHA256 متن UTF-8: `4a3d0a136b6e33a34a604d21789b7dc20d649570dd3a275169f66b6504b0d98c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are they playing football?
```

### L06-082 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-082.weba`
- voice: `sage`
- slot: `data-audio-id="L06-082"`
- SHA256 متن UTF-8: `6bf831f80b94c8fe7e96561887d95c5a54163d7df8ff73c8e8e2fe991c0be6e1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does he like summer?
```

### L06-083 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-083.weba`
- voice: `sage`
- slot: `data-audio-id="L06-083"`
- SHA256 متن UTF-8: `b94904d070bb075c70635d5d082f778d8a8120801b71fe34a16a7a77bc3e0500`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do they have their lunch at school?
```

### L06-084 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-084.weba`
- voice: `sage`
- slot: `data-audio-id="L06-084"`
- SHA256 متن UTF-8: `00d8bcdb500b7bb51af5eeca2e18855cc7ed54d79e8ca317e51807c7824e2ed8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It is fantastic!
```

### L06-085 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-085.weba`
- voice: `sage`
- slot: `data-audio-id="L06-085"`
- SHA256 متن UTF-8: `a9c8d621ac5127b8510be36a28489ba2ed7e29c3dc563e2d56651c6323bd2db2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What a beautiful flower!
```

### L06-086 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-086.weba`
- voice: `sage`
- slot: `data-audio-id="L06-086"`
- SHA256 متن UTF-8: `3d4869de62e306afae9f15da911db96d8814fd74f870b418a899a3696a30fc6e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
There is a cat in the yard.
```

### L06-087 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-087.weba`
- voice: `sage`
- slot: `data-audio-id="L06-087"`
- SHA256 متن UTF-8: `f3c84a6b62404535f29c04ec6332495abcac37cb07b50877a26f1afa05c20671`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We had an accident.
```

### L06-088 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-088.weba`
- voice: `sage`
- slot: `data-audio-id="L06-088"`
- SHA256 متن UTF-8: `c707a8d03b413f67c3f7726dfc7342441c0727ee6e6e5b9fd2638a3b6d30f678`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We live in Isfahan.
```

### L06-089 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-089.weba`
- voice: `sage`
- slot: `data-audio-id="L06-089"`
- SHA256 متن UTF-8: `74fa5acc59e0af217656d299c15a933ac1f422fd3e27346bcc5e1b8d48f2ed65`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is my coat?
```

### L06-090 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-090.weba`
- voice: `sage`
- slot: `data-audio-id="L06-090"`
- SHA256 متن UTF-8: `960d1c4db951d87d63506a6df9d7a5b4b746a242be892c0077e51cdc667c0f1e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What do you study?
```

### L06-091 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-091.weba`
- voice: `sage`
- slot: `data-audio-id="L06-091"`
- SHA256 متن UTF-8: `9202770bf84c8c30022c0b0345695fc3a17aa744f6bfc45cafd75217faf48308`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When did they go to school?
```

### L06-092 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L06-092.weba`
- voice: `sage`
- slot: `data-audio-id="L06-092"`
- SHA256 متن UTF-8: `640b1b7f18923043c32769e0f7f973d718b095fac57fb0d6590eeae7adb67bfc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you need help?
```

### L06-146 — آرتین — fa

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: تمرین تکمیلی تلفظِ سلامت و آسیب‌ها
- فایل: `L06-146.weba`
- voice: `sage`
- slot: `data-audio-id="L06-146"`
- SHA256 متن UTF-8: `e8f872dd7aff9b5090e54cc8a9065a9eb15b82b639c937d07bde58396ba206ac`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
knee، hurt و گذشتهٔ read را جدا اجرا کن. در knee صدای k نیاور، در hurt به انتهای واژه واکه اضافه نکن و برای read، مدلِ جملهٔ گذشته را با مدلِ جملهٔ عادت مقایسه کن.
```

### L06-093 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L06-093.weba`
- voice: `sage`
- slot: `data-audio-id="L06-093"`
- SHA256 متن UTF-8: `e7499ad68e741053fffe1343c0a98fce23d8dea27302647b563d8d65289d394e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My mom just baked some cookies. She put them on the table. My little brother Reza was hungry. He wanted a cookie. He climbed a chair to take it. He fell down and hurt his head. He climbed the chair again. He took one this time. The cookie was hot. He burnt his hand and started crying.
```

### L06-147 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: ترجمهٔ خواندنی
- فایل: `L06-147.weba`
- voice: `sage`
- slot: `data-audio-id="L06-147"`
- SHA256 متن UTF-8: `df6ec135b97c758129389998762c6856b39a3687f5312b310a7e1bb008374145`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
مادرم چند شیرینی پخت و روی میز گذاشت. برادر کوچکم رضا گرسنه بود و شیرینی می‌خواست. برای برداشتنش از صندلی بالا رفت، افتاد و سرش آسیب دید. دوباره بالا رفت و این بار یکی برداشت؛ شیرینی داغ بود، دستش سوخت و گریه‌اش گرفت.
```

### L06-094 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L06-094.weba`
- voice: `sage`
- slot: `data-audio-id="L06-094"`
- SHA256 متن UTF-8: `5e28fa42d6f74a331135c69008cf5ce3b21e0816deef97c68521652d3343102b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
گذشته‌های باقاعده و بی‌قاعده را انتخاب کن؛ to take و crying را با فعل گذشته اشتباه نگیر.
```

### L06-148 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L06-148.weba`
- voice: `sage`
- slot: `data-audio-id="L06-148"`
- SHA256 متن UTF-8: `65e2fb0f9c4c104d0d9fdfd41347875c0a3a77e14c309e650013e020546303b3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
baked / put / was / wanted / climbed / fell / hurt / took / burnt / started
```

### L06-149 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L06-149.weba`
- voice: `sage`
- slot: `data-audio-id="L06-149"`
- SHA256 متن UTF-8: `b86791d87cc7ab0ce8c596b43967e17340d4cb8cd616c1cde95b513f616ce793`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در داستان شیرینی، climbed و was بیش از یک بار می‌آیند؛ هر مورد را جدا انتخاب کن. crying و to take را با گذشته‌های wanted و took اشتباه نگیر.
```

### L06-150 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: مرجع ضمیر در داستان شیرینی
- فایل: `L06-150.weba`
- voice: `sage`
- slot: `data-audio-id="L06-150"`
- SHA256 متن UTF-8: `57df2436750d4ef211493542fe4de7ffdded6d778e0f7010789a3e8d9f73cb67`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
them به cookies برمی‌گردد؛ it در to take it به یک شیرینی اشاره دارد. his در his head صفت ملکی است، نه ضمیر مفعولی.
```

### L06-095 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن اصلی
- فایل: `L06-095.weba`
- voice: `sage`
- slot: `data-audio-id="L06-095"`
- SHA256 متن UTF-8: `be1fd0f65c3507bae3a28f3af30e1a7c16f1169a31c6551c152d9b2dec7e3e94`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فایل رسمی شنیداری در PDF موجود نیست. دو متن این بخش برای تمرینِ سلامت و آسیب‌ها تألیف شده‌اند و کلید آن‌ها فقط مربوط به همین متن‌هاست. بار اول اطلاعات اصلی و بار دوم جزئیات پرسش‌ها را یادداشت کن.
```

### L06-096 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی A؛ پس از گوش دادن باز کن
- فایل: `L06-096.weba`
- voice: `sage`
- slot: `data-audio-id="L06-096"`
- SHA256 متن UTF-8: `1dc40633841c5e14d6d140b8cc6825117406237e060ab49df13d8e7c39f97b25`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
In this practice story, a girl did not see a step. She fell down the steps and broke her leg. Her mother called for help and stayed with her.
```

### L06-151 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی A
- فایل: `L06-151.weba`
- voice: `sage`
- slot: `data-audio-id="L06-151"`
- SHA256 متن UTF-8: `131f6854f1b385c11137801be3cfe1ddd4d966803ea5629ebb167d3202ef920c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پله را ندید؛ از پله‌ها افتاد؛ مادر درخواست کمک کرد و کنارش ماند.
```

### L06-097 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی B؛ پس از گوش دادن باز کن
- فایل: `L06-097.weba`
- voice: `sage`
- slot: `data-audio-id="L06-097"`
- SHA256 متن UTF-8: `0337339c526e6a2c4b1ead2a218f914f0eea17af89d1f49d4b3eb024cd112ffa`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
In our fictional exercise, a firefighter named Omid helped a family in a fire. He fell and hurt his back. He is at home now. This is a language-practice story.
```

### L06-152 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی B
- فایل: `L06-152.weba`
- voice: `sage`
- slot: `data-audio-id="L06-152"`
- SHA256 متن UTF-8: `dd6f891e25aa76eedecefe4f0e1281b4b0552e2c23150b9630e0154066639371`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
یک خانواده در آتش بود؛ افتاد و کمرش آسیب دید؛ الان در خانه است. این متن دربارهٔ شخصیت فرضی است و زندگی‌نامهٔ فرد واقعی نیست.
```

### L06-098 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-098.weba`
- voice: `sage`
- slot: `data-audio-id="L06-098"`
- SHA256 متن UTF-8: `d2d89f70316e286530da89918536401d2683753d760592c1a7cfdc5bd0ada619`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What was your last accident?
```

### L06-099 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-099.weba`
- voice: `sage`
- slot: `data-audio-id="L06-099"`
- SHA256 متن UTF-8: `01d4c15ef818093397aa10815f6fbe8cab6f2b927780904bfe929fa9b8d77983`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did it happen?
```

### L06-100 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-100.weba`
- voice: `sage`
- slot: `data-audio-id="L06-100"`
- SHA256 متن UTF-8: `40befb12738d3c105fba848b574c4bd7fa15867b45748dca17a8c0e50576368c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When did it happen?
```

### L06-101 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-101.weba`
- voice: `sage`
- slot: `data-audio-id="L06-101"`
- SHA256 متن UTF-8: `32189bb58790878bac0aa48d836d846f174da8e210c9160b5d9f85a0219edd33`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What did you do?
```

### L06-102 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-102.weba`
- voice: `sage`
- slot: `data-audio-id="L06-102"`
- SHA256 متن UTF-8: `6f2b38d82f2158eccf2002ac6716f0670e2d48f39f9b77fab9dba8871c613da6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helped you?
```

### L06-103 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-103.weba`
- voice: `coral`
- slot: `data-audio-id="L06-103"`
- SHA256 متن UTF-8: `1a6a82d50dbee071c88bc3c961c07fa9760c946fff1d40090b0577333d20a491`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What happened yesterday?
```

### L06-104 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-104.weba`
- voice: `echo`
- slot: `data-audio-id="L06-104"`
- SHA256 متن UTF-8: `2791e8aecd4fcf31bad25665641c5803866a216bcff760d2dafdc419407c8b76`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I fell in the school yard.
```

### L06-105 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-105.weba`
- voice: `coral`
- slot: `data-audio-id="L06-105"`
- SHA256 متن UTF-8: `57f6353529e1095eb3870918dcef0709fdee1eec41974aeba989272670304711`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you hurt your leg?
```

### L06-106 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-106.weba`
- voice: `echo`
- slot: `data-audio-id="L06-106"`
- SHA256 متن UTF-8: `30f748af02fd0932e7a681c4d3c55fd534478ce9e114e89e9265b656e8b0cb7d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, I hurt my hand.
```

### L06-107 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-107.weba`
- voice: `coral`
- slot: `data-audio-id="L06-107"`
- SHA256 متن UTF-8: `6f2b38d82f2158eccf2002ac6716f0670e2d48f39f9b77fab9dba8871c613da6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helped you?
```

### L06-108 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L06-108.weba`
- voice: `echo`
- slot: `data-audio-id="L06-108"`
- SHA256 متن UTF-8: `788e58d8501db0cbb82c18ce5991c709fcdddbd935604b83bd76567ec01bf02e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Our teacher helped me. She called my father.
```

### L06-153 — آرتین — fa

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: معیار اجرای مستقل در سلامت و آسیب‌ها
- فایل: `L06-153.weba`
- voice: `sage`
- slot: `data-audio-id="L06-153"`
- SHA256 متن UTF-8: `ad12f745217fb2969e8965992ded1f03bd948b92e161999e0be17ea94a29648f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گفت‌وگوی حادثه، زمان و محل و کمک‌کننده را روشن کن. یک بار نامِ شخص کمک‌کننده را با ضمیر فاعلی و نامِ فرد آسیب‌دیده را با ضمیر مفعولی جایگزین کن.
```

### L06-109 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-109.weba`
- voice: `sage`
- slot: `data-audio-id="L06-109"`
- SHA256 متن UTF-8: `24a88de22a6763cd92ef33ff2f2b9e4443eb3c3bb12a5887e06dcf838ce3bc56`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
go گذشتهٔ بی‌قاعدهٔ went دارد.
```

### L06-110 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-110.weba`
- voice: `sage`
- slot: `data-audio-id="L06-110"`
- SHA256 متن UTF-8: `62ec62d6606ba2f63399861e37a345a9a4576f94f169f58cacbd7b76089060af`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He went home.
```

### L06-111 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-111.weba`
- voice: `sage`
- slot: `data-audio-id="L06-111"`
- SHA256 متن UTF-8: `02bffa6e678083d5a8bf8961dd62e50bb6f9d8eb51e379779c53a3c065a24dc3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پس از did، شکل پایهٔ break لازم است.
```

### L06-112 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-112.weba`
- voice: `sage`
- slot: `data-audio-id="L06-112"`
- SHA256 متن UTF-8: `a8356e47252d2c2366ba369ef603cafc916accaf74b670830eb2f1cfb6679fec`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did she break her leg?
```

### L06-113 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-113.weba`
- voice: `sage`
- slot: `data-audio-id="L06-113"`
- SHA256 متن UTF-8: `cdb3a3733e365b832ce715d012c60532e601e13c8bbc410e6d872728c4104ae9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
مفعول باید us باشد، نه فاعل we.
```

### L06-114 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L06-114.weba`
- voice: `sage`
- slot: `data-audio-id="L06-114"`
- SHA256 متن UTF-8: `3e98613927b46aea95533d93f4d0a561906ddd1f1f65fa2e16908b8482842a9d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They helped us.
```

### L06-115 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L06-115.weba`
- voice: `sage`
- slot: `data-audio-id="L06-115"`
- SHA256 متن UTF-8: `03b999317c4b8fa504cb00f2a9d1df5a0395b7dcc725bc28ed74530d108e6877`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
a black eye
```

### L06-116 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L06-116.weba`
- voice: `sage`
- slot: `data-audio-id="L06-116"`
- SHA256 متن UTF-8: `8877e1e824326b8a1aeeb74697c93e41852201f179b976cffa8809c2f8193f61`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
a car crash
```

### L06-117 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L06-117.weba`
- voice: `sage`
- slot: `data-audio-id="L06-117"`
- SHA256 متن UTF-8: `9d8beb8ef10264fbfbcc637f93b8a82ec2d6c556c2e92c87203678d2451ad18b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
a scar
```

### L06-118 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L06-118.weba`
- voice: `sage`
- slot: `data-audio-id="L06-118"`
- SHA256 متن UTF-8: `d67f241570be65b5389451ffd8c62a88a0b2a2f13b172e7013cacfda8c620347`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
a heart attack
```

### L06-119 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L06-119.weba`
- voice: `sage`
- slot: `data-audio-id="L06-119"`
- SHA256 متن UTF-8: `36066930c45ad07efff9eaf8f4581ac5a7bedc5b9dc7c326841b44861f9ba97d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
a leg in a cast
```

### L06-120 — آرتین — fa

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-120.weba`
- voice: `sage`
- slot: `data-audio-id="L06-120"`
- SHA256 متن UTF-8: `1433074ea70aa249743bd092d07134d89af93c4f790e63161ddc0987bcf6b75e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
این جدول برای مراجعه است، نه حفظ کردن همهٔ فعل‌ها در یک نشست. ابتدا فعل‌های داستان شیرینی و مکالمهٔ آسیب را پیدا کن؛ بعد پنج فعل مرتبط با زندگی روزانه انتخاب کن و با آن‌ها جمله بساز. شکل پایه را پس از did و شکل گذشته را در خبرِ مثبت به کار ببر.
```

### L06-121 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-121.weba`
- voice: `sage`
- slot: `data-audio-id="L06-121"`
- SHA256 متن UTF-8: `d0bad34769264eb782aeb168d3253eb135abc3511b0c3db9eccf047b84b404e6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
be. was, were. become. became. bleed. bled. break. broke. bring. brought. build. built.
```

### L06-122 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-122.weba`
- voice: `sage`
- slot: `data-audio-id="L06-122"`
- SHA256 متن UTF-8: `fe7c9a533fa66c12486f987b2c5060d00cc1e4813830368e033eb62693407986`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
buy. bought. choose. chose. come. came. cut. cut. do. did. draw. drew.
```

### L06-123 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-123.weba`
- voice: `sage`
- slot: `data-audio-id="L06-123"`
- SHA256 متن UTF-8: `1862f0dac66180904955f7d5101a0cb3b226ec10b7387d588e49ec0342a6d51c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
drink. drank. drive. drove. eat. ate. fall. fell. feed. fed. feel. felt.
```

### L06-124 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-124.weba`
- voice: `sage`
- slot: `data-audio-id="L06-124"`
- SHA256 متن UTF-8: `bd4c2bfac2ccc18893beec94f04304a01eb1cfdad8b97bde74339d82b6d317a1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
find. found. forget. forgot. get. got. give. gave. go. went. have. had.
```

### L06-125 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-125.weba`
- voice: `sage`
- slot: `data-audio-id="L06-125"`
- SHA256 متن UTF-8: `4d8d7f2dbbdd807beeabc34c0bbc7ea583609bf64cef0fe21ab4d748bbc30220`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
hear. heard. hit. hit. hurt. hurt. keep. kept. know. knew. leave. left.
```

### L06-126 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-126.weba`
- voice: `sage`
- slot: `data-audio-id="L06-126"`
- SHA256 متن UTF-8: `705f98abe4cc25b7d8a75a0f6c83c35ef32d1cfea0496a340a5e4b0a77e75911`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
lose. lost. make. made. meet. met. pay. paid. put. put. I read every day. I read the book yesterday.
```

### L06-127 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-127.weba`
- voice: `sage`
- slot: `data-audio-id="L06-127"`
- SHA256 متن UTF-8: `6d701359d0e65f8da5d6e4b81b6aedfba5650115fba21dd57da2674ffa197613`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
ride. rode. run. ran. say. said. see. saw. set. set. sell. sold.
```

### L06-128 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-128.weba`
- voice: `sage`
- slot: `data-audio-id="L06-128"`
- SHA256 متن UTF-8: `09bb7733dc40ba907fb080421ddc0221af5a3fa5c3c1fdcb3c9dd111a7c0fe3a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
send. sent. sing. sang. sit. sat. sleep. slept. speak. spoke. stand. stood.
```

### L06-129 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-129.weba`
- voice: `sage`
- slot: `data-audio-id="L06-129"`
- SHA256 متن UTF-8: `3d91d4748c4ff7794558f0eddcad5cd35fb4eb30c38fd679f680aac1576d8758`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
stick. stuck. swim. swam. take. took. take off. took off. teach. taught. tell. told.
```

### L06-130 — آرتین — en

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: متن اصلی
- فایل: `L06-130.weba`
- voice: `sage`
- slot: `data-audio-id="L06-130"`
- SHA256 متن UTF-8: `a77f2119f76ab466c9ee539cf68c998cfc30a488863f1421f0ea903b819cc33d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
think. thought. understand. understood. wake. woke. wear. wore. write. wrote.
```

### L06-154 — آرتین — fa

- بخش: مرجع کامل فعل‌های بی‌قاعدهٔ پایان کتاب (`irregular-reference`)
- کادر: از فهرست به کاربرد
- فایل: `L06-154.weba`
- voice: `sage`
- slot: `data-audio-id="L06-154"`
- SHA256 متن UTF-8: `a4fa5efb144ba7fa47153ca250744e446bc063b73924fa695e6d63322b42f3f7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای پنج فعل انتخابی، سه ستون بساز: خبرِ مثبت، سؤال و منفی. مثلاً went در خبر می‌آید ولی پس از did باید go را برگردانی. برای read گذشته، تلفظ /red/ را نگه دار، حتی اگر املایش تغییری نکرده باشد.
```

### L06-155 — آرتین — en

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L06-155.weba`
- voice: `sage`
- slot: `data-audio-id="L06-155"`
- SHA256 متن UTF-8: `3a2046f3c3eba1b441b5c5aa96970ceb2a404948efde6046ba59ba8cd8a8d69b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I fell in the park last year. I hurt my knee. My teacher helped me. She called my mother. I stayed at home for one day.
```

### L06-156 — آرتین — fa

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L06-156.weba`
- voice: `sage`
- slot: `data-audio-id="L06-156"`
- SHA256 متن UTF-8: `6b53a207fb1ad23d4f1899caa097aec60a9c3c56c9752820a50eeebada7f8911`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در روایت آسیب، شکل پایه و گذشتهٔ فعل بی‌قاعده را مقابله کن. برای هر ضمیر مفعولی، مرجع مشخص داشته باش و پس از did فعل گذشتهٔ دوباره نگذار.
```

### L06-131 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L06-131.weba`
- voice: `sage`
- slot: `data-audio-id="L06-131"`
- SHA256 متن UTF-8: `d484b4fc783a0b8b1f9ae92dcd8cad35e9d1b4fc2718083fc5d3a33773c0f368`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Mina texted a message to her sister.
```

### L06-132 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L06-132.weba`
- voice: `sage`
- slot: `data-audio-id="L06-132"`
- SHA256 متن UTF-8: `a4206d9246e81d970f31c9f1aa499b593e2d8dcd2fb90b7ddf1bfa7aefdb90ae`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My father listened to the radio this morning.
```

### L06-157 — آرتین — fa

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: مرور ارتباطیِ دو درس
- فایل: `L06-157.weba`
- voice: `sage`
- slot: `data-audio-id="L06-157"`
- SHA256 متن UTF-8: `ad0f7f41f021e957e0052660e78f489da46af5f866e49f25ded476c60a0e7a03`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مرورِ سلامت و آسیب‌ها و رسانه‌ها، یک گفت‌وگوی ترکیبی بساز. ابتدا اطلاعات را بپرس، سپس با همان زمانِ درست پاسخ بده. دو واژه از فرهنگ تصویری و یک ساختارِ بخش See also را هم به کار ببر.
```

### L06-133 — آرتین — fa

- بخش: جمع‌بندی و مرور فاصله‌دارِ سلامت و آسیب‌ها (`summary`)
- کادر: متن اصلی
- فایل: `L06-133.weba`
- voice: `sage`
- slot: `data-audio-id="L06-133"`
- SHA256 متن UTF-8: `a38eae7195ad557f4d81f10a39ae3e8529aac3de140966f46f5e3e1467d415a2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جمع‌بندیِ سلامت و آسیب‌ها، به‌جای بازخوانی کل صفحه، سه جمله از حافظه بساز: یک خبر، یک منفی و یک پرسش. روز بعد یکی از اطلاعات را عوض کن؛ سه روز بعد گفت‌وگوی تازه اجرا کن و هفتهٔ بعد آزمون را با نمونهٔ شخصی تکمیل کن.
```

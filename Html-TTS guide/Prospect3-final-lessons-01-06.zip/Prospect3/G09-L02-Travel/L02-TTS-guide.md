# راهنمای کامل تولید و تزریق صوت؛ درس 2 — سفر

تعداد قطعات: 141. این فایل تمام متن‌های گفتاری را دارد؛ ایجنت متن تازه ننویسد، تکرار یا خلاصه نکند. هر متن دقیقاً با p.tts-text در HTML برابر است. متن اصلی کتاب و شنیداری‌های تألیفی با هم اشتباه نشوند.

## پرامپت TTS

Read only the exact input. Do not add an introduction, summary, translation, music, or speaker label. Use fluent Iranian Persian for fa and clear General American English for en. Keep each character's voice fixed. Read dialogue as conversation. Use meaningful short pauses and a moderate teaching pace. Follow the delivery field for pronunciation and intonation. Never pronounce IDs, arrows or metadata.

## رابط و قرارداد فایل

نام مدرس آرتین و نام یادگیرنده رها است. کنترل ترجمه در همان ناحیه قرار دارد. همهٔ بخش‌های اصلی در منبع بسته‌اند؛ در اجرا فقط یکی باز و آخرین انتخاب ذخیره می‌شود. پنل فلوتر در وب‌ویو تمام‌صفحه است. هیچ پنل مدرس، تولید صوت، خوانش دستگاه، چاپ یا دانلود یادداشت به HTML اضافه نکن. هر آیکون داخل audio-block باید فقط صوت همان ID را پخش/مکث کند. پخش تازه باید صوت قبلی، از جمله ضبط شخصی، را متوقف کند.

متن‌های کادرهای کمکی، پاسخ‌های بازشونده و نکات تلفظی هم قطعات مستقل دارند. ترتیب clips ترتیب تدریس است؛ شماره‌ها را تغییر نده. برای هر قطعه یک فایل L02-NNN.weba و JSON منشأ لازم است. hash متن و فایل را کنترل کن؛ یکسان بودن نام فایل به‌تنهایی کافی نیست.

## کیفیت و حجم

ظرف WebM فقط صوتی، codec Opus، تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s و application=voip. تغییر پسوند MP3 به WebA تبدیل نیست. loudness هدف حدود -18 LUFS و true peak حداکثر -2 dBTP؛ اسکریپت از loudnorm تک‌مرحله‌ای استفاده می‌کند. خروجی را برای قطع نشدن کلمات، وضوح صداها و ثبات نقش‌ها بشنو. Base64 تقریباً یک‌سوم به حجم باینری اضافه می‌کند. موسیقی و افکت اضافه نکن.

## اجرا

نیازمند Python 3.10+، ffmpeg و ffprobe با libopus است. OPENAI_API_KEY فقط در محیطِ ایجنت تولیدکننده قرار بگیرد؛ در HTML و Markdown نوشته نشود. --generate درخواست شبکه‌ای هزینه‌دار دارد؛ --embed آفلاین است. در این تحویل هنوز صوت آموزشی نهایی تولید نشده است.

```bash
python tts_pipeline.py engl9-l02-travel.html
python tts_pipeline.py engl9-l02-travel.html --generate --only L02-001,L02-002 --audio-dir audio-l02
python tts_pipeline.py engl9-l02-travel.html --generate --audio-dir audio-l02
python tts_pipeline.py engl9-l02-travel.html --embed --audio-dir audio-l02 --output engl9-l02-travel-with-audio.html
```

ابتدا فارسی و انگلیسی و دو نقشِ گفت‌وگو را نمونه‌گیری و شنیداری کنترل کن. صداهای سرویس مطابق voice هر قطعه‌اند؛ اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود. فایل خام را برای QA نگه دار. برای صوت وارداتی از ایجنت دیگر، پس از تطبیق انسانی متن می‌توان --accept-imports را هنگام embed به کار برد؛ این گزینه تشخیص خودکار صحت گفتار نیست.

```bash
ffmpeg -i source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L02-001.weba
```

## تزریق دقیق

manifest داخلی با id=tts-manifest را بخوان. اسکریپت متن HTML، SHA256 متن و SHA256 فایل را بررسی می‌کند. هر data-audio-id دقیقاً یک audio مخفی دارد. src آن باید data:audio/webm;codecs=opus;base64,... باشد. تمام صوت‌ها داخل همان HTML هستند؛ مسیر خارجی یا iframe نگذار. اسکریپت فایل ناقص را تحویل نمی‌دهد و منبع اصلی را بازنویسی نمی‌کند.

پس از تزریق، شمار audioهای دارای src باید با شمار manifest برابر باشد. یک بخش و یک کادر کمکی را باز کن؛ دکمه باید صوت همان قسمت را اجرا کند. پخش دو قسمت پشت‌سرهم باید اولی را قطع کند. شنیداری A و B بدون باز کردن متن قابل پخش‌اند. گوشی و دسکتاپ، سرعت، توقف، منوی تمام‌صفحه و حالت آفلاین را بررسی کن. تلفظ و نوبت دیالوگ به بازبینی انسانی نیاز دارند؛ آزمون فنیِ پخش به معنی تأیید تلفظ نیست.

## متن کامل قطعات

فقط متن کادر text را به سرویس بده؛ عنوان و metadata خوانده نشوند.

### L02-001 — آرتین — fa

- بخش: درس 2؛ سفر و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L02-001.weba`
- voice: `sage`
- slot: `data-audio-id="L02-001"`
- SHA256 متن UTF-8: `b950be00b4ff3ab85c62f83c7d697ee5b38fbcb7f355e66e9119dd8800a98bbb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس «سفر» می‌آموزی اطلاعات یک سفر را بپرسی، کارهای در حال انجام را توصیف کنی و در پذیرش هتل گفت‌وگو کنی.
```

### L02-002 — آرتین — en

- بخش: درس 2؛ سفر و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L02-002.weba`
- voice: `sage`
- slot: `data-audio-id="L02-002"`
- SHA256 متن UTF-8: `d852029f59bb87d6d3fe71845ee0dd8d1ce805c499901c255bf9b015981dff5b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Lesson 2. Travel. Use the language in a new situation.
```

### L02-120 — آرتین — fa

- بخش: درس 2؛ سفر و هدف یادگیری (`goals`)
- کادر: مسیر پیشنهادی همین درس
- فایل: `L02-120.weba`
- voice: `sage`
- slot: `data-audio-id="L02-120"`
- SHA256 متن UTF-8: `3928f909d928e0ce6a8a5dbe7620db7ec33530c8e55499ea0d64ac2558794edf`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پیش از شروعِ سفر، سنجش ورودی را انجام بده. کمتر از شش پاسخ درست از هشت یعنی مرور پل پیش‌نیاز لازم است. سپس به ترتیبِ فهرست پیش برو؛ پس از هر الگو، پاسخ خودت را پیش از باز کردن راه‌حل بساز.
```

### L02-003 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-003.weba`
- voice: `sage`
- slot: `data-audio-id="L02-003"`
- SHA256 متن UTF-8: `dce62e1139819a366862c5359573304d4e9546e467c528aace914aefc0e5e6a9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای سفر لازم است فعل‌های am/is/are، ضمیرها، شکل کوتاه و پرسش‌های who، where و how را از درس قبل بازیابی کنی. از هفتم و هشتم هم نام کشورها، معرفی ملیت و عبارت‌های مکان و وسیلهٔ رفت‌وآمد را لازم داریم.
```

### L02-004 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-004.weba`
- voice: `sage`
- slot: `data-audio-id="L02-004"`
- SHA256 متن UTF-8: `4f733438c7b8a202294e4b9f89c996b322a2e6edf77279ca0d8958c1b5c398e3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
می‌گویی او دانش‌آموز است: She is a student. این جمله عملِ در حال انجام ندارد. برای گفتن اینکه همین حالا چه می‌کند، پس از is یک فعل با ing می‌آوریم. پس شناخت be در درس یک مستقیماً پایهٔ امروز است.
```

### L02-005 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-005.weba`
- voice: `sage`
- slot: `data-audio-id="L02-005"`
- SHA256 متن UTF-8: `b462b6fb9b6285100186370a74029a1840a99723e8cd0de9f90cd598ff7294e6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She is a student. She is reading now.
```

### L02-006 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-006.weba`
- voice: `sage`
- slot: `data-audio-id="L02-006"`
- SHA256 متن UTF-8: `ca9e0bcbe35299c9113286d0e8298fc239f47ecee1e739ed0c13cd3297565d5b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای نام بردن مکان، at school و in Tehran را بشناس. برای مقصد از to و برای وسیله از by استفاده می‌کنیم. پس از by در این الگوها a یا the نمی‌گذاریم.
```

### L02-007 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-007.weba`
- voice: `sage`
- slot: `data-audio-id="L02-007"`
- SHA256 متن UTF-8: `5ce2ec03dfc118eb7ab402e4b5f365656273045b1b4d7e12523d6a26727b4916`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
At school. In Tehran. To Shiraz. By train. By bus.
```

### L02-008 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-008.weba`
- voice: `sage`
- slot: `data-audio-id="L02-008"`
- SHA256 متن UTF-8: `09fed4f3358fd0ba512effc67869e9bee193a3a2053899faf54a6dc2875ce4c2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
my و your صاحبِ اسم را معرفی می‌کنند. passport یعنی گذرنامه؛ reservation یعنی رزرو. این‌ها را با نام و صاحبشان تمرین کن تا در مکالمهٔ پذیرش سردرگم نشوی.
```

### L02-009 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L02-009.weba`
- voice: `sage`
- slot: `data-audio-id="L02-009"`
- SHA256 متن UTF-8: `470387b17dd71b13ea4beb834ec6cd79f3619a4b3d589a055d8ecd93e89d883d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My passport. Your reservation. Her room. Our hotel.
```

### L02-121 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L02-121.weba`
- voice: `sage`
- slot: `data-audio-id="L02-121"`
- SHA256 متن UTF-8: `a1fdc4aad3587d0b00a0d38f24531017b707997ba768a38bd4e0580afde1745f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
اسم دو هم‌سفر را بنویس و هر دو را با they جایگزین کن. برای اکنون، یک جمله با are و فعل ing بساز؛ سپس برای یک نفر از is استفاده کن. اگر be را جا انداختی، قبل از افزودن واژهٔ تازه همان جای خالی را کامل کن.
```

### L02-122 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L02-122.weba`
- voice: `sage`
- slot: `data-audio-id="L02-122"`
- SHA256 متن UTF-8: `b462b6fb9b6285100186370a74029a1840a99723e8cd0de9f90cd598ff7294e6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She is a student. She is reading now.
```

### L02-010 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-010.weba`
- voice: `sage`
- slot: `data-audio-id="L02-010"`
- SHA256 متن UTF-8: `b97db18eaa246aee27f31e65ab63eae72dbac80bd7d2f0fdd56d7a5ebe34c1f3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
buy a ticket. He is buying a ticket.
```

### L02-011 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-011.weba`
- voice: `sage`
- slot: `data-audio-id="L02-011"`
- SHA256 متن UTF-8: `dd29c9e0612f9696195ca2e7201d4ea171b3b75427e5b98b4f14df9a3a683c97`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
check the passport. She is checking my passport.
```

### L02-012 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-012.weba`
- voice: `sage`
- slot: `data-audio-id="L02-012"`
- SHA256 متن UTF-8: `fd0ad3172d3623a34e98d9830a8b95486bafaa119f4856096886893672386a6f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
check in. We are checking in at the hotel.
```

### L02-013 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-013.weba`
- voice: `sage`
- slot: `data-audio-id="L02-013"`
- SHA256 متن UTF-8: `937342f18bd5b6716c6ff9623a66bef0e02716c4f240d0155a16b04da0d98fcd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
check the timetable. I am checking the timetable.
```

### L02-014 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-014.weba`
- voice: `sage`
- slot: `data-audio-id="L02-014"`
- SHA256 متن UTF-8: `b77355972aa0923322244f8bf11221573a8b6040e54ce3e4c25d484edfa4f56a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
take off / land. The plane is taking off. Another plane is landing.
```

### L02-015 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-015.weba`
- voice: `sage`
- slot: `data-audio-id="L02-015"`
- SHA256 متن UTF-8: `e2bb05f8bb2b7a29a4a88f80d9896d9dd9f7fc412ee82f04e36c564ccc43969e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
exchange money. They are exchanging money.
```

### L02-016 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-016.weba`
- voice: `sage`
- slot: `data-audio-id="L02-016"`
- SHA256 متن UTF-8: `0104e6c4d52c219351707c03703324a0f6c0efc118740994ddbd894cd9dcd958`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
fill out the form. She is filling out the form.
```

### L02-017 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-017.weba`
- voice: `sage`
- slot: `data-audio-id="L02-017"`
- SHA256 متن UTF-8: `49ef45c548d0b641941f6f31ee92fd679b8ef3e09ac19efb4197610a3149c2d6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
book a hotel. We are booking a hotel online.
```

### L02-018 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-018.weba`
- voice: `sage`
- slot: `data-audio-id="L02-018"`
- SHA256 متن UTF-8: `c2ab283914db483c2f03cb8d4f74720614ca9e65405853215e71a27f8f8a96fd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
pack for a trip. My father is packing for a trip.
```

### L02-019 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L02-019.weba`
- voice: `sage`
- slot: `data-audio-id="L02-019"`
- SHA256 متن UTF-8: `8a53449f6d7202a1f13337449b1ab3d80075db2d08ec5664278456dc283ab65d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
talk to a receptionist. The tourist is talking to a receptionist.
```

### L02-020 — Receptionist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-020.weba`
- voice: `sage`
- slot: `data-audio-id="L02-020"`
- SHA256 متن UTF-8: `be225afadade48c4ddd63cee6401733dcea167df3eccdbd4a91934ec634c4112`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Welcome to our hotel sir, how can I help you?
```

### L02-021 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-021.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-021"`
- SHA256 متن UTF-8: `67904c7b7fd5992eeebf7f1424a55c983fa3c207cea06a11afd477dd0c270fac`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My name is Paul Kress. I’m from Germany. I have a reservation here.
```

### L02-022 — Receptionist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-022.weba`
- voice: `sage`
- slot: `data-audio-id="L02-022"`
- SHA256 متن UTF-8: `903a25bd3b1aeec4f13a492f339bcbd01d65b10fdd4e822265370ee905ab33f6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I see! Are you staying here for two nights?
```

### L02-023 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-023.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-023"`
- SHA256 متن UTF-8: `ff1566607ad0a87bb1c56ce3f9d9e01ad210a437d19177a04bb967285698013e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, my wife and I are visiting Tehran for three days.
```

### L02-024 — Receptionist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-024.weba`
- voice: `sage`
- slot: `data-audio-id="L02-024"`
- SHA256 متن UTF-8: `ea67d85c2ec07ea602c1e01e5c26cc36844ddc7a36445554ce5433699d7eafd1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is she now? I need to check her passport.
```

### L02-025 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-025.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-025"`
- SHA256 متن UTF-8: `537573b8117331d1261936891a525ca488bceda61316289d6f027ba85d2298d2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She’s standing over there, by the gift shop. Here is her passport.
```

### L02-026 — Receptionist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L02-026.weba`
- voice: `sage`
- slot: `data-audio-id="L02-026"`
- SHA256 متن UTF-8: `54681d077b40456aa52974ca5c5372040058cbb9314bd1178ca62f6173844a5a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Thank you. This is your key. It’s room 213. Hope you enjoy your stay in Tehran.
```

### L02-123 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: اجرای گفت‌وگو بدون وابستگی به متن
- فایل: `L02-123.weba`
- voice: `sage`
- slot: `data-audio-id="L02-123"`
- SHA256 متن UTF-8: `45a584fa74f356deb9f7a672340a637c209695c6e649829a92f847b0b492662e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
بار اول پذیرش هتل، اطلاعات اتاق را از روی متن اجرا کن. بار دوم، شمارهٔ اتاق و تعداد شب‌ها را عوض کن؛ مسئول پذیرش باید بتواند آن‌ها را از پاسخ تو یادداشت کند. در دور سوم، همراهِ مسافر کجا منتظر است؟ این اطلاعات را اضافه کن.
```

### L02-027 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-027.weba`
- voice: `sage`
- slot: `data-audio-id="L02-027"`
- SHA256 متن UTF-8: `57ad70d6a1779a3b8b92e2d6c27f8833d0fc8d511a99f0ba8a83d798b40f9f1f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you visiting Tehran?
```

### L02-028 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-028.weba`
- voice: `coral`
- slot: `data-audio-id="L02-028"`
- SHA256 متن UTF-8: `cc07850c5e9229139005fd230419a5d512fb253e67cf4cfd4d58100b9d016a20`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I am.
```

### L02-029 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-029.weba`
- voice: `sage`
- slot: `data-audio-id="L02-029"`
- SHA256 متن UTF-8: `a2212f6f24b08856e36384473e0dd4be678146b3c91296cba96560f67bc9c863`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are they traveling around the world?
```

### L02-030 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-030.weba`
- voice: `coral`
- slot: `data-audio-id="L02-030"`
- SHA256 متن UTF-8: `83bd74a8edebf079a11ad9bac1afe0db061fd1be4eb4d6f7cd6fe8eff71e362c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, they aren’t.
```

### L02-031 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-031.weba`
- voice: `sage`
- slot: `data-audio-id="L02-031"`
- SHA256 متن UTF-8: `ef534ebdde7b7e4f4e4ccf8517755d8acddf04eed9796dbc980697ec8ea4da9d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is Paul booking a room?
```

### L02-032 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-032.weba`
- voice: `coral`
- slot: `data-audio-id="L02-032"`
- SHA256 متن UTF-8: `581eddc9f18baa6bad84b8e708e2ad90b680db2c7f0c5c9be07daf52e15a31c2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, he is.
```

### L02-033 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-033.weba`
- voice: `sage`
- slot: `data-audio-id="L02-033"`
- SHA256 متن UTF-8: `d9b4915e4d79f139946a65a5d8c4ae8b3f25402d0cd08f4502c624c39540e86d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is Kate checking the map?
```

### L02-034 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-034.weba`
- voice: `coral`
- slot: `data-audio-id="L02-034"`
- SHA256 متن UTF-8: `8776ebd08cd5bec959733535258dbefbbdfc48496dd184be197b7b79885121fe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, she’s reading the guide book.
```

### L02-035 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-035.weba`
- voice: `sage`
- slot: `data-audio-id="L02-035"`
- SHA256 متن UTF-8: `93294623d095ffea99dec7c31d8f7de3b3136adfda8cb9934504ebc8a53502a6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is speaking English now?
```

### L02-036 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-036.weba`
- voice: `coral`
- slot: `data-audio-id="L02-036"`
- SHA256 متن UTF-8: `c6eb53bded531b474db8a4027c097761282e252c4ea4e377e6b6d5edd28b0089`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Sara.
```

### L02-037 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-037.weba`
- voice: `sage`
- slot: `data-audio-id="L02-037"`
- SHA256 متن UTF-8: `2cf8964d45b3d3d9935fecd00a9020d78a9dd22473fac7d3641b9d19c3790673`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What is he doing?
```

### L02-038 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-038.weba`
- voice: `coral`
- slot: `data-audio-id="L02-038"`
- SHA256 متن UTF-8: `86bc49c52d689fc40257cbdf265edb85a82c8c3a5fb2a374914de4d03ede6824`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He is buying a ticket.
```

### L02-039 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-039.weba`
- voice: `sage`
- slot: `data-audio-id="L02-039"`
- SHA256 متن UTF-8: `98640015a8d6f5520089374fb415515650c884757d68a9477905eaa8e313d8cc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is Ali going?
```

### L02-040 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-040.weba`
- voice: `coral`
- slot: `data-audio-id="L02-040"`
- SHA256 متن UTF-8: `c276656fed32307eb92c0d39dcc22fd01659ef0504fcb3f1d34adca40099a6c3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He’s going to Mehrabad Airport.
```

### L02-041 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-041.weba`
- voice: `sage`
- slot: `data-audio-id="L02-041"`
- SHA256 متن UTF-8: `5abff00c28a3f309d13738779a878490f0152be63e95d03a143d97c364b77fa4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What are you doing?
```

### L02-042 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-042.weba`
- voice: `coral`
- slot: `data-audio-id="L02-042"`
- SHA256 متن UTF-8: `90af6c241e436035b7b1e7c0b0504e2d47e205b7547f72b1d797294778584a71`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I’m filling out the reservation form.
```

### L02-043 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-043.weba`
- voice: `sage`
- slot: `data-audio-id="L02-043"`
- SHA256 متن UTF-8: `c0d301ebc034b46785f12f60ff9473f1dd03cf5e53c24d1be58ee30332788afa`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How are they traveling?
```

### L02-044 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-044.weba`
- voice: `coral`
- slot: `data-audio-id="L02-044"`
- SHA256 متن UTF-8: `494e94fd0990116c1dc9305a0b01b1eaf8d16534e4560708b341589760e74376`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They are traveling by train.
```

### L02-045 — آرتین — fa

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L02-045.weba`
- voice: `sage`
- slot: `data-audio-id="L02-045"`
- SHA256 متن UTF-8: `7a8391b3324eec55bef5af0acd634e6ea9eadfb36d9d2c936df12f44ce86dbe8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در کارت مصاحبهٔ این درس، Who is brave? مرور شخصیت از درس یک است؛ آن را به حال استمراری تبدیل نکن. سؤال دربارهٔ کارِ اکنون با What ... doing? هدف دیگری دارد.
```

### L02-046 — آرتین — fa

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-046.weba`
- voice: `sage`
- slot: `data-audio-id="L02-046"`
- SHA256 متن UTF-8: `c25311285908d461232747696a44e8b0dfab03e764c1689706efbc28a361f672`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
حال استمراری از سه بخش ساخته می‌شود: فاعل، am یا is یا are، و فعل دارای ing. فقط ing گذاشتن کافی نیست؛ be هم باید وجود داشته باشد. در جملهٔ مثبت، فعل اصلی برای he و she، s نمی‌گیرد.
```

### L02-047 — آرتین — en

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-047.weba`
- voice: `sage`
- slot: `data-audio-id="L02-047"`
- SHA256 متن UTF-8: `e12a3bb44db24b1e65fb2760c27c5eed45076b918a3584ed0f9403e6ad225da5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I am packing. She is packing. They are packing.
```

### L02-048 — آرتین — fa

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-048.weba`
- voice: `sage`
- slot: `data-audio-id="L02-048"`
- SHA256 متن UTF-8: `f35f47554d56f8d198aa50014cadad45c26dd949231982127d6698f9ac7766b9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
now و at the moment بافت اکنون را روشن می‌کنند، اما وجودشان اجباری نیست. living در متن کتاب، زندگی موقتیِ این دوره را نشان می‌دهد؛ لازم نیست فقط عملی چندثانیه‌ای باشد.
```

### L02-049 — آرتین — en

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-049.weba`
- voice: `sage`
- slot: `data-audio-id="L02-049"`
- SHA256 متن UTF-8: `c934c4ce6866cd3bcdd0124b0f7db3c10da6c2b2b7a81ef5f4ad6a8e53bab6f5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They are living in Spain now. We are staying here this week.
```

### L02-050 — آرتین — fa

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-050.weba`
- voice: `sage`
- slot: `data-audio-id="L02-050"`
- SHA256 متن UTF-8: `71194ca7514dfaea208b8d89ef9c41c2c6768d10a551d05ba2b157cf4f9e8626`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای منفی، not را بعد از be قرار بده. برای سؤال بله یا خیر، be را جلو بیاور. do و does را به این ساختار اضافه نکن؛ آن‌ها متعلق به الگوی دیگری هستند.
```

### L02-051 — آرتین — en

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: متن اصلی
- فایل: `L02-051.weba`
- voice: `sage`
- slot: `data-audio-id="L02-051"`
- SHA256 متن UTF-8: `c7509239b821e7ad1234b21c790de42af62917d63a6cb524e286433ecaee7401`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She is not booking a room. Is she booking a room? No, she isn’t.
```

### L02-124 — آرتین — fa

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-124.weba`
- voice: `sage`
- slot: `data-audio-id="L02-124"`
- SHA256 متن UTF-8: `3ab59203dc84778fe4463a86adaa59c6b5f8c397a5fcaf082e188f31a324b453`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
همین حالا سه کارِ قابل مشاهده را نام ببر. برای یک نفر is و برای چند نفر are بگذار؛ سپس یکی از کارها را نفی کن تا be از جمله حذف نشود.
```

### L02-125 — آرتین — en

- بخش: حال استمراری؛ کاری که اکنون جریان دارد (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-125.weba`
- voice: `sage`
- slot: `data-audio-id="L02-125"`
- SHA256 متن UTF-8: `e12a3bb44db24b1e65fb2760c27c5eed45076b918a3584ed0f9403e6ad225da5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I am packing. She is packing. They are packing.
```

### L02-052 — آرتین — fa

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-052.weba`
- voice: `sage`
- slot: `data-audio-id="L02-052"`
- SHA256 متن UTF-8: `e24d48904a595eb3d778deddeeffc99773506673f55c5c8fc8739e70b24907ce`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
بیشتر فعل‌ها فقط ing می‌گیرند: check به checking تبدیل می‌شود. اگر فعل به e ساکن تمام شود، e حذف می‌شود: write به writing و make به making تبدیل می‌شود.
```

### L02-053 — آرتین — en

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-053.weba`
- voice: `sage`
- slot: `data-audio-id="L02-053"`
- SHA256 متن UTF-8: `9ead373602a1e13cbd592fb58103776f9dc777ffc0dc9b03f1bd69fb6f336ce2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Checking. Writing. Making. She is writing a letter.
```

### L02-054 — آرتین — fa

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-054.weba`
- voice: `sage`
- slot: `data-audio-id="L02-054"`
- SHA256 متن UTF-8: `8531516e289982388dcf9577492c65f5ec265fbffee9d6817cd87bb8fbd562ef`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در فعل کوتاهی مثل run و sit با الگوی پایانِ واکهٔ کوتاه و یک همخوان، همخوان پایانی دو برابر می‌شود. این حکم را به همهٔ فعل‌ها تعمیم نده: opening و visiting در هجای آخر تکیه ندارند و حرف آخرشان دو برابر نمی‌شود.
```

### L02-055 — آرتین — en

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-055.weba`
- voice: `sage`
- slot: `data-audio-id="L02-055"`
- SHA256 متن UTF-8: `861b3b1a1f857478e15ac70309974e1ea46fb9d0cc10a21119c5918dbdf385c7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Run, running. Sit, sitting. Open, opening. Visit, visiting.
```

### L02-056 — آرتین — fa

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-056.weba`
- voice: `sage`
- slot: `data-audio-id="L02-056"`
- SHA256 متن UTF-8: `baf01faa366a8a0c53d022e1533a46841f206bc39a579e9ce358ccc1322b80fe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گفت‌وگو، I’m و he’s و they’re طبیعی‌اند. در پاسخ کوتاه مثبت، شکل کوتاه را در آخر جمله نگذار. برای منفی، she isn’t و she’s not هر دو درست‌اند.
```

### L02-057 — آرتین — en

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: متن اصلی
- فایل: `L02-057.weba`
- voice: `sage`
- slot: `data-audio-id="L02-057"`
- SHA256 متن UTF-8: `dd0091cd832642eed6d8a62592b7a182f6f23b87c8780a8c4359541fafeb13cd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you waiting? Yes, I am. Is she waiting? No, she’s not.
```

### L02-126 — آرتین — fa

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-126.weba`
- voice: `sage`
- slot: `data-audio-id="L02-126"`
- SHA256 متن UTF-8: `6fc64cff5a3924866bf7caac282db1712f6e366d9f44ecfedf8360c7df908c5a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از write، sit و open شکل ing بساز. برای هر تغییر املایی، دلیل بیاور: حذف e، دو برابر شدن همخوان یا افزودن سادهٔ ing. پاسخ‌ها را با جدول همین بخش مقایسه کن.
```

### L02-127 — آرتین — en

- بخش: ساختن ing؛ املا و شکل کوتاه (`spelling`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-127.weba`
- voice: `sage`
- slot: `data-audio-id="L02-127"`
- SHA256 متن UTF-8: `9ead373602a1e13cbd592fb58103776f9dc777ffc0dc9b03f1bd69fb6f336ce2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Checking. Writing. Making. She is writing a letter.
```

### L02-058 — آرتین — fa

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-058.weba`
- voice: `sage`
- slot: `data-audio-id="L02-058"`
- SHA256 متن UTF-8: `1689a99dbb6d8ee54ba05e4ba9891b6b5ad774baa645c31e698ff5aa3e1221fd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای پرسش اطلاعاتی، واژهٔ پرسشی را پیش از be بگذار. سپس فاعل و فعل ing می‌آیند. what عمل، where مقصد یا مکان و how روش یا وسیله را می‌پرسد.
```

### L02-059 — آرتین — en

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-059.weba`
- voice: `sage`
- slot: `data-audio-id="L02-059"`
- SHA256 متن UTF-8: `2241c5ef088c6e71146030679d8718675278cf861c7aa9a9ca20aafbc5ac4926`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What are you doing? Where is he going? How are they traveling?
```

### L02-060 — آرتین — fa

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-060.weba`
- voice: `sage`
- slot: `data-audio-id="L02-060"`
- SHA256 متن UTF-8: `a4b8361e272c98b228a4263b2fe27d85f09bde3275de55db30327680886c9736`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
وقتی خودِ انجام‌دهنده را نمی‌دانی، Who is speaking? یک پرسش کامل است؛ به فاعلِ اضافی مثل he نیاز ندارد. در پاسخ می‌توانی فقط نام را بگویی یا جملهٔ کامل بسازی.
```

### L02-061 — آرتین — en

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-061.weba`
- voice: `sage`
- slot: `data-audio-id="L02-061"`
- SHA256 متن UTF-8: `c295b5a1502ae8189d37097d5966fdc2c8b23d77a475a9c84443cf2a557762ab`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is speaking to the teacher? Sara is speaking to the teacher.
```

### L02-062 — آرتین — fa

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-062.weba`
- voice: `sage`
- slot: `data-audio-id="L02-062"`
- SHA256 متن UTF-8: `918c69e725a2d7e2232e40b9fe84062d6775f3ab2971cd24658d47f8af9100df`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
سؤال Where is she? صرفاً مکان را می‌پرسد و فعل ing ندارد. Where is she going? مقصدِ رفتن را می‌پرسد. از روی وجود کلمهٔ where به‌تنهایی زمان جمله را حدس نزن.
```

### L02-063 — آرتین — en

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: متن اصلی
- فایل: `L02-063.weba`
- voice: `sage`
- slot: `data-audio-id="L02-063"`
- SHA256 متن UTF-8: `aa0a1ef91daa8005bd931c7c698eb5cd6a1f4026d4f5dcb7a767e450dde0c052`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is she? At the hotel. Where is she going? To the airport.
```

### L02-128 — آرتین — fa

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-128.weba`
- voice: `sage`
- slot: `data-audio-id="L02-128"`
- SHA256 متن UTF-8: `dce24814d787e575b95df60cbaf1e6d36c45ccb8230f9353a05ca329f998088a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
Ali is going to Shiraz by train را مبنا بگیر. برای شخص، مقصد و وسیله سه سؤال متفاوت بساز؛ در هر پاسخ فقط اطلاعات مربوط به همان پرسش را انتخاب کن.
```

### L02-129 — آرتین — en

- بخش: پرسیدن عمل، مکان، وسیله و انجام‌دهنده (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-129.weba`
- voice: `sage`
- slot: `data-audio-id="L02-129"`
- SHA256 متن UTF-8: `2241c5ef088c6e71146030679d8718675278cf861c7aa9a9ca20aafbc5ac4926`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What are you doing? Where is he going? How are they traveling?
```

### L02-064 — آرتین — fa

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-064.weba`
- voice: `sage`
- slot: `data-audio-id="L02-064"`
- SHA256 متن UTF-8: `3e91f830071a30f67a14029765dea6aa128d91ee0a48d8ff6d07203f6253e681`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای مالکِ مفرد، پس از اسمِ صاحب، آپاستروف و s می‌آید. Kate’s scarf یعنی شالِ کیت. این s را با کوتاه‌شدهٔ is اشتباه نگیر؛ پس از آن به جای صفت، اسمِ چیزی که متعلق به فرد است می‌آید.
```

### L02-065 — آرتین — en

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-065.weba`
- voice: `sage`
- slot: `data-audio-id="L02-065"`
- SHA256 متن UTF-8: `bb93ee915cfdb2d184c84580be4825f3edc1b7a61608ba4b2f194d77ab6e3e5e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Kate’s scarf. Jack’s shirt. This is Jack’s bag.
```

### L02-066 — آرتین — fa

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-066.weba`
- voice: `sage`
- slot: `data-audio-id="L02-066"`
- SHA256 متن UTF-8: `03c059b95afaf0dbc7d81ab39e60ec7b35c0744d90c1180bd6ee169f89c40e4e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای اسم جمعی که s دارد، آپاستروف پس از s می‌آید: teachers’ office یعنی دفتر معلم‌ها. teacher’s office دربارهٔ یک معلم است. تلفظ این دو می‌تواند یکسان باشد ولی نوشتار صاحب را روشن می‌کند.
```

### L02-067 — آرتین — en

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-067.weba`
- voice: `sage`
- slot: `data-audio-id="L02-067"`
- SHA256 متن UTF-8: `0a627b44c3de796798f19a7f70b63cc6dd7dc201428fc36c4949971ce0deca4c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The teacher’s office. The teachers’ office.
```

### L02-068 — آرتین — fa

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-068.weba`
- voice: `sage`
- slot: `data-audio-id="L02-068"`
- SHA256 متن UTF-8: `143be8f8b35ed1d757bd321288987700204dde3f6c35e77b8b0d1b977356d208`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای اجزای اشیا، الگوی of در این درس کاربردی است. ابتدا جزء و سپس کل می‌آید: the door of the room. شکلِ your با آپاستروف نوشته نمی‌شود.
```

### L02-069 — آرتین — en

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: متن اصلی
- فایل: `L02-069.weba`
- voice: `sage`
- slot: `data-audio-id="L02-069"`
- SHA256 متن UTF-8: `90cea6f791fbf0a90e53dba2b72b7db1f44df73210aae728660ee2188d3dbd19`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The wheels of the car. The legs of the chair. The door of the room.
```

### L02-130 — آرتین — fa

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-130.weba`
- voice: `sage`
- slot: `data-audio-id="L02-130"`
- SHA256 متن UTF-8: `29189b6293643a219e4c82481f90ab99e2cf5fa9822235a9c60e397820ec4e93`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
یک شال برای Kate و یک دفتر برای چند teacher تصور کن. دو عبارت مالکیت بنویس و جای آپاستروف را مشخص کن؛ سپس برای چرخ‌های خودرو از of استفاده کن.
```

### L02-131 — آرتین — en

- بخش: مالکیت؛ apostrophe و of (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L02-131.weba`
- voice: `sage`
- slot: `data-audio-id="L02-131"`
- SHA256 متن UTF-8: `bb93ee915cfdb2d184c84580be4825f3edc1b7a61608ba4b2f194d77ab6e3e5e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Kate’s scarf. Jack’s shirt. This is Jack’s bag.
```

### L02-070 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-070.weba`
- voice: `sage`
- slot: `data-audio-id="L02-070"`
- SHA256 متن UTF-8: `8684f682edb7e984903448850706c9a5946feee491847cb79e4a2733bf9d2cea`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در receptionist، تکیه روی بخش دوم است. صدای آغاز واژه ضعیف می‌ماند؛ بخش مربوط به sep برجسته‌تر شنیده می‌شود. واژه را در عبارت کاملِ مسئول پذیرش تمرین کن.
```

### L02-071 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-071.weba`
- voice: `sage`
- slot: `data-audio-id="L02-071"`
- SHA256 متن UTF-8: `29d8ad6e8e8576f60bbb077ad21f6ce17c6117ff16e78d947fdabfea64553852`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Receptionist. A receptionist. Talk to a receptionist.
```

### L02-072 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-072.weba`
- voice: `sage`
- slot: `data-audio-id="L02-072"`
- SHA256 متن UTF-8: `b2eac572862f594513a92e5fc02da96e33a9eb6a16d38d4424e1645b8a58aafe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پایان visiting و booking با صدای بینیِ پشت دهان تمام می‌شود. پس از آن گِ جداگانه اضافه نکن. در speaking حرف k پیش از همین پایان وجود دارد و باید حفظ شود.
```

### L02-073 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-073.weba`
- voice: `sage`
- slot: `data-audio-id="L02-073"`
- SHA256 متن UTF-8: `ad29378c145520d86d0448c31a65bbb5bd999075b1336153490556f39842f071`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Visiting. Booking. Speaking. We are visiting Tehran.
```

### L02-074 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-074.weba`
- voice: `sage`
- slot: `data-audio-id="L02-074"`
- SHA256 متن UTF-8: `c8d522f95805aed19f4545348f7a768265003bec4d7a0f7d8da9f1b5ecdd50f9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در پرسش بله یا خیر با be، پایان صدا در الگوی این درس معمولاً بالا می‌رود. روی آخرین واژهٔ مهم حرکت آهنگ را نشان بده؛ نیازی نیست تمام جمله را بلندتر فریاد بزنی.
```

### L02-075 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 2 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L02-075.weba`
- voice: `sage`
- slot: `data-audio-id="L02-075"`
- SHA256 متن UTF-8: `49c0b2ef36e6d9ac9f95a60373f0edae04aed478b1773bf581774fddad8cecfe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you staying here? Is she searching for a hotel?
```

### L02-076 — Kiana — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-076.weba`
- voice: `nova`
- slot: `data-audio-id="L02-076"`
- SHA256 متن UTF-8: `7638a3ae03e0e6df6af03aea52ac3367c6d8c6691b9e07a827efecab3415bff8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you working with the computer now?
```

### L02-077 — Sara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-077.weba`
- voice: `nova`
- slot: `data-audio-id="L02-077"`
- SHA256 متن UTF-8: `a80e3263aa7748da5d03b9dc5e92547ddd76cbdc48116e44c4a0e24831307302`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I’m searching for a hotel in Sanandaj.
```

### L02-078 — Kiana — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-078.weba`
- voice: `nova`
- slot: `data-audio-id="L02-078"`
- SHA256 متن UTF-8: `094cedae99dc275e320ac4c3e7284558a62ba03192c291ad24d30162804ded56`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is it possible to book it online?
```

### L02-079 — Sara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-079.weba`
- voice: `nova`
- slot: `data-audio-id="L02-079"`
- SHA256 متن UTF-8: `cbffbaeabc8e164c69514b5d271e828e5734544195fec0aa0bde0b443eb56669`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, of course.
```

### L02-080 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-080.weba`
- voice: `sage`
- slot: `data-audio-id="L02-080"`
- SHA256 متن UTF-8: `304759e630218b60a32410d14230a8a2c4fd771b7af09f0de627add82d8497e0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is it a beautiful country?
```

### L02-081 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-081.weba`
- voice: `sage`
- slot: `data-audio-id="L02-081"`
- SHA256 متن UTF-8: `8cb671ea651a6f5e13a55c5bd2c7543c9bbd97c0d8a8215031d9a7ed5fdc1fe2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is he a tourist?
```

### L02-082 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-082.weba`
- voice: `sage`
- slot: `data-audio-id="L02-082"`
- SHA256 متن UTF-8: `ced9e5ad5b8726003664edcf6853f17058d81017b256907e26ec56dea9747d36`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you staying here?
```

### L02-083 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-083.weba`
- voice: `sage`
- slot: `data-audio-id="L02-083"`
- SHA256 متن UTF-8: `7c308fbf2b9fec4d3a681f32efc73a6b33823470e9284d11ad9ff5f89659aac9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is she searching for a hotel?
```

### L02-084 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-084.weba`
- voice: `sage`
- slot: `data-audio-id="L02-084"`
- SHA256 متن UTF-8: `17b92a6b14c59816e1b4657167730d0827e62c8ab2f890dbccd36d034a41fff5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are you traveling to Shiraz?
```

### L02-085 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-085.weba`
- voice: `sage`
- slot: `data-audio-id="L02-085"`
- SHA256 متن UTF-8: `ec16a939fa8535751ff93e55b473aeba7f9ac02c09df980a7db8b8345e939bb3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Are they checking out?
```

### L02-086 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L02-086.weba`
- voice: `sage`
- slot: `data-audio-id="L02-086"`
- SHA256 متن UTF-8: `1eef1baefc7ddb32c2b8b6373aac44e763a4138b5b5d3673a7c68278923d36f2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I am interested in travel. How about you?
```

### L02-132 — آرتین — fa

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: تمرین تکمیلی تلفظِ سفر
- فایل: `L02-132.weba`
- voice: `sage`
- slot: `data-audio-id="L02-132"`
- SHA256 متن UTF-8: `35810db46ab02131f95dbcbe4724ee888e104a99422dc07fc0fea290e5405db9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
عبارت talking to a receptionist را انتخاب کن. تکیهٔ receptionist و پایان ing را جدا بشنو؛ بعد کل جمله را بدون مکث مصنوعی میان حرف‌های کلمه اجرا کن.
```

### L02-087 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L02-087.weba`
- voice: `sage`
- slot: `data-audio-id="L02-087"`
- SHA256 متن UTF-8: `da94a650b93818a78339098e4c218815706bf5e0f99a20dad2a13a81d9422691`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
This is Paul. He is a tourist from Germany. He’s going into a gift shop with his wife. They are opening the door of the shop. Now, they’re talking to the shopkeeper to find suitable gifts for their daughters. Paul’s daughters are living in Spain now.
```

### L02-133 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: ترجمهٔ خواندنی
- فایل: `L02-133.weba`
- voice: `sage`
- slot: `data-audio-id="L02-133"`
- SHA256 متن UTF-8: `d192145ebd18f1fb55960c3549c40a2fd9f0be58192e7ca168354b11edbb6e2b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
این پل است؛ گردشگری از آلمان. او با همسرش وارد فروشگاه هدیه می‌شود. آن‌ها درِ فروشگاه را باز می‌کنند. اکنون با فروشنده صحبت می‌کنند تا برای دخترهایشان هدیه‌های مناسب پیدا کنند. دخترهای پل فعلاً در اسپانیا زندگی می‌کنند.
```

### L02-088 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L02-088.weba`
- voice: `sage`
- slot: `data-audio-id="L02-088"`
- SHA256 متن UTF-8: `87e63c82d6c4ae0aa1da65c830bccfa4b5e6e64abd2d50f25fe7e0d120186a3c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فقط گروه‌های حال استمراری را انتخاب کن؛ be و فعل ing را با هم ببین.
```

### L02-134 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L02-134.weba`
- voice: `sage`
- slot: `data-audio-id="L02-134"`
- SHA256 متن UTF-8: `a302414dfd8ca8823a87efc44a5adb200ac72b32c015bc0672a5a91530dd04f6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He’s going / are opening / they’re talking / are living
```

### L02-135 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L02-135.weba`
- voice: `sage`
- slot: `data-audio-id="L02-135"`
- SHA256 متن UTF-8: `ef64d0a9db3d3f8c8072936e6a24d45233d9cc4b255f63fdbec9f0583add1cdc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در این متن، گروه حال استمراری باید هم be و هم ing را داشته باشد؛ is a tourist وصف است و to find مصدر، پس در این انتخاب‌ها هدف نیستند.
```

### L02-089 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن اصلی
- فایل: `L02-089.weba`
- voice: `sage`
- slot: `data-audio-id="L02-089"`
- SHA256 متن UTF-8: `6ccebaaf8d9a8933937b0112e8d23f4a075aee7d5bf36ca77373c67ad0080462`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فایل رسمی شنیداری در PDF موجود نیست. دو متن این بخش برای تمرینِ سفر تألیف شده‌اند و کلید آن‌ها فقط مربوط به همین متن‌هاست. بار اول اطلاعات اصلی و بار دوم جزئیات پرسش‌ها را یادداشت کن.
```

### L02-090 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی A؛ پس از گوش دادن باز کن
- فایل: `L02-090.weba`
- voice: `sage`
- slot: `data-audio-id="L02-090"`
- SHA256 متن UTF-8: `f695dcae0f214207e68424adee72e7d634f708012fb76dcacea49cc3e03e7fc5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Brenda is from Canada. She is checking a hotel website. She cannot find the room price. She is asking the receptionist for help.
```

### L02-136 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی A
- فایل: `L02-136.weba`
- voice: `sage`
- slot: `data-audio-id="L02-136"`
- SHA256 متن UTF-8: `b0885369b8f53167a277a48a089c721e56c116616b35c3087606199a84c53f1a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
Canada؛ checking؛ نمی‌تواند قیمت اتاق را پیدا کند.
```

### L02-091 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی B؛ پس از گوش دادن باز کن
- فایل: `L02-091.weba`
- voice: `sage`
- slot: `data-audio-id="L02-091"`
- SHA256 متن UTF-8: `7ee5b9867241bc7f1a41a0fe2902c0a1b5e5aade553c8d9dff53a9dc75b80901`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Mehmet is from Turkey. He is going to Shiraz by train. He is asking about the timetable. His train leaves at ten.
```

### L02-137 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی B
- فایل: `L02-137.weba`
- voice: `sage`
- slot: `data-audio-id="L02-137"`
- SHA256 متن UTF-8: `36c7b80d2809fcea950e6d6d0cb1dde9e96b7d75fd8c497f227eeedfa5c3ff41`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
Turkey؛ Shiraz؛ جدول حرکت قطار.
```

### L02-092 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-092.weba`
- voice: `sage`
- slot: `data-audio-id="L02-092"`
- SHA256 متن UTF-8: `d30c08fe20f592210491b4727778797b001c67a307c42cc990c1bebbe0ded650`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What are you doing now?
```

### L02-093 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-093.weba`
- voice: `sage`
- slot: `data-audio-id="L02-093"`
- SHA256 متن UTF-8: `d56b69234d92433da256f2d1672a1f8747476781ed5ae410d9c89137601a9d04`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What is he/she doing?
```

### L02-094 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-094.weba`
- voice: `sage`
- slot: `data-audio-id="L02-094"`
- SHA256 متن UTF-8: `48f9bf6893de55daf9187c19427c35967aafcf1dabc38d917dc5315d060d2d6c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is brave?
```

### L02-095 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-095.weba`
- voice: `sage`
- slot: `data-audio-id="L02-095"`
- SHA256 متن UTF-8: `b2cabbfe0ee79372b283b8d62f8d3e979c2a37998b927b8531553ad9bea09437`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What’s our teacher doing?
```

### L02-096 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-096.weba`
- voice: `sage`
- slot: `data-audio-id="L02-096"`
- SHA256 متن UTF-8: `b8043ac4f53bbfd3d87f0492d12fc05985cfd5a20f1793df5756ff824d97eb3d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What is your best friend doing?
```

### L02-097 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-097.weba`
- voice: `sage`
- slot: `data-audio-id="L02-097"`
- SHA256 متن UTF-8: `b2d5243495d9369c1526dd908411d733c39395f287ecc59c560cd0b1556f6af7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is doing his/her homework?
```

### L02-098 — Tourist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-098.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-098"`
- SHA256 متن UTF-8: `e0579fadeffe7e237dc1c22bbb6f3f30d0ad29754413c59175e791e9b43bbe16`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Hello. I have a reservation for one night.
```

### L02-099 — Receptionist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-099.weba`
- voice: `sage`
- slot: `data-audio-id="L02-099"`
- SHA256 متن UTF-8: `9d1106df978b349b08e8c90879fa5ed66444745f8f0a0763a9f49eef8c14cdad`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Welcome. Are you traveling alone?
```

### L02-100 — Tourist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-100.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-100"`
- SHA256 متن UTF-8: `23e872e851ff6f9a69f3c6787225bc1cf49574e776ecff7bc2997317cc6a8915`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, I’m traveling with my sister.
```

### L02-101 — Receptionist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-101.weba`
- voice: `sage`
- slot: `data-audio-id="L02-101"`
- SHA256 متن UTF-8: `20a12451833cc24f141668b3487cbe84a78f849a3e1207a425dd4601e2d9fae2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is she now?
```

### L02-102 — Tourist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-102.weba`
- voice: `onyx`
- slot: `data-audio-id="L02-102"`
- SHA256 متن UTF-8: `5f6138a0a3449448cbd4217453e89345c5132a72a45f646aee995e8adf016d7c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She’s waiting by the door.
```

### L02-103 — Receptionist — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L02-103.weba`
- voice: `sage`
- slot: `data-audio-id="L02-103"`
- SHA256 متن UTF-8: `e67930d235f4b63a52e00e625ef54d4a7a40aaf7ec1b30f30f4694b8d35269c0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Please fill out this form.
```

### L02-138 — آرتین — fa

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: معیار اجرای مستقل در سفر
- فایل: `L02-138.weba`
- voice: `sage`
- slot: `data-audio-id="L02-138"`
- SHA256 متن UTF-8: `f0732f933c1de2afd849521133bb2130b44f81b0f1e1d9ec69dd97fdfc5da259`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای سنجش نقش سفر، یک مقصد، یک وسیله و یک کارِ در حال انجام تعیین کن. از هم‌صحبتت دو اطلاعاتی را بپرس که از قبل نمی‌دانی و یک جواب منفیِ طبیعی هم بده.
```

### L02-104 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-104.weba`
- voice: `sage`
- slot: `data-audio-id="L02-104"`
- SHA256 متن UTF-8: `56fe65094eaca4b31b27d8a07c52c6ab9ec7ff964c3399f662b23220ae99bf45`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
بعد از be فعلِ در حال انجام باید ing داشته باشد.
```

### L02-105 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-105.weba`
- voice: `sage`
- slot: `data-audio-id="L02-105"`
- SHA256 متن UTF-8: `6485f37d3ab21cfe260cdb558e2ec3b1249dedf0a485a522124a5b0679f5f69e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Sara is writing.
```

### L02-106 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-106.weba`
- voice: `sage`
- slot: `data-audio-id="L02-106"`
- SHA256 متن UTF-8: `60f710a6667cc188aa659c78d27cc2b5334ac70f1e18cfeb4d2125c6dc0c4dfd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
be خودش برای سؤال جلو می‌آید.
```

### L02-107 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-107.weba`
- voice: `sage`
- slot: `data-audio-id="L02-107"`
- SHA256 متن UTF-8: `e1e5d485b74a6f7fe155679bfa3249ccd7616821361d7bcd43ef34bea44fd6e4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is he traveling?
```

### L02-108 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-108.weba`
- voice: `sage`
- slot: `data-audio-id="L02-108"`
- SHA256 متن UTF-8: `cb70d6a4d8f99a5cdf16a6bba77f0ce9aa9c5cabdecac5a0f3879d28997dcaf3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جزء و کل، الگوی of را در این درس تمرین می‌کنیم؛ ساخت نخست لزوماً در همهٔ بافت‌ها غلط نیست.
```

### L02-109 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L02-109.weba`
- voice: `sage`
- slot: `data-audio-id="L02-109"`
- SHA256 متن UTF-8: `b9f3eeb82b203c0916c6655b5ea5b55f39df6b12a9f9edb591a6ef9aae491542`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The door of the room
```

### L02-110 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-110.weba`
- voice: `sage`
- slot: `data-audio-id="L02-110"`
- SHA256 متن UTF-8: `97de2f009c2591d1acb8c64ccd37b9b7c16f3bee5e5d120a00f4df7fb1bff525`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
weigh the baggage
```

### L02-111 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-111.weba`
- voice: `sage`
- slot: `data-audio-id="L02-111"`
- SHA256 متن UTF-8: `b65b073f75ff7ebce6cc58e08f1ab7173d3326b990258409bd765de00516dc1a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
baggage reclaim
```

### L02-112 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-112.weba`
- voice: `sage`
- slot: `data-audio-id="L02-112"`
- SHA256 متن UTF-8: `c58e977968ac11387f434f0c69e0d55b8b6b840a112f0de5196b77d5f661451d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
board the plane
```

### L02-113 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-113.weba`
- voice: `sage`
- slot: `data-audio-id="L02-113"`
- SHA256 متن UTF-8: `add526f391061107b1ae70d7851e862a425b2923ac7142442505981b1d774aab`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
make a voyage
```

### L02-114 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-114.weba`
- voice: `sage`
- slot: `data-audio-id="L02-114"`
- SHA256 متن UTF-8: `bb0280ea2729148994d8d89517a252d415b25d0fc1b621e1b4c803b0b32f4fa0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
take an express train
```

### L02-115 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L02-115.weba`
- voice: `sage`
- slot: `data-audio-id="L02-115"`
- SHA256 متن UTF-8: `a09b77a14010c47019c6b559637b74ffbbf524005510633559caaab372b88d01`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
pay toll
```

### L02-139 — آرتین — en

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L02-139.weba`
- voice: `sage`
- slot: `data-audio-id="L02-139"`
- SHA256 متن UTF-8: `5cca58aa7b3ee90de6151fc5eb5fe7471afda5496cecf74d0e18823125e1cefd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I am studying English now. My sister is reading. My parents are cooking. My brother is not watching TV. We are staying at home today.
```

### L02-140 — آرتین — fa

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L02-140.weba`
- voice: `sage`
- slot: `data-audio-id="L02-140"`
- SHA256 متن UTF-8: `1d0be65ffae113e6e98a9de02b456be0f37d1a2cf8d75c8a465f13657388e8c4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
متن سفر را از نظرِ وجود be، املای ing و پاسخ مرتبط به who، where و how بررسی کن؛ اگر اسم صاحب را نوشته‌ای، جای آپاستروف یا of را هم بسنج.
```

### L02-116 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L02-116.weba`
- voice: `sage`
- slot: `data-audio-id="L02-116"`
- SHA256 متن UTF-8: `94cd46c0708d89f19dfd72d3769f4badfaf935e18a54eedb809960601dc1aecb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She is talkative.
```

### L02-117 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L02-117.weba`
- voice: `sage`
- slot: `data-audio-id="L02-117"`
- SHA256 متن UTF-8: `f902d2d270b22d69798226dab5c3df314fb0ef70672b991c3b29cc95f4f0f250`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
There is a gift shop here.
```

### L02-118 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L02-118.weba`
- voice: `sage`
- slot: `data-audio-id="L02-118"`
- SHA256 متن UTF-8: `7ae0e16a9f7dc64acf6874c953016d0402bc9acf7076f37089b76bf6f45da41c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
John is reading a short story.
```

### L02-141 — آرتین — fa

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: مرور ارتباطیِ دو درس
- فایل: `L02-141.weba`
- voice: `sage`
- slot: `data-audio-id="L02-141"`
- SHA256 متن UTF-8: `c2bb7f3821386e291946f4851013eeed28aafa73db0c6c9c04c7c7a79e15fe18`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مرورِ سفر و شخصیت، یک گفت‌وگوی ترکیبی بساز. ابتدا اطلاعات را بپرس، سپس با همان زمانِ درست پاسخ بده. دو واژه از فرهنگ تصویری و یک ساختارِ بخش See also را هم به کار ببر.
```

### L02-119 — آرتین — fa

- بخش: جمع‌بندی و مرور فاصله‌دارِ سفر (`summary`)
- کادر: متن اصلی
- فایل: `L02-119.weba`
- voice: `sage`
- slot: `data-audio-id="L02-119"`
- SHA256 متن UTF-8: `7612eea0c5136b55388893543129d0f8e7d439ccc6b9f8967d983e88a6423389`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جمع‌بندیِ سفر، به‌جای بازخوانی کل صفحه، سه جمله از حافظه بساز: یک خبر، یک منفی و یک پرسش. روز بعد یکی از اطلاعات را عوض کن؛ سه روز بعد گفت‌وگوی تازه اجرا کن و هفتهٔ بعد آزمون را با نمونهٔ شخصی تکمیل کن.
```

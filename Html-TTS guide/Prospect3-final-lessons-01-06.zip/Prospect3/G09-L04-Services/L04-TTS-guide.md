# راهنمای کامل تولید و تزریق صوت؛ درس 4 — خدمات

تعداد قطعات: 144. این فایل تمام متن‌های گفتاری را دارد؛ ایجنت متن تازه ننویسد، تکرار یا خلاصه نکند. هر متن دقیقاً با p.tts-text در HTML برابر است. متن اصلی کتاب و شنیداری‌های تألیفی با هم اشتباه نشوند.

## پرامپت TTS

Read only the exact input. Do not add an introduction, summary, translation, music, or speaker label. Use fluent Iranian Persian for fa and clear General American English for en. Keep each character's voice fixed. Read dialogue as conversation. Use meaningful short pauses and a moderate teaching pace. Follow the delivery field for pronunciation and intonation. Never pronounce IDs, arrows or metadata.

## رابط و قرارداد فایل

نام مدرس آرتین و نام یادگیرنده رها است. کنترل ترجمه در همان ناحیه قرار دارد. همهٔ بخش‌های اصلی در منبع بسته‌اند؛ در اجرا فقط یکی باز و آخرین انتخاب ذخیره می‌شود. پنل فلوتر در وب‌ویو تمام‌صفحه است. هیچ پنل مدرس، تولید صوت، خوانش دستگاه، چاپ یا دانلود یادداشت به HTML اضافه نکن. هر آیکون داخل audio-block باید فقط صوت همان ID را پخش/مکث کند. پخش تازه باید صوت قبلی، از جمله ضبط شخصی، را متوقف کند.

متن‌های کادرهای کمکی، پاسخ‌های بازشونده و نکات تلفظی هم قطعات مستقل دارند. ترتیب clips ترتیب تدریس است؛ شماره‌ها را تغییر نده. برای هر قطعه یک فایل L04-NNN.weba و JSON منشأ لازم است. hash متن و فایل را کنترل کن؛ یکسان بودن نام فایل به‌تنهایی کافی نیست.

## کیفیت و حجم

ظرف WebM فقط صوتی، codec Opus، تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s و application=voip. تغییر پسوند MP3 به WebA تبدیل نیست. loudness هدف حدود -18 LUFS و true peak حداکثر -2 dBTP؛ اسکریپت از loudnorm تک‌مرحله‌ای استفاده می‌کند. خروجی را برای قطع نشدن کلمات، وضوح صداها و ثبات نقش‌ها بشنو. Base64 تقریباً یک‌سوم به حجم باینری اضافه می‌کند. موسیقی و افکت اضافه نکن.

## اجرا

نیازمند Python 3.10+، ffmpeg و ffprobe با libopus است. OPENAI_API_KEY فقط در محیطِ ایجنت تولیدکننده قرار بگیرد؛ در HTML و Markdown نوشته نشود. --generate درخواست شبکه‌ای هزینه‌دار دارد؛ --embed آفلاین است. در این تحویل هنوز صوت آموزشی نهایی تولید نشده است.

```bash
python tts_pipeline.py engl9-l04-services.html
python tts_pipeline.py engl9-l04-services.html --generate --only L04-001,L04-002 --audio-dir audio-l04
python tts_pipeline.py engl9-l04-services.html --generate --audio-dir audio-l04
python tts_pipeline.py engl9-l04-services.html --embed --audio-dir audio-l04 --output engl9-l04-services-with-audio.html
```

ابتدا فارسی و انگلیسی و دو نقشِ گفت‌وگو را نمونه‌گیری و شنیداری کنترل کن. صداهای سرویس مطابق voice هر قطعه‌اند؛ اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود. فایل خام را برای QA نگه دار. برای صوت وارداتی از ایجنت دیگر، پس از تطبیق انسانی متن می‌توان --accept-imports را هنگام embed به کار برد؛ این گزینه تشخیص خودکار صحت گفتار نیست.

```bash
ffmpeg -i source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L04-001.weba
```

## تزریق دقیق

manifest داخلی با id=tts-manifest را بخوان. اسکریپت متن HTML، SHA256 متن و SHA256 فایل را بررسی می‌کند. هر data-audio-id دقیقاً یک audio مخفی دارد. src آن باید data:audio/webm;codecs=opus;base64,... باشد. تمام صوت‌ها داخل همان HTML هستند؛ مسیر خارجی یا iframe نگذار. اسکریپت فایل ناقص را تحویل نمی‌دهد و منبع اصلی را بازنویسی نمی‌کند.

پس از تزریق، شمار audioهای دارای src باید با شمار manifest برابر باشد. یک بخش و یک کادر کمکی را باز کن؛ دکمه باید صوت همان قسمت را اجرا کند. پخش دو قسمت پشت‌سرهم باید اولی را قطع کند. شنیداری A و B بدون باز کردن متن قابل پخش‌اند. گوشی و دسکتاپ، سرعت، توقف، منوی تمام‌صفحه و حالت آفلاین را بررسی کن. تلفظ و نوبت دیالوگ به بازبینی انسانی نیاز دارند؛ آزمون فنیِ پخش به معنی تأیید تلفظ نیست.

## متن کامل قطعات

فقط متن کادر text را به سرویس بده؛ عنوان و metadata خوانده نشوند.

### L04-001 — آرتین — fa

- بخش: درس 4؛ خدمات و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L04-001.weba`
- voice: `sage`
- slot: `data-audio-id="L04-001"`
- SHA256 متن UTF-8: `c346f30d4fe23596b8ea03d50876668ba0914c350b7b7d5cf0bdcd32c8a96a5e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس «خدمات» می‌آموزی برای پیدا کردن خدمات شهری اطلاعات بگیری، دربارهٔ شغل و زمان کار سؤال بسازی و عادت‌ها را دقیق‌تر توصیف کنی.
```

### L04-002 — آرتین — en

- بخش: درس 4؛ خدمات و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L04-002.weba`
- voice: `sage`
- slot: `data-audio-id="L04-002"`
- SHA256 متن UTF-8: `8f954a4fc052cb2a2a89481e4f61fc0313268ab4bceea48f0fb5f9f8bbaa0169`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Lesson 4. Services. Use the language in a new situation.
```

### L04-123 — آرتین — fa

- بخش: درس 4؛ خدمات و هدف یادگیری (`goals`)
- کادر: مسیر پیشنهادی همین درس
- فایل: `L04-123.weba`
- voice: `sage`
- slot: `data-audio-id="L04-123"`
- SHA256 متن UTF-8: `d6d868d74846ebcba25c303d7d3d376b0b472fdd4318909269d944259454b738`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پیش از شروعِ خدمات، سنجش ورودی را انجام بده. کمتر از شش پاسخ درست از هشت یعنی مرور پل پیش‌نیاز لازم است. سپس به ترتیبِ فهرست پیش برو؛ پس از هر الگو، پاسخ خودت را پیش از باز کردن راه‌حل بساز.
```

### L04-003 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-003.weba`
- voice: `sage`
- slot: `data-audio-id="L04-003"`
- SHA256 متن UTF-8: `678e0fd152fb31c59c46371b304a7c6c0af28e358b7d3e4b9a5903fbcac6acd7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از پایه‌های هفتم و هشتم، نام شغل‌ها، ساعت، روزهای هفته و مکان‌های شهر را بازیابی کن. از درس سه، do و does و شکل سادهٔ فعل را لازم داری؛ از درس یک نیز پرسش با be را کنار آن‌ها نگه می‌داریم.
```

### L04-004 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-004.weba`
- voice: `sage`
- slot: `data-audio-id="L04-004"`
- SHA256 متن UTF-8: `955733e35b8e9192afb2d5996c39592ba389113d0f5c2712e64ce4af316d2157`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
معنی پرسش، نوع پاسخ را تعیین می‌کند. where مکان می‌خواهد و when زمان. what time زمان دقیق‌تری مثل ساعت می‌خواهد؛ why با دلیل جواب می‌گیرد.
```

### L04-005 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-005.weba`
- voice: `sage`
- slot: `data-audio-id="L04-005"`
- SHA256 متن UTF-8: `5f5daf048720fd0ca771171645807194fb2e0c19c81f490ca8b633c1981891e2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where? At school. When? On Monday. What time? At eight. Why? Because it is near.
```

### L04-006 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-006.weba`
- voice: `sage`
- slot: `data-audio-id="L04-006"`
- SHA256 متن UTF-8: `d86dcedc9965d443728d33b93c02c275f88e453cb14006f2674c2e4141eadeb3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از قبل می‌دانی she works درست است. وقتی does وارد سؤال می‌شود، works به work برمی‌گردد. در مقابل، برای She is a teacher سؤال با خود is ساخته می‌شود.
```

### L04-007 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-007.weba`
- voice: `sage`
- slot: `data-audio-id="L04-007"`
- SHA256 متن UTF-8: `ad7ff34e943aa460f949b4b37104577fda7a25b445072757611f45d86a42dac0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does she work here? Is she a teacher?
```

### L04-008 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-008.weba`
- voice: `sage`
- slot: `data-audio-id="L04-008"`
- SHA256 متن UTF-8: `0c9c4249601e82bf2f1f23c965409be58115be92494bdd0eb0927e704d76ffc1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
عبارت from Saturday to Wednesday یک بازه می‌سازد. at را برای ساعت و on را برای روز به کار ببر. این حرف‌های اضافه را به‌صورت تکه‌های کاربردی یاد بگیر.
```

### L04-009 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L04-009.weba`
- voice: `sage`
- slot: `data-audio-id="L04-009"`
- SHA256 متن UTF-8: `e74d9d483c22a58688873ae35f9c44e0db4ca6854134dcc65f0bd52bd4fe8428`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
At eight. On Sunday. From Saturday to Wednesday.
```

### L04-124 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L04-124.weba`
- voice: `sage`
- slot: `data-audio-id="L04-124"`
- SHA256 متن UTF-8: `7967c8bd7b43f278da3a5e01a4391f9a33892636faa4f33732dc7c73dbf19883`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
سه جواب بنویس: at eight، at a bank و because it is near. روبه‌روی هر جواب، واژهٔ پرسشی مناسب را قرار بده. حالا یکی را به سؤال کامل با do یا does تبدیل کن.
```

### L04-125 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L04-125.weba`
- voice: `sage`
- slot: `data-audio-id="L04-125"`
- SHA256 متن UTF-8: `5f5daf048720fd0ca771171645807194fb2e0c19c81f490ca8b633c1981891e2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where? At school. When? On Monday. What time? At eight. Why? Because it is near.
```

### L04-010 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-010.weba`
- voice: `sage`
- slot: `data-audio-id="L04-010"`
- SHA256 متن UTF-8: `b23625476be506167cd0bd09f2f671432b809ded2a8c239b6347f5802452417d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
call the emergency. They call the emergency number.
```

### L04-011 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-011.weba`
- voice: `sage`
- slot: `data-audio-id="L04-011"`
- SHA256 متن UTF-8: `5d16873a260154ad685905f755d71b1a0ae72542878dea444188f69e2992a3ce`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
send an e-mail. I send an e-mail to my teacher.
```

### L04-012 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-012.weba`
- voice: `sage`
- slot: `data-audio-id="L04-012"`
- SHA256 متن UTF-8: `ed771bf72af39a8b3572e102f6a8b77f5b260d69eb26c33162b6b2afc49cab69`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
take out money. She takes out money from an ATM.
```

### L04-013 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-013.weba`
- voice: `sage`
- slot: `data-audio-id="L04-013"`
- SHA256 متن UTF-8: `c50e2b6e31a8f43008a518251c33c0531789fb066cbce178a8061ad65a76de8e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
get on a bus. We get on a bus near school.
```

### L04-014 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-014.weba`
- voice: `sage`
- slot: `data-audio-id="L04-014"`
- SHA256 متن UTF-8: `54f66774a6e79c046bcaa724d7b539e6a126e9fbd1d383f20b2c1c62563f4dc3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
get off a bus. He gets off the bus here.
```

### L04-015 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-015.weba`
- voice: `sage`
- slot: `data-audio-id="L04-015"`
- SHA256 متن UTF-8: `706301b9ca944285a9f2701734d50dccb7f9a65122a5eb83c573a3636955724c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
hire a taxi. They hire a taxi at the airport.
```

### L04-016 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-016.weba`
- voice: `sage`
- slot: `data-audio-id="L04-016"`
- SHA256 متن UTF-8: `14d97b980a7f548420c2b7e3d12491513a5526d392941bbe13451d5027402e38`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
open an account. My father opens an account at a bank.
```

### L04-017 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-017.weba`
- voice: `sage`
- slot: `data-audio-id="L04-017"`
- SHA256 متن UTF-8: `c6c2ed577c215d118f54d8c5fce491994a642b2629f713f2b05f723a80f2fca3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
put out fire. Firefighters put out fires.
```

### L04-018 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-018.weba`
- voice: `sage`
- slot: `data-audio-id="L04-018"`
- SHA256 متن UTF-8: `4687d1d8144a311ca046cda53cd280bc28fd6916b5be7f1436c934f8ed04e2bb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
recharge the E-ticket. I recharge my E-ticket every week.
```

### L04-019 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L04-019.weba`
- voice: `sage`
- slot: `data-audio-id="L04-019"`
- SHA256 متن UTF-8: `241c06787e80195428cef4b1faf80db1f23ce8465bac51f7a9d799425cd387be`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
ask the information desk. We ask the information desk for help.
```

### L04-020 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-020.weba`
- voice: `onyx`
- slot: `data-audio-id="L04-020"`
- SHA256 متن UTF-8: `49f1d9397a407dd9b63eca4bff094e74e47668fdf997abe6a174cc3a1625c6e1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Excuse me sir! Can you help me please?
```

### L04-021 — Pedram — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-021.weba`
- voice: `echo`
- slot: `data-audio-id="L04-021"`
- SHA256 متن UTF-8: `12a109e734fbf8fc1c9cf532fb043b68b9512626771502823e81d5534c6c9f1a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What can I do for you?
```

### L04-022 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-022.weba`
- voice: `onyx`
- slot: `data-audio-id="L04-022"`
- SHA256 متن UTF-8: `068677df1619857677147f7e7ec6459b717b69a9b81c370b050abc1e8d42f250`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I want a postcard, an envelope and a stamp.
```

### L04-023 — Pedram — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-023.weba`
- voice: `echo`
- slot: `data-audio-id="L04-023"`
- SHA256 متن UTF-8: `aed194b8003e921130f0a87bd85ebb58d51eaf19ebdbe0503bc28f960083e5a3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Umm…, you can get them from a post office.
```

### L04-024 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-024.weba`
- voice: `onyx`
- slot: `data-audio-id="L04-024"`
- SHA256 متن UTF-8: `6c4fac1a20d7245ebed34ba70a74beaa96526805852ad0ab924ebb8adcc8a736`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is the post office?
```

### L04-025 — Pedram — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-025.weba`
- voice: `echo`
- slot: `data-audio-id="L04-025"`
- SHA256 متن UTF-8: `18e99bbadafe21600f4734e20410589b25dfb8ac7e1c7e3a2e44bcc9569653e2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Actually it’s near here. It’s just round the corner.
```

### L04-026 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-026.weba`
- voice: `onyx`
- slot: `data-audio-id="L04-026"`
- SHA256 متن UTF-8: `b7afdefaafad39d6b864913e2c744d9465af1a7a1c481932831eddfbd2f19a74`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Good! Thank you. What time does it open?
```

### L04-027 — Pedram — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-027.weba`
- voice: `echo`
- slot: `data-audio-id="L04-027"`
- SHA256 متن UTF-8: `d2929c5da194d4113bfc3c74f9c06adaf78a2aa7ddb247e60b78e9b881d42289`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It opens at 8.
```

### L04-028 — Tourist — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L04-028.weba`
- voice: `onyx`
- slot: `data-audio-id="L04-028"`
- SHA256 متن UTF-8: `42949dbe12d63b39a6c88017ffe327f1c1e32397a6a56d9b2e9ce44647e6e783`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Thanks a lot!
```

### L04-126 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: اجرای گفت‌وگو بدون وابستگی به متن
- فایل: `L04-126.weba`
- voice: `sage`
- slot: `data-audio-id="L04-126"`
- SHA256 متن UTF-8: `ffcb6808f84d2605269dc0e0ccf053e9c178aee1782d9efd51857280a6d15924`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گفت‌وگوی پست، جای اداره و ساعت شروع را روی کارت بنویس. یکی گردشگر و دیگری راهنما باشد؛ راهنما کارت خود را نشان ندهد و گردشگر اطلاعات را فقط با پرسش به دست بیاورد.
```

### L04-029 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-029.weba`
- voice: `sage`
- slot: `data-audio-id="L04-029"`
- SHA256 متن UTF-8: `9f9c33d5ed6f06504ee575e2cea1014b94226ac759eb9d26acdf4bffb5b88c84`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What is her job?
```

### L04-030 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-030.weba`
- voice: `coral`
- slot: `data-audio-id="L04-030"`
- SHA256 متن UTF-8: `ec4ba897f2e068aac449e51da52d7cc6098922dc25d46c2305b37c07021262ad`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She’s an employee.
```

### L04-031 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-031.weba`
- voice: `sage`
- slot: `data-audio-id="L04-031"`
- SHA256 متن UTF-8: `6c4fac1a20d7245ebed34ba70a74beaa96526805852ad0ab924ebb8adcc8a736`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is the post office?
```

### L04-032 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-032.weba`
- voice: `coral`
- slot: `data-audio-id="L04-032"`
- SHA256 متن UTF-8: `d3abcc877084b296eb8bca13d93f95c678033cf1f44a27777560ebf7d3fe52dc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It’s over there.
```

### L04-033 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-033.weba`
- voice: `sage`
- slot: `data-audio-id="L04-033"`
- SHA256 متن UTF-8: `d87ec707e55bebc67c49aaef2cb169cb85a339c7cc81f31811fc2c71b4dc808c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who’s that man?
```

### L04-034 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-034.weba`
- voice: `coral`
- slot: `data-audio-id="L04-034"`
- SHA256 متن UTF-8: `92b72813c8009695350923290e00ea790ee4f6d481770686368675032ad09011`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He is a postman.
```

### L04-035 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-035.weba`
- voice: `sage`
- slot: `data-audio-id="L04-035"`
- SHA256 متن UTF-8: `8e91f6b0a0a25dae0a95d759b43d574cdffe591db761747c946f0f908629c407`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When is the break?
```

### L04-036 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-036.weba`
- voice: `coral`
- slot: `data-audio-id="L04-036"`
- SHA256 متن UTF-8: `74473803b10bbc635d3dcb80aead6c896390fee63f6a5444450a8a06691c1e96`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It’s at 9:30.
```

### L04-037 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-037.weba`
- voice: `sage`
- slot: `data-audio-id="L04-037"`
- SHA256 متن UTF-8: `a1aa3e7afdab62fcea3d6540ad23b1f52cbb1c8f90845edb8af5ce2044238ac8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What time does it open?
```

### L04-038 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-038.weba`
- voice: `coral`
- slot: `data-audio-id="L04-038"`
- SHA256 متن UTF-8: `4327bb85f54b7c7dce7bf32951838009d19fb7676ce6141404a11b43f5f65c78`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It opens at 8 in the morning.
```

### L04-039 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-039.weba`
- voice: `sage`
- slot: `data-audio-id="L04-039"`
- SHA256 متن UTF-8: `5cb98801ebb784121619734145f307f68f2b640aea7deb5e40f7fbbfcf22c5ca`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When do they work?
```

### L04-040 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-040.weba`
- voice: `coral`
- slot: `data-audio-id="L04-040"`
- SHA256 متن UTF-8: `b5d33d9106800ed5e58e8172b5a68cc949acbb40f71000b5f61da28ccf2f75e6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They work from Saturday to Wednesday.
```

### L04-041 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-041.weba`
- voice: `sage`
- slot: `data-audio-id="L04-041"`
- SHA256 متن UTF-8: `e392441b7008824e46284476cd4811b7cf8050aaac0183c3e82d649a6b30fdf8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helps lost children?
```

### L04-042 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-042.weba`
- voice: `coral`
- slot: `data-audio-id="L04-042"`
- SHA256 متن UTF-8: `a980527fc1f32e8c5bfca4a028288c119573a5d93b86677f5cee6e236b219cc3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The police help them.
```

### L04-043 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-043.weba`
- voice: `sage`
- slot: `data-audio-id="L04-043"`
- SHA256 متن UTF-8: `d5ecc3719b87534b69ab22c2db456bc2d06a7f6553a4d8bb4953d64dcb3cdc33`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where does she buy stamps?
```

### L04-044 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-044.weba`
- voice: `coral`
- slot: `data-audio-id="L04-044"`
- SHA256 متن UTF-8: `884f0f4da316331f088bf44c6cbcf77d64c035bc5d26b9fd97281b6d61d132a7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She buys them from a post office.
```

### L04-045 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-045.weba`
- voice: `sage`
- slot: `data-audio-id="L04-045"`
- SHA256 متن UTF-8: `40a28ee05d05d137231bcf1ad81052c0b55d72a6bdec096f5693dd0beab08934`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why does he go to work by bus?
```

### L04-046 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-046.weba`
- voice: `coral`
- slot: `data-audio-id="L04-046"`
- SHA256 متن UTF-8: `04d260072ccf5366b586c2352f01cc5c1662974c1b545d62af4987214d5e9062`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Because it’s fast and cheap.
```

### L04-047 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-047.weba`
- voice: `sage`
- slot: `data-audio-id="L04-047"`
- SHA256 متن UTF-8: `e4e681aa48ae180434171f98750d310ac35efc094df9bb8f31b53f86c584283b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How do you come to school?
```

### L04-048 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L04-048.weba`
- voice: `coral`
- slot: `data-audio-id="L04-048"`
- SHA256 متن UTF-8: `c12fe4b608a7a7a16a4af31179aaf65532734b468b9db9fad3aea0b18fb1938a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I take a bus.
```

### L04-049 — آرتین — fa

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-049.weba`
- voice: `sage`
- slot: `data-audio-id="L04-049"`
- SHA256 متن UTF-8: `fadd01655bc94cd67fc673cd27b5fa04f53852cf6d911f23af6064b2fd69857f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای پرسیدن مکانِ یک کار، where را پیش از do یا does بگذار. فاعل پس از فعل کمکی و فعل اصلی به شکل پایه در ادامه می‌آید. علامت سؤال در پایان قرار می‌گیرد.
```

### L04-050 — آرتین — en

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-050.weba`
- voice: `sage`
- slot: `data-audio-id="L04-050"`
- SHA256 متن UTF-8: `e0f048ca9bb389fe98e1ace0c19ccbf4794e3fe08125e7c9c279672227687ce7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do they work? Where does she work?
```

### L04-051 — آرتین — fa

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-051.weba`
- voice: `sage`
- slot: `data-audio-id="L04-051"`
- SHA256 متن UTF-8: `acbb24bf61903feb12c1ea37b71c5799833cad75b663bc92e6ac01444041ebf4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در What does your father do?، does نخست فعل کمکی است و do پایانی به معنی انجام دادن. این پرسش معمولاً شغل را می‌پرسد. پاسخ می‌تواند یک شغل با be یا توضیح کار با فعل اصلی باشد.
```

### L04-052 — آرتین — en

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-052.weba`
- voice: `sage`
- slot: `data-audio-id="L04-052"`
- SHA256 متن UTF-8: `c721dc2ed300b4b0b4541a884662d0f2dd123cdf95652a58d1d8b47ed04b453d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What does your father do? He is a teacher. He teaches English.
```

### L04-053 — آرتین — fa

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-053.weba`
- voice: `sage`
- slot: `data-audio-id="L04-053"`
- SHA256 متن UTF-8: `d55840eddd853e0f6057e8650510021dacf22355518a0f91a774971fd902e26e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای why دلیل و برای how روش لازم است. پاسخ Because it’s cheap دلیل می‌دهد؛ پاسخ By bus وسیله را نشان می‌دهد. فقط داشتن جملهٔ درست کافی نیست؛ باید اطلاعات مناسبِ پرسش را بدهی.
```

### L04-054 — آرتین — en

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: متن اصلی
- فایل: `L04-054.weba`
- voice: `sage`
- slot: `data-audio-id="L04-054"`
- SHA256 متن UTF-8: `ed8cf962f544f58d1f71dbceaaa993397944e8c90add89d6e3093577c2e276ed`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why does he take a bus? Because it’s cheap. How does he go? By bus.
```

### L04-127 — آرتین — fa

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-127.weba`
- voice: `sage`
- slot: `data-audio-id="L04-127"`
- SHA256 متن UTF-8: `8a36a4b5267356e05fdc553a1b0f0086759e382239b6cca89afe7203d3adf772`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای یک کارمند فرضی سه داده تعیین کن: بانک، ساعت هشت و رفتن با اتوبوس. با where، what time و how از او سؤال کن؛ فعل اصلی در کنار does بدون s بماند.
```

### L04-128 — آرتین — en

- بخش: پرسش Wh با فعل اصلی (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-128.weba`
- voice: `sage`
- slot: `data-audio-id="L04-128"`
- SHA256 متن UTF-8: `e0f048ca9bb389fe98e1ace0c19ccbf4794e3fe08125e7c9c279672227687ce7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do they work? Where does she work?
```

### L04-055 — آرتین — fa

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-055.weba`
- voice: `sage`
- slot: `data-audio-id="L04-055"`
- SHA256 متن UTF-8: `2a3ecbd49bbe52cdca2ecb15b8461027973f46dcabe6887981365a8640d66f03`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
وقتی جملهٔ پایه be دارد، do و does لازم نیست. ترتیبِ پرسش، واژهٔ پرسشی، be و فاعل است. برای چند چیز are و برای یک چیز is می‌آید.
```

### L04-056 — آرتین — en

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-056.weba`
- voice: `sage`
- slot: `data-audio-id="L04-056"`
- SHA256 متن UTF-8: `bf4e7f66d43219fc4b61bf5b98af30c69baaa23664b318ce887a7fcbef404b5b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is the bank? What are those? Who is that man?
```

### L04-057 — آرتین — fa

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-057.weba`
- voice: `sage`
- slot: `data-audio-id="L04-057"`
- SHA256 متن UTF-8: `91c78b8b17de857d9a605bbcaf542b1d5f52cf1176899b9360b70b94eddc9cd4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در Who helps children?، who خودش فاعل است؛ does اضافه نمی‌کنیم. اما در Who does Sara help? فاعل Sara معلوم است و دربارهٔ مفعول می‌پرسیم، پس does لازم می‌شود.
```

### L04-058 — آرتین — en

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-058.weba`
- voice: `sage`
- slot: `data-audio-id="L04-058"`
- SHA256 متن UTF-8: `828025516fc9d31c2a0404f018fc1d45696789a855bf2b827e8548e97b0e0392`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helps Sara? Her teacher. Who does Sara help? Her brother.
```

### L04-059 — آرتین — fa

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-059.weba`
- voice: `sage`
- slot: `data-audio-id="L04-059"`
- SHA256 متن UTF-8: `5f8cba12d462ce27a8fee15ca63300d6686cc6e8d9d4685abd89603d296d6d4e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
آیا از هویت فرد می‌پرسی یا از کار او؟ Who is he? با What does he do? فرق دارد. در اولی می‌توان نام فرد را گفت؛ در دومی شغل یا کار او را توضیح می‌دهیم.
```

### L04-060 — آرتین — en

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: متن اصلی
- فایل: `L04-060.weba`
- voice: `sage`
- slot: `data-audio-id="L04-060"`
- SHA256 متن UTF-8: `d088bbd4107fe449986a6b1a9ceef07154c919feda3bc24e26529211318719a9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is he? He is Amir. What does he do? He is a postman.
```

### L04-129 — آرتین — fa

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-129.weba`
- voice: `sage`
- slot: `data-audio-id="L04-129"`
- SHA256 متن UTF-8: `44ba0ec4beb83910cb0beec3cefd049e6907fbd81ea45efa3569d062a8b85390`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
دو پرسش بساز که یکی دربارهٔ کمک‌کننده و دیگری دربارهٔ کسی باشد که سارا به او کمک می‌کند. در اولی Who helps و در دومی Who does Sara help را مقایسه کن.
```

### L04-130 — آرتین — en

- بخش: پرسش با be و پرسش فاعلی Who (`wh`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-130.weba`
- voice: `sage`
- slot: `data-audio-id="L04-130"`
- SHA256 متن UTF-8: `bf4e7f66d43219fc4b61bf5b98af30c69baaa23664b318ce887a7fcbef404b5b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where is the bank? What are those? Who is that man?
```

### L04-061 — آرتین — fa

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-061.weba`
- voice: `sage`
- slot: `data-audio-id="L04-061"`
- SHA256 متن UTF-8: `694ff92b7bce89c235231cfb2296ec959f94a0b88042fc4c369845b48751eb6a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
قید تکرار معمولاً پیش از فعل اصلی قرار می‌گیرد، اما پس از be می‌آید. جای always را در این دو ساختار مقایسه کن؛ از یک ترتیب ثابت برای هر دو استفاده نکن.
```

### L04-062 — آرتین — en

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-062.weba`
- voice: `sage`
- slot: `data-audio-id="L04-062"`
- SHA256 متن UTF-8: `b9a7081ee0b88bb74c5f1c1069986b2fc1023ede9b8bf061e9fca9e104013256`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She always studies hard. We are sometimes busy.
```

### L04-063 — آرتین — fa

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-063.weba`
- voice: `sage`
- slot: `data-audio-id="L04-063"`
- SHA256 متن UTF-8: `5a7dd45bc93619ecb320f4863f0cccf53620fb644d8d41ff0b2a6456840550ed`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
always یعنی همیشه و never یعنی هرگز. usually، often و sometimes به‌ترتیب معمولاً، اغلب و گاهی را می‌رسانند؛ درصد دقیق آن‌ها به بافت وابسته است. نمودار کتاب برای نشان دادن ترتیب فراوانی است.
```

### L04-064 — آرتین — en

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-064.weba`
- voice: `sage`
- slot: `data-audio-id="L04-064"`
- SHA256 متن UTF-8: `6a6581acc58c306398313dc42054a58d9e9a9c01ca6dcac8e9dbb96e9031332c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Always. Usually. Often. Sometimes. Never.
```

### L04-065 — آرتین — fa

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-065.weba`
- voice: `sage`
- slot: `data-audio-id="L04-065"`
- SHA256 متن UTF-8: `61fa8c2335c9458daa7a1720a14cf528af28a5979a661cbbe8225975d103de26`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
never خودش معنی منفی دارد. برای گفتن او هرگز دیر نمی‌آید، معمولاً don’t یا doesn’t را دوباره وارد نمی‌کنیم.
```

### L04-066 — آرتین — en

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: متن اصلی
- فایل: `L04-066.weba`
- voice: `sage`
- slot: `data-audio-id="L04-066"`
- SHA256 متن UTF-8: `d35c3c01a20ed580e2fb457df30c099570bd98dd9553a9f975bbe25919987900`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He never comes late. They never come late.
```

### L04-131 — آرتین — fa

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-131.weba`
- voice: `sage`
- slot: `data-audio-id="L04-131"`
- SHA256 متن UTF-8: `226f28032c3cedf94ad814bb4ca7870b562c137cc3389d362d040795fd1fbed7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
با always دو جمله بساز: یکی با be و یکی با study. جای قید را با جدول بررسی کن؛ سپس جمله‌ای با never بنویس که don’t یا doesn’t اضافی نداشته باشد.
```

### L04-132 — آرتین — en

- بخش: قید تکرار؛ هر چند وقت یک بار؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-132.weba`
- voice: `sage`
- slot: `data-audio-id="L04-132"`
- SHA256 متن UTF-8: `b9a7081ee0b88bb74c5f1c1069986b2fc1023ede9b8bf061e9fca9e104013256`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She always studies hard. We are sometimes busy.
```

### L04-067 — آرتین — fa

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: متن اصلی
- فایل: `L04-067.weba`
- voice: `sage`
- slot: `data-audio-id="L04-067"`
- SHA256 متن UTF-8: `1be372886dd6918aba2d8856b3cbfd9e53e9c726f05af2972a029fdf03bcc901`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای زمان دقیق از at و برای روز هفته از on استفاده کن. when می‌تواند روز یا بازه بپرسد؛ what time معمولاً ساعت می‌خواهد. در نقش‌آفرینی، اطلاعات تخیلی و مشخص بده تا طرف مقابل بتواند پاسخ را ثبت کند.
```

### L04-068 — آرتین — en

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: متن اصلی
- فایل: `L04-068.weba`
- voice: `sage`
- slot: `data-audio-id="L04-068"`
- SHA256 متن UTF-8: `63ad1b6d578be8314ab3811c967df91a1d1fe58184c47002212f682672f00913`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
At nine thirty. On Tuesday. From eight to four.
```

### L04-069 — آرتین — fa

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: متن اصلی
- فایل: `L04-069.weba`
- voice: `sage`
- slot: `data-audio-id="L04-069"`
- SHA256 متن UTF-8: `d3b078df8eba2887c9de0631b4065d358059b1364f0fed7f43ab0c25bd091eed`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
Excuse me برای آغاز درخواست توجه است. Can you help me please? و I’d like to know about ... قالب‌های مؤدبانه‌اند؛ پس از درخواست، پاسخ مرتبط و تشکر کوتاه کافی است.
```

### L04-070 — آرتین — en

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: متن اصلی
- فایل: `L04-070.weba`
- voice: `sage`
- slot: `data-audio-id="L04-070"`
- SHA256 متن UTF-8: `7c044740ac0fdc46bd983948ef12b788ad9c78848e0ddbab164e146d0ca500fa`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Excuse me. Can you help me please? I’d like to know about the timetable.
```

### L04-133 — آرتین — fa

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-133.weba`
- voice: `sage`
- slot: `data-audio-id="L04-133"`
- SHA256 متن UTF-8: `6a10a6f71ff2cdb10ef2899e67c895e135c4a3079b9dda148d7ec6b6721a314c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
ساعت و روز را از هم جدا کن: برای 9:30 از at و برای Tuesday از on استفاده کن. یک درخواست مؤدبانهٔ آدرس و یک پاسخ کوتاه با همان دو داده بساز.
```

### L04-134 — آرتین — en

- بخش: زمان، مکان و درخواست مؤدبانه (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L04-134.weba`
- voice: `sage`
- slot: `data-audio-id="L04-134"`
- SHA256 متن UTF-8: `63ad1b6d578be8314ab3811c967df91a1d1fe58184c47002212f682672f00913`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
At nine thirty. On Tuesday. From eight to four.
```

### L04-071 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-071.weba`
- voice: `sage`
- slot: `data-audio-id="L04-071"`
- SHA256 متن UTF-8: `289d09cabc68d841402ba75dc24e51cfd778fface6fb6ee29e31cf3999be8eff`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در پرسش‌های Wh معمولِ این درس، پایان جمله پایین می‌آید. کلمهٔ پرسشی را واضح بگو و اطلاعات مهم جمله را برجسته کن. خیزان شدن آهنگ ممکن است در درخواست تکرار رخ دهد؛ پس این الگو را قانونِ بدون استثنا ندان.
```

### L04-072 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-072.weba`
- voice: `sage`
- slot: `data-audio-id="L04-072"`
- SHA256 متن UTF-8: `8a3c56fa8403394eadff24e3cb81cf66cf97f9be770684476bacd898a01ff375`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do you live? What time does it open?
```

### L04-073 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-073.weba`
- voice: `sage`
- slot: `data-audio-id="L04-073"`
- SHA256 متن UTF-8: `aaaa2acb4970a1a51eb7d97e092ee9351ff78d7188d7ee1a1013c593974e7d48`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
employee در بخش آخر برجسته است، اما postman معمولاً روی بخش اول تکیه دارد. برای شغل‌ها، تکیه را همراه معنی واژه حفظ کن.
```

### L04-074 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-074.weba`
- voice: `sage`
- slot: `data-audio-id="L04-074"`
- SHA256 متن UTF-8: `e2bf2d8b501ba884686cf272bda6ad46b4b5f0cbd89f0d0c0e5e9122b5ed3bb3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Employee. Postman. She is an employee. He is a postman.
```

### L04-075 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-075.weba`
- voice: `sage`
- slot: `data-audio-id="L04-075"`
- SHA256 متن UTF-8: `a3a1d80f12ac73e6762630d03ca5764bb357af164bf1c52370fa961631695d75`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در عبارت get on، صدای پایانی get به آغاز on متصل می‌شود. در get off هم پیوستگی را حفظ کن، ولی on و off را واضح از هم جدا کن چون جهت حرکت را عوض می‌کنند.
```

### L04-076 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 4 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L04-076.weba`
- voice: `sage`
- slot: `data-audio-id="L04-076"`
- SHA256 متن UTF-8: `0c2e64a6993a45a16d9fe1432623c85178b8d03aafaf8bf52a5713d2fc071612`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Get on the bus. Get off the bus.
```

### L04-077 — Clara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-077.weba`
- voice: `echo`
- slot: `data-audio-id="L04-077"`
- SHA256 متن UTF-8: `b6d01c5180f4cd13e75278048793dd1f23a0aef4db3310c58d24f9123ca678db`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Excuse me sir! I’m lost.
```

### L04-078 — Police officer — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-078.weba`
- voice: `nova`
- slot: `data-audio-id="L04-078"`
- SHA256 متن UTF-8: `8fed958cf05bb1254e6d5d356ad5a2782f83872926f6a116e3d439b4fc4a5bc7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Don’t worry. What’s your name?
```

### L04-079 — Clara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-079.weba`
- voice: `echo`
- slot: `data-audio-id="L04-079"`
- SHA256 متن UTF-8: `deb3f71db3faa4af78f4eb02cc4f85fca2a56f8899d6ec865b0fbd71a753567d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My name’s Clara.
```

### L04-080 — Police officer — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-080.weba`
- voice: `nova`
- slot: `data-audio-id="L04-080"`
- SHA256 متن UTF-8: `8a38c81b46381d2693666843c8bd213c5d9be3cb02fd1cf73bba5ae9f84b05de`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do you live?
```

### L04-081 — Clara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-081.weba`
- voice: `echo`
- slot: `data-audio-id="L04-081"`
- SHA256 متن UTF-8: `2e20bf22f1a66e458557a2c1b14964335992230ecec4ead823666a27c117e18f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
On Main Street, near the gas station.
```

### L04-082 — Police officer — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-082.weba`
- voice: `nova`
- slot: `data-audio-id="L04-082"`
- SHA256 متن UTF-8: `fe33780e2c414a97179351409dd15f428a3f821ebd651b7e3548371f404e47f5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Don’t worry. I can take you home.
```

### L04-083 — Clara — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-083.weba`
- voice: `echo`
- slot: `data-audio-id="L04-083"`
- SHA256 متن UTF-8: `4a047138ff201d729450a9dc1a3aba4d57e1a6700903c4b9626b0ed7359c863a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Thank you sir.
```

### L04-084 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-084.weba`
- voice: `sage`
- slot: `data-audio-id="L04-084"`
- SHA256 متن UTF-8: `f1308ce0cf77aa9d2d72e967d7cc38a03c6739ced96cd965c79f54efc98093f1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What’s your name?
```

### L04-085 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-085.weba`
- voice: `sage`
- slot: `data-audio-id="L04-085"`
- SHA256 متن UTF-8: `9b181de483e0da61391cd385f16383f953401fdfee8ca2c46297bd812f3e0b5d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How old are you?
```

### L04-086 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-086.weba`
- voice: `sage`
- slot: `data-audio-id="L04-086"`
- SHA256 متن UTF-8: `8a38c81b46381d2693666843c8bd213c5d9be3cb02fd1cf73bba5ae9f84b05de`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do you live?
```

### L04-087 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-087.weba`
- voice: `sage`
- slot: `data-audio-id="L04-087"`
- SHA256 متن UTF-8: `71480774a90a5e0370051078ef6fe31b8a246ba43ea72199e1c55ef47e00d7ff`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why are you here?
```

### L04-088 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-088.weba`
- voice: `sage`
- slot: `data-audio-id="L04-088"`
- SHA256 متن UTF-8: `2ae6eb2eed2fecf22f00823bb35d1d1c9be6f9cd3ca30f7d2dd6015d7f9075c5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When does it open?
```

### L04-089 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-089.weba`
- voice: `sage`
- slot: `data-audio-id="L04-089"`
- SHA256 متن UTF-8: `99fa9f9d32d611f115a42ceb5229bb644deccaf629431f31ba55ab375f9ffa8c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who is that man?
```

### L04-090 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L04-090.weba`
- voice: `sage`
- slot: `data-audio-id="L04-090"`
- SHA256 متن UTF-8: `b8a4c3cb3f9bcaf5ad0bb54f36ea1cca4a14137f529bfc2b89440647a8f4475e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I’d like to know about your job.
```

### L04-135 — آرتین — fa

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: تمرین تکمیلی تلفظِ خدمات
- فایل: `L04-135.weba`
- voice: `sage`
- slot: `data-audio-id="L04-135"`
- SHA256 متن UTF-8: `524c828a9434c24eb971dca5745e37ee64e18c9087fd995a193013d63cb1426c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
یک پرسش Where و یک سؤال بله یا خیر دربارهٔ بانک بگو. افت انتهای پرسش Wh را با خیزِ پرسش بله یا خیر مقایسه کن، نه با بلند و آهسته کردنِ بی‌هدف صدا.
```

### L04-091 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L04-091.weba`
- voice: `sage`
- slot: `data-audio-id="L04-091"`
- SHA256 متن UTF-8: `35dacf579983150a0e0d8b37cd102f2b68fdc54d01679f1ce768571f3f1b0a64`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Parsa: What’s your favorite job? Hamid: I like to be a firefighter. Parsa: What does a firefighter do? Hamid: He puts out fire and saves people’s lives. Parsa: And is it an easy job?! Hamid: No! Actually it’s very hard. Parsa: When does a firefighter go to work? Hamid: I think he goes to work on shifts. Parsa: Oh! Where does he work? Hamid: At a fire station. Parsa: Is there a fire station near here? Hamid: Yes, there’s one over there.
```

### L04-136 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: ترجمهٔ خواندنی
- فایل: `L04-136.weba`
- voice: `sage`
- slot: `data-audio-id="L04-136"`
- SHA256 متن UTF-8: `458e9b9b194501d80a66fd0ac208f6de5af4e02e0603c328cff6b15a648b9e04`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پارسا شغل موردعلاقهٔ حمید را می‌پرسد. حمید می‌خواهد آتش‌نشان باشد؛ آتش را خاموش کند و جان مردم را نجات دهد. او می‌گوید این کار سخت است، کار به‌صورت شیفتی انجام می‌شود و محل آن ایستگاه آتش‌نشانی است. در پایان دربارهٔ وجود ایستگاه در نزدیکی سؤال می‌کنند.
```

### L04-092 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L04-092.weba`
- voice: `sage`
- slot: `data-audio-id="L04-092"`
- SHA256 متن UTF-8: `6da81278b06b2f11d207d007380159028d05547bc1206d19a883a8663c380dfe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
چهار پرسش Wh را از سؤال‌های بله یا خیر جدا کن.
```

### L04-137 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L04-137.weba`
- voice: `sage`
- slot: `data-audio-id="L04-137"`
- SHA256 متن UTF-8: `b391420ada69f595d3531aa1ff74acd1a0853045fff28ed8c88acaa7871e047c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What’s your favorite job? / What does a firefighter do? / When does a firefighter go to work? / Where does he work?
```

### L04-138 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L04-138.weba`
- voice: `sage`
- slot: `data-audio-id="L04-138"`
- SHA256 متن UTF-8: `37142bd4691ecc0a69aa73f452d10cd9d4330f50cd2b68bdbbe70713c0116129`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مصاحبهٔ شغل، چهار پرسش با واژهٔ پرسشی داریم. پرسش‌های Is it ... و Is there ... بله یا خیر هستند و در انتخاب Wh قرار نمی‌گیرند.
```

### L04-093 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن اصلی
- فایل: `L04-093.weba`
- voice: `sage`
- slot: `data-audio-id="L04-093"`
- SHA256 متن UTF-8: `b0ecfa51b8e94ebc932536153ec8070d595a380208e2882cb963692f1dcb8a39`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فایل رسمی شنیداری در PDF موجود نیست. دو متن این بخش برای تمرینِ خدمات تألیف شده‌اند و کلید آن‌ها فقط مربوط به همین متن‌هاست. بار اول اطلاعات اصلی و بار دوم جزئیات پرسش‌ها را یادداشت کن.
```

### L04-094 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی A؛ پس از گوش دادن باز کن
- فایل: `L04-094.weba`
- voice: `sage`
- slot: `data-audio-id="L04-094"`
- SHA256 متن UTF-8: `c9ac9d4762251ff1b7c43010413cd93c42230f1f646dc0c870edcccefb32bb3c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My father is a bank employee. He works at a bank near our house. His work starts at eight in the morning. He usually goes to work by bus.
```

### L04-139 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی A
- فایل: `L04-139.weba`
- voice: `sage`
- slot: `data-audio-id="L04-139"`
- SHA256 متن UTF-8: `8dc505819ec7ae6ce4b67c4dc3c7378deec8413b019e0f7cdf3adfa6420fb7c8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
کارمند بانک؛ در بانک نزدیک خانه؛ شروع کار ساعت هشت.
```

### L04-095 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی B؛ پس از گوش دادن باز کن
- فایل: `L04-095.weba`
- voice: `sage`
- slot: `data-audio-id="L04-095"`
- SHA256 متن UTF-8: `33da67704ac49e93b3f8e9365812765fd186315176655a22d873a4b4c2cd0f03`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Amir is a firefighter in our practice story. He works at a fire station. He goes to work on shifts. Today his shift starts at seven in the morning and finishes at seven in the evening.
```

### L04-140 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی B
- فایل: `L04-140.weba`
- voice: `sage`
- slot: `data-audio-id="L04-140"`
- SHA256 متن UTF-8: `bf8061a67770bae8845edfc042723bb3dae5addd293c0db3b68b2540478b5730`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
آتش‌نشان؛ ایستگاه آتش‌نشانی؛ به‌صورت شیفتی؛ شیفت امروز از هفت صبح تا هفت عصر.
```

### L04-096 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-096.weba`
- voice: `sage`
- slot: `data-audio-id="L04-096"`
- SHA256 متن UTF-8: `f1308ce0cf77aa9d2d72e967d7cc38a03c6739ced96cd965c79f54efc98093f1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What’s your name?
```

### L04-097 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-097.weba`
- voice: `sage`
- slot: `data-audio-id="L04-097"`
- SHA256 متن UTF-8: `a052a8a6fd2160e0e96b4b20c6ab970ecab775f026367832298458891651d3e5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What do you do?
```

### L04-098 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-098.weba`
- voice: `sage`
- slot: `data-audio-id="L04-098"`
- SHA256 متن UTF-8: `9b181de483e0da61391cd385f16383f953401fdfee8ca2c46297bd812f3e0b5d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How old are you?
```

### L04-099 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-099.weba`
- voice: `sage`
- slot: `data-audio-id="L04-099"`
- SHA256 متن UTF-8: `8a38c81b46381d2693666843c8bd213c5d9be3cb02fd1cf73bba5ae9f84b05de`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where do you live?
```

### L04-100 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-100.weba`
- voice: `sage`
- slot: `data-audio-id="L04-100"`
- SHA256 متن UTF-8: `a8c1a10d5cc6862f3504bd46332443b1c03c3e44b41a15e1c515c5ebcfbc3b1e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What time do you wake up?
```

### L04-101 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-101.weba`
- voice: `sage`
- slot: `data-audio-id="L04-101"`
- SHA256 متن UTF-8: `4ad96c9470ffbe39c071acab05f0f4b191ace58446b062a45b6ca37b9d153d4c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why do you learn English?
```

### L04-102 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-102.weba`
- voice: `sage`
- slot: `data-audio-id="L04-102"`
- SHA256 متن UTF-8: `b21f3180812cda0ed2ef7c00186c0b3dc4dd67d7078025042525ac88f47a991d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When does your school start?
```

### L04-103 — Visitor — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-103.weba`
- voice: `nova`
- slot: `data-audio-id="L04-103"`
- SHA256 متن UTF-8: `50a7ef95e7b4d2f4359953f0ce1940ad75be6e203e63ac296ddaef8497d798ce`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Excuse me. Where is the bank?
```

### L04-104 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-104.weba`
- voice: `sage`
- slot: `data-audio-id="L04-104"`
- SHA256 متن UTF-8: `b86a34d26f89b8a1f62f6d2f011b2bb5401cef4dda5c3e373d688afc51172ee3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It’s near the library.
```

### L04-105 — Visitor — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-105.weba`
- voice: `nova`
- slot: `data-audio-id="L04-105"`
- SHA256 متن UTF-8: `a1aa3e7afdab62fcea3d6540ad23b1f52cbb1c8f90845edb8af5ce2044238ac8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What time does it open?
```

### L04-106 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-106.weba`
- voice: `sage`
- slot: `data-audio-id="L04-106"`
- SHA256 متن UTF-8: `2d2ccd6bc43634920103343ec7bf73730b7a3edaa704c685605080d2f93e5329`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It opens at eight.
```

### L04-107 — Visitor — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-107.weba`
- voice: `nova`
- slot: `data-audio-id="L04-107"`
- SHA256 متن UTF-8: `2c9ba57dc5a63ed23f00895dd5a52abf8f7f25bf6b6c9fb2fb1f0876778d4c73`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How do I get there?
```

### L04-108 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L04-108.weba`
- voice: `sage`
- slot: `data-audio-id="L04-108"`
- SHA256 متن UTF-8: `89fc1795cfc37ea3620aa6fb4140bc7e20deee3ee4b72d775a62b0aacb2aa227`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
You can take a bus.
```

### L04-141 — آرتین — fa

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: معیار اجرای مستقل در خدمات
- فایل: `L04-141.weba`
- voice: `sage`
- slot: `data-audio-id="L04-141"`
- SHA256 متن UTF-8: `691ffcf7e22f85bfa00d6edf114e44ee03aac3327ea39696658d747bde729329`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مصاحبهٔ خدمات، از نام، شغل، محل و ساعت کار بپرس. پاسخ‌دهنده باید با اطلاعات دقیق جواب بدهد؛ به هر پرسش فقط اطلاعاتی را بده که همان واژهٔ پرسشی می‌خواهد.
```

### L04-109 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-109.weba`
- voice: `sage`
- slot: `data-audio-id="L04-109"`
- SHA256 متن UTF-8: `9d79b9927e41dce628112d5f168a871845ec2314944c0596bebd60c6df65a8b8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای پرسشِ معیار، does و شکل پایه لازم است.
```

### L04-110 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-110.weba`
- voice: `sage`
- slot: `data-audio-id="L04-110"`
- SHA256 متن UTF-8: `7187607b25a01abc2adae990db1aa5d4714f4e7fd88d6f172386c2f81f6a3425`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where does she work?
```

### L04-111 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-111.weba`
- voice: `sage`
- slot: `data-audio-id="L04-111"`
- SHA256 متن UTF-8: `dcc6e347f223a5b0540c371a14aad9425d79d4c1ea876b420ac5c97b4014ff01`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
who در این جمله فاعل است؛ does حذف می‌شود.
```

### L04-112 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-112.weba`
- voice: `sage`
- slot: `data-audio-id="L04-112"`
- SHA256 متن UTF-8: `d15b2faffafe06d8b331ffd6510b7c92f1409af2f07840f11c7c1b8ca950b4ea`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who helps them?
```

### L04-113 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-113.weba`
- voice: `sage`
- slot: `data-audio-id="L04-113"`
- SHA256 متن UTF-8: `242cc8fc5ee4245f7b50377f7db6d56a45c53e4307c70bcbaec7874544c846f8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
never کافی است؛ در جملهٔ مثبت سوم‌شخص، come به comes تبدیل می‌شود.
```

### L04-114 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L04-114.weba`
- voice: `sage`
- slot: `data-audio-id="L04-114"`
- SHA256 متن UTF-8: `336c976770d3c4966383ea08f226ba4b0b70009370a4dc3075db68926792707e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He never comes late.
```

### L04-115 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L04-115.weba`
- voice: `sage`
- slot: `data-audio-id="L04-115"`
- SHA256 متن UTF-8: `4b8f1812e780f74b054e8f1ef82317fdba7019bc527c58b81bafdcb09ef2b691`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
donate blood
```

### L04-116 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L04-116.weba`
- voice: `sage`
- slot: `data-audio-id="L04-116"`
- SHA256 متن UTF-8: `cd249d10a54e69e2b9abe86096e76ed4c55c500c5d7cd6231377cbb449156d50`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
do voluntary work
```

### L04-117 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L04-117.weba`
- voice: `sage`
- slot: `data-audio-id="L04-117"`
- SHA256 متن UTF-8: `684d36796a0e2490d949d61afaa698e012a2717011313daa74103b5ae5d0c7bc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
help charity
```

### L04-118 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L04-118.weba`
- voice: `sage`
- slot: `data-audio-id="L04-118"`
- SHA256 متن UTF-8: `463c6caa48086c73c5145254656ff8880834e47350fbe7a38850d1a3093fc452`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
bring to the ER
```

### L04-119 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L04-119.weba`
- voice: `sage`
- slot: `data-audio-id="L04-119"`
- SHA256 متن UTF-8: `fc925dcda96ea2cb3873ca66ed51a697253a5c5926d1772ecb4b473b93313c75`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
keep the city clean
```

### L04-142 — آرتین — en

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L04-142.weba`
- voice: `sage`
- slot: `data-audio-id="L04-142"`
- SHA256 متن UTF-8: `717dca54d9a84ce5b2a1cf1cf117d31f3db32f5c11652e469bd41d83a004780c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I recharge my E-ticket every week. My mother sends e-mails. Our bank opens at eight. Firefighters help people. We keep our street clean.
```

### L04-143 — آرتین — fa

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L04-143.weba`
- voice: `sage`
- slot: `data-audio-id="L04-143"`
- SHA256 متن UTF-8: `33f4c55c0092bc99440154b3d92edb1a1d900ad5261b6635999068d0da9a9246`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در متن خدمات، مطمئن شو پرسش‌های Wh ساخت کامل دارند و جای قید تکرار با نوع فعل هماهنگ است. ساعت و روز را نیز با at و on درست بنویس.
```

### L04-120 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L04-120.weba`
- voice: `sage`
- slot: `data-audio-id="L04-120"`
- SHA256 متن UTF-8: `ce9649437b4c9dd748c76439d27cb64ee3525443edde22fbeff8c14ea88283de`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Mary enjoys New Year holidays.
```

### L04-121 — آرتین — en

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: متن اصلی
- فایل: `L04-121.weba`
- voice: `sage`
- slot: `data-audio-id="L04-121"`
- SHA256 متن UTF-8: `d23557462eb8042c0ecef81185bb5022863361ce144eeaa94528f5cbe7de19a8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Alex helps his mother a lot.
```

### L04-144 — آرتین — fa

- بخش: مرور دو درس و تمرین انتقال (`review`)
- کادر: مرور ارتباطیِ دو درس
- فایل: `L04-144.weba`
- voice: `sage`
- slot: `data-audio-id="L04-144"`
- SHA256 متن UTF-8: `fc37bd6d1aece53c6507fc715272f8cf090d1f3974e76c5d90f0689c23c616ca`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مرورِ خدمات و جشن‌ها و مراسم، یک گفت‌وگوی ترکیبی بساز. ابتدا اطلاعات را بپرس، سپس با همان زمانِ درست پاسخ بده. دو واژه از فرهنگ تصویری و یک ساختارِ بخش See also را هم به کار ببر.
```

### L04-122 — آرتین — fa

- بخش: جمع‌بندی و مرور فاصله‌دارِ خدمات (`summary`)
- کادر: متن اصلی
- فایل: `L04-122.weba`
- voice: `sage`
- slot: `data-audio-id="L04-122"`
- SHA256 متن UTF-8: `5f16700b205427530acffd2f569268221291427b2eabb3584748936b226a983a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جمع‌بندیِ خدمات، به‌جای بازخوانی کل صفحه، سه جمله از حافظه بساز: یک خبر، یک منفی و یک پرسش. روز بعد یکی از اطلاعات را عوض کن؛ سه روز بعد گفت‌وگوی تازه اجرا کن و هفتهٔ بعد آزمون را با نمونهٔ شخصی تکمیل کن.
```

# راهنمای کامل تولید و تزریق صوت؛ درس 3 — جشن‌ها و مراسم

تعداد قطعات: 135. این فایل تمام متن‌های گفتاری را دارد؛ ایجنت متن تازه ننویسد، تکرار یا خلاصه نکند. هر متن دقیقاً با p.tts-text در HTML برابر است. متن اصلی کتاب و شنیداری‌های تألیفی با هم اشتباه نشوند.

## پرامپت TTS

Read only the exact input. Do not add an introduction, summary, translation, music, or speaker label. Use fluent Iranian Persian for fa and clear General American English for en. Keep each character's voice fixed. Read dialogue as conversation. Use meaningful short pauses and a moderate teaching pace. Follow the delivery field for pronunciation and intonation. Never pronounce IDs, arrows or metadata.

## رابط و قرارداد فایل

نام مدرس آرتین و نام یادگیرنده رها است. کنترل ترجمه در همان ناحیه قرار دارد. همهٔ بخش‌های اصلی در منبع بسته‌اند؛ در اجرا فقط یکی باز و آخرین انتخاب ذخیره می‌شود. پنل فلوتر در وب‌ویو تمام‌صفحه است. هیچ پنل مدرس، تولید صوت، خوانش دستگاه، چاپ یا دانلود یادداشت به HTML اضافه نکن. هر آیکون داخل audio-block باید فقط صوت همان ID را پخش/مکث کند. پخش تازه باید صوت قبلی، از جمله ضبط شخصی، را متوقف کند.

متن‌های کادرهای کمکی، پاسخ‌های بازشونده و نکات تلفظی هم قطعات مستقل دارند. ترتیب clips ترتیب تدریس است؛ شماره‌ها را تغییر نده. برای هر قطعه یک فایل L03-NNN.weba و JSON منشأ لازم است. hash متن و فایل را کنترل کن؛ یکسان بودن نام فایل به‌تنهایی کافی نیست.

## کیفیت و حجم

ظرف WebM فقط صوتی، codec Opus، تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s و application=voip. تغییر پسوند MP3 به WebA تبدیل نیست. loudness هدف حدود -18 LUFS و true peak حداکثر -2 dBTP؛ اسکریپت از loudnorm تک‌مرحله‌ای استفاده می‌کند. خروجی را برای قطع نشدن کلمات، وضوح صداها و ثبات نقش‌ها بشنو. Base64 تقریباً یک‌سوم به حجم باینری اضافه می‌کند. موسیقی و افکت اضافه نکن.

## اجرا

نیازمند Python 3.10+، ffmpeg و ffprobe با libopus است. OPENAI_API_KEY فقط در محیطِ ایجنت تولیدکننده قرار بگیرد؛ در HTML و Markdown نوشته نشود. --generate درخواست شبکه‌ای هزینه‌دار دارد؛ --embed آفلاین است. در این تحویل هنوز صوت آموزشی نهایی تولید نشده است.

```bash
python tts_pipeline.py engl9-l03-festivals-and-ceremonies.html
python tts_pipeline.py engl9-l03-festivals-and-ceremonies.html --generate --only L03-001,L03-002 --audio-dir audio-l03
python tts_pipeline.py engl9-l03-festivals-and-ceremonies.html --generate --audio-dir audio-l03
python tts_pipeline.py engl9-l03-festivals-and-ceremonies.html --embed --audio-dir audio-l03 --output engl9-l03-festivals-and-ceremonies-with-audio.html
```

ابتدا فارسی و انگلیسی و دو نقشِ گفت‌وگو را نمونه‌گیری و شنیداری کنترل کن. صداهای سرویس مطابق voice هر قطعه‌اند؛ اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود. فایل خام را برای QA نگه دار. برای صوت وارداتی از ایجنت دیگر، پس از تطبیق انسانی متن می‌توان --accept-imports را هنگام embed به کار برد؛ این گزینه تشخیص خودکار صحت گفتار نیست.

```bash
ffmpeg -i source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L03-001.weba
```

## تزریق دقیق

manifest داخلی با id=tts-manifest را بخوان. اسکریپت متن HTML، SHA256 متن و SHA256 فایل را بررسی می‌کند. هر data-audio-id دقیقاً یک audio مخفی دارد. src آن باید data:audio/webm;codecs=opus;base64,... باشد. تمام صوت‌ها داخل همان HTML هستند؛ مسیر خارجی یا iframe نگذار. اسکریپت فایل ناقص را تحویل نمی‌دهد و منبع اصلی را بازنویسی نمی‌کند.

پس از تزریق، شمار audioهای دارای src باید با شمار manifest برابر باشد. یک بخش و یک کادر کمکی را باز کن؛ دکمه باید صوت همان قسمت را اجرا کند. پخش دو قسمت پشت‌سرهم باید اولی را قطع کند. شنیداری A و B بدون باز کردن متن قابل پخش‌اند. گوشی و دسکتاپ، سرعت، توقف، منوی تمام‌صفحه و حالت آفلاین را بررسی کن. تلفظ و نوبت دیالوگ به بازبینی انسانی نیاز دارند؛ آزمون فنیِ پخش به معنی تأیید تلفظ نیست.

## متن کامل قطعات

فقط متن کادر text را به سرویس بده؛ عنوان و metadata خوانده نشوند.

### L03-001 — آرتین — fa

- بخش: درس 3؛ جشن‌ها و مراسم و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L03-001.weba`
- voice: `sage`
- slot: `data-audio-id="L03-001"`
- SHA256 متن UTF-8: `973bd69b3e325811ab60da2a7716cfbcf43d2322dfedff22873fd7ebbc668aa8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس «جشن‌ها و مراسم» می‌آموزی دربارهٔ رسم‌ها و کارهای تکراری حرف بزنی، با do و does سؤال بسازی و صاحبِ چیزها را مشخص کنی.
```

### L03-002 — آرتین — en

- بخش: درس 3؛ جشن‌ها و مراسم و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L03-002.weba`
- voice: `sage`
- slot: `data-audio-id="L03-002"`
- SHA256 متن UTF-8: `f0156c63c837b7271c2c7c54e6f962300d658cb1223bf3864cd7aeca5be67010`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Lesson 3. Festivals and Ceremonies. Use the language in a new situation.
```

### L03-114 — آرتین — fa

- بخش: درس 3؛ جشن‌ها و مراسم و هدف یادگیری (`goals`)
- کادر: مسیر پیشنهادی همین درس
- فایل: `L03-114.weba`
- voice: `sage`
- slot: `data-audio-id="L03-114"`
- SHA256 متن UTF-8: `5575a2bcdf77fd8b667e181e9dc738f86d218a44c6699fe56a451cafaab254c4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پیش از شروعِ جشن‌ها و مراسم، سنجش ورودی را انجام بده. کمتر از شش پاسخ درست از هشت یعنی مرور پل پیش‌نیاز لازم است. سپس به ترتیبِ فهرست پیش برو؛ پس از هر الگو، پاسخ خودت را پیش از باز کردن راه‌حل بساز.
```

### L03-003 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-003.weba`
- voice: `sage`
- slot: `data-audio-id="L03-003"`
- SHA256 متن UTF-8: `5334e95aa35cc9dd16c45cd51a4e6a1a67447e61277014bfdc2d041a5d30a362`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از هفتم و هشتم، معرفی خانواده، روزها و فصل‌ها، واژه‌های خوراک و کارهای روزانه را لازم داری. از درس‌های یک و دو، فاعل و ضمیر و تفاوت وضعیت ثابت با کارِ در حال انجام را مرور می‌کنیم.
```

### L03-004 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-004.weba`
- voice: `sage`
- slot: `data-audio-id="L03-004"`
- SHA256 متن UTF-8: `7930ed0a266eb702f89e49a4a78ecc937328a576937ed5997b069c302ad98fa0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فاعل را پیش از انتخاب فعل پیدا کن: my mother یک نفر است؛ my parents دو نفرند. در زمان حال ساده، این تفاوت در شکل فعل اهمیت دارد.
```

### L03-005 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-005.weba`
- voice: `sage`
- slot: `data-audio-id="L03-005"`
- SHA256 متن UTF-8: `f5520738170b7c881fe5dbf3d5f7eb3e09290a7fbca53f61a1724df1e134c332`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My mother cooks. My parents cook.
```

### L03-006 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-006.weba`
- voice: `sage`
- slot: `data-audio-id="L03-006"`
- SHA256 متن UTF-8: `63b1b0fd10629d78f8ea312277fc28b298adf5657ef93cff3963d321d88c6244`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس قبل now نشانهٔ کارِ در حال انجام بود. اینجا usually و every year به عادت اشاره می‌کنند. برای یک رسم سالانه، لازم نیست به فعل ing بدهی.
```

### L03-007 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-007.weba`
- voice: `sage`
- slot: `data-audio-id="L03-007"`
- SHA256 متن UTF-8: `17d0f82815eaa3b8fcca37f39b131c533aac3170db4120775e4bab5aed4edc09`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We are visiting our aunt now. We visit our aunt every year.
```

### L03-008 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-008.weba`
- voice: `sage`
- slot: `data-audio-id="L03-008"`
- SHA256 متن UTF-8: `9446a58d725d3471bbb07c9378c8dcaaa7c6392cea248dcf281e119b12c3931e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
its یعنی مالِ آن؛ it’s شکل کوتاه it is است. آپاستروف فقط یک نشانهٔ ظاهری نیست؛ معنی جمله را عوض می‌کند.
```

### L03-009 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L03-009.weba`
- voice: `sage`
- slot: `data-audio-id="L03-009"`
- SHA256 متن UTF-8: `a811cd315eef9220476e67c73f35f50dfb7226947db6984f217485c6c1bf5280`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The cat drinks its milk. It’s hungry.
```

### L03-115 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L03-115.weba`
- voice: `sage`
- slot: `data-audio-id="L03-115"`
- SHA256 متن UTF-8: `2b0d83c57a6316a57abb3ce7d82641530eac660b9c8410bccca06f6452c6a7db`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
چهار فاعلِ I، my sister، my parents و the cat را به دو گروه مفرد سوم‌شخص و بقیه تقسیم کن. بعد فعل like را برای هرکدام انتخاب کن؛ فقط گروه نخست likes می‌گیرد.
```

### L03-116 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L03-116.weba`
- voice: `sage`
- slot: `data-audio-id="L03-116"`
- SHA256 متن UTF-8: `f5520738170b7c881fe5dbf3d5f7eb3e09290a7fbca53f61a1724df1e134c332`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My mother cooks. My parents cook.
```

### L03-010 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-010.weba`
- voice: `sage`
- slot: `data-audio-id="L03-010"`
- SHA256 متن UTF-8: `8253e53e92105876fa3203c6e2328595a363813e3b69aaccf6005cf57e8072b4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
make lunch / dinner. My father makes dinner.
```

### L03-011 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-011.weba`
- voice: `sage`
- slot: `data-audio-id="L03-011"`
- SHA256 متن UTF-8: `c62c59e2cde87c2a82fa445093b726c79470674259cc324c9e5ff6bc14d27cef`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
bake a cake. We bake a cake for the party.
```

### L03-012 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-012.weba`
- voice: `sage`
- slot: `data-audio-id="L03-012"`
- SHA256 متن UTF-8: `c8d52b0eb7436d2b521d05ae4553e0ee8c514915951a534fe70b95d52332915a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
set the table. I set the table before dinner.
```

### L03-013 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-013.weba`
- voice: `sage`
- slot: `data-audio-id="L03-013"`
- SHA256 متن UTF-8: `f680749032b2b2c9e5d4912d1e121d7c3cbf5f976772e589da3784c5d0ec2527`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
sing the national anthem. The students sing the national anthem.
```

### L03-014 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-014.weba`
- voice: `sage`
- slot: `data-audio-id="L03-014"`
- SHA256 متن UTF-8: `67b5ea6901ad544ffb482e33730ad2d1661d99298c9cb8756bc7f21ffcb10cca`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
hold a ceremony. They hold a ceremony at school.
```

### L03-015 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-015.weba`
- voice: `sage`
- slot: `data-audio-id="L03-015"`
- SHA256 متن UTF-8: `f67fbb87f8158a96e0b97da7b5b4aefa9fb3f9c00c2c148a7e7f55f00e0506b5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
watch fireworks. We watch fireworks from a safe place.
```

### L03-016 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-016.weba`
- voice: `sage`
- slot: `data-audio-id="L03-016"`
- SHA256 متن UTF-8: `cd2e63df033c97265611c7988761a0038617b329459651a3c46be65310a83b2e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
read poems of Hafez. My grandfather reads poems of Hafez.
```

### L03-017 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-017.weba`
- voice: `sage`
- slot: `data-audio-id="L03-017"`
- SHA256 متن UTF-8: `6b2a3e90c64d046ea662899f35f671b6fdff5b27a105228aaf27be664f839013`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
wear special clothes. They wear special clothes for the ceremony.
```

### L03-018 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-018.weba`
- voice: `sage`
- slot: `data-audio-id="L03-018"`
- SHA256 متن UTF-8: `e028432a51c971366307ee6198b7f3257914548069b9f2938f1511fc2255fd71`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
go out on Nature Day. Our family goes out on Nature Day.
```

### L03-019 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L03-019.weba`
- voice: `sage`
- slot: `data-audio-id="L03-019"`
- SHA256 متن UTF-8: `d0165866ba332974a5b4f2e03b580f5c0e9461cf34d320aba204ecef4f9f2b90`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
clear the table. We clear the table after lunch.
```

### L03-020 — Elham — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-020.weba`
- voice: `echo`
- slot: `data-audio-id="L03-020"`
- SHA256 متن UTF-8: `bfb1194b6e958715bfa54c4e4ba94592d616ab3f2763ea30204ca12afca4ae41`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I just love New Year holidays!
```

### L03-021 — Nasrin — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-021.weba`
- voice: `nova`
- slot: `data-audio-id="L03-021"`
- SHA256 متن UTF-8: `7a516154b2d9d789d9cd879db68093d68610557879693d1c7aa48c189f881805`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Oh, yes, me too. It’s really great.
```

### L03-022 — Elham — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-022.weba`
- voice: `echo`
- slot: `data-audio-id="L03-022"`
- SHA256 متن UTF-8: `dcd26f9471535152e43910590b8796b053923c521a18577971bc42fb22cc907a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We normally visit our relatives in Norooz. It’s fun!
```

### L03-023 — Nasrin — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-023.weba`
- voice: `nova`
- slot: `data-audio-id="L03-023"`
- SHA256 متن UTF-8: `da4a853e2885293d98da66b384fa10a624b72a1df016e9f13270e76340031928`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you get New Year gifts too?
```

### L03-024 — Elham — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-024.weba`
- voice: `echo`
- slot: `data-audio-id="L03-024"`
- SHA256 متن UTF-8: `b4549631737466e15a5f610dc3bf213e053a84184570b1108aad62ac9b52ec4f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Sure! We usually get money. I really like it.
```

### L03-025 — Nasrin — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-025.weba`
- voice: `nova`
- slot: `data-audio-id="L03-025"`
- SHA256 متن UTF-8: `fc2fe700a7556b970bd8a6152a994cf686ac16179c39f256aba1b553bc7aff9a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Well…, We always go to my grandparents’ houses.
```

### L03-026 — Elham — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-026.weba`
- voice: `echo`
- slot: `data-audio-id="L03-026"`
- SHA256 متن UTF-8: `53cebd63fff4fe34a348a13993049130d5adf0e0d94478637dd1b388bf84468e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
That’s nice! Does your grandmother cook the New Year meal?
```

### L03-027 — Nasrin — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L03-027.weba`
- voice: `nova`
- slot: `data-audio-id="L03-027"`
- SHA256 متن UTF-8: `400233a7785117ecc9f3f3116bd4d17ad8d24260e2e2105107c0c30a30279954`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Actually, she doesn’t. My mother makes it.
```

### L03-117 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: اجرای گفت‌وگو بدون وابستگی به متن
- فایل: `L03-117.weba`
- voice: `sage`
- slot: `data-audio-id="L03-117"`
- SHA256 متن UTF-8: `aec4e86466ad78a9afdc3975d371aff1dcbd274f5f69a5ed8e420f0d046b37f1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در اجرای نوروز، ابتدا نقش الهام را بخوان و پاسخ نسرین را از حافظه بگو. در دور بعد، دو رسم را تغییر بده تا گفت‌وگو دربارهٔ خانواده‌ای تازه باشد. یک پاسخ منفی هم دربارهٔ کسی بده که آن کار را انجام نمی‌دهد.
```

### L03-028 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-028.weba`
- voice: `sage`
- slot: `data-audio-id="L03-028"`
- SHA256 متن UTF-8: `fc3cf14b182d1cb55715a87e237f15a74cdaee6688112eeda84e6b42996f5cba`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you buy new clothes for the New Year?
```

### L03-029 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-029.weba`
- voice: `coral`
- slot: `data-audio-id="L03-029"`
- SHA256 متن UTF-8: `27282b999a04ddc63b41567e687d9b5109651c26ba0caf653ded126f30648d61`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I do.
```

### L03-030 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-030.weba`
- voice: `sage`
- slot: `data-audio-id="L03-030"`
- SHA256 متن UTF-8: `de2fc44a23dfd2e219600bf09caeca391ac468e6c43efe4811c41715db841c7f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you and your cousins set the Haft Seen table?
```

### L03-031 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-031.weba`
- voice: `coral`
- slot: `data-audio-id="L03-031"`
- SHA256 متن UTF-8: `e573dfdd095992e75d7ee1a68ef9b91f30464f2c41775c291783733311b944c5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, we don’t.
```

### L03-032 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-032.weba`
- voice: `sage`
- slot: `data-audio-id="L03-032"`
- SHA256 متن UTF-8: `ced49e28f1a086126ebe0af944b120e432f317db1144dc943561a5d3aef33ebb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do young children color the eggs?
```

### L03-033 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-033.weba`
- voice: `coral`
- slot: `data-audio-id="L03-033"`
- SHA256 متن UTF-8: `f7836d1aaac91fb41329e6d01df8ee5b9fdc82edd6a6c0bc3687b938235b536b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, they usually color them.
```

### L03-034 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-034.weba`
- voice: `sage`
- slot: `data-audio-id="L03-034"`
- SHA256 متن UTF-8: `fb7242f844567618c1a5fd24aa3a4139b66d36d4f5a759909af431e720a69438`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do Chinese people buy goldfish for the New Year?
```

### L03-035 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-035.weba`
- voice: `coral`
- slot: `data-audio-id="L03-035"`
- SHA256 متن UTF-8: `acff7ba29e940a711d73f9a7d0867a4439495f7df3637a43d404b7c157520f02`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, they don’t buy goldfish.
```

### L03-036 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-036.weba`
- voice: `sage`
- slot: `data-audio-id="L03-036"`
- SHA256 متن UTF-8: `86a1493b657ff52e3d6c01567fa507e9e18c7575bde2557d02fac6cd4fdbe880`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does he recite the Holy Quran at the turn of the year?
```

### L03-037 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-037.weba`
- voice: `coral`
- slot: `data-audio-id="L03-037"`
- SHA256 متن UTF-8: `927ac2492c745415d234bc4059cb1e0c420c0634180b8d98622825801a216cd1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, he does.
```

### L03-038 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-038.weba`
- voice: `sage`
- slot: `data-audio-id="L03-038"`
- SHA256 متن UTF-8: `4a0f3b2faec9f75a74e03e8cfdbc046c8df9becafd56962cf30ae91ef9fd04b9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does your father give you New Year gifts?
```

### L03-039 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-039.weba`
- voice: `coral`
- slot: `data-audio-id="L03-039"`
- SHA256 متن UTF-8: `ed87250a4cbbe59dc6adc72ae1f363a9c3da11769a2ded9ee19954f69586d5bf`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, he doesn’t.
```

### L03-040 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-040.weba`
- voice: `sage`
- slot: `data-audio-id="L03-040"`
- SHA256 متن UTF-8: `a089affcdfa7625517d8fb966346c6ab3b27c8c5af564d2088e6009614c7e443`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does she have many friends?
```

### L03-041 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-041.weba`
- voice: `coral`
- slot: `data-audio-id="L03-041"`
- SHA256 متن UTF-8: `880bf8de4cfbeba70b5ca3b01705ae5981c82d2b92395162fe5bf36ae58b4b4d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, she has many friends.
```

### L03-042 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-042.weba`
- voice: `sage`
- slot: `data-audio-id="L03-042"`
- SHA256 متن UTF-8: `78d21d8f98737e80e5205c3e6116c871964c33062bd0ca24750be808a738d9de`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does your mom make a special food for Norooz?
```

### L03-043 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-043.weba`
- voice: `coral`
- slot: `data-audio-id="L03-043"`
- SHA256 متن UTF-8: `9e743849c9482fad76a723437f1792a77dea242d294c63d6b91926e62c222d95`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, she doesn’t make a special food.
```

### L03-044 — آرتین — fa

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L03-044.weba`
- voice: `sage`
- slot: `data-audio-id="L03-044"`
- SHA256 متن UTF-8: `8b6843c91c10d11c37ae7f06788ebd1a28bd10415074ede385a45e97cee9c222`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پاسخ‌های مربوط به رسم‌ها، نمونه‌های تمرین کتاب‌اند؛ یک پاسخ را به همهٔ خانواده‌های یک کشور تعمیم نده. برای پاسخ شخصی، رسم خانوادهٔ خود یا یک خانوادهٔ فرضی را توضیح بده.
```

### L03-045 — آرتین — fa

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-045.weba`
- voice: `sage`
- slot: `data-audio-id="L03-045"`
- SHA256 متن UTF-8: `0a5288636b426df26a4f5d5290827300c7be1dd2f909f9afa19ac4bca9dd2d06`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای عادت، برنامهٔ تکراری یا یک واقعیت، از حال ساده استفاده می‌کنیم. I و you و we و they با شکل پایهٔ فعل می‌آیند. he و she و it در جملهٔ مثبت معمولاً s می‌خواهند.
```

### L03-046 — آرتین — en

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-046.weba`
- voice: `sage`
- slot: `data-audio-id="L03-046"`
- SHA256 متن UTF-8: `1e92e43de7c56113f0c649f382c0d1769da2b9d92087ae7dd5a73c4212183273`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We visit our relatives. She visits her relatives.
```

### L03-047 — آرتین — fa

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-047.weba`
- voice: `sage`
- slot: `data-audio-id="L03-047"`
- SHA256 متن UTF-8: `47bf3cfa1a99e766f144bbd134edb453eed91784ecfbe357429a28160eb7dd90`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای فعل‌های پایان‌یافته به ch و sh و s و x و گاهی o، معمولاً es می‌آید. در study، پیش از y همخوان داریم؛ y به ies تبدیل می‌شود. در play، پیش از y واکه است و فقط s اضافه می‌شود.
```

### L03-048 — آرتین — en

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-048.weba`
- voice: `sage`
- slot: `data-audio-id="L03-048"`
- SHA256 متن UTF-8: `7f07490e15308f140b165af525b2df35636dd8411a5bc63c89898aebccdfced2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Watch, watches. Wash, washes. Go, goes. Study, studies. Play, plays.
```

### L03-049 — آرتین — fa

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-049.weba`
- voice: `sage`
- slot: `data-audio-id="L03-049"`
- SHA256 متن UTF-8: `bc7dbeb410a5ccd1cbfb12b2d7496c65adb2b6fbcf4ec30d42e236f67aaafa34`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
have برای سوم‌شخص مفرد به has تبدیل می‌شود. شکل مثبت He has را یاد بگیر، ولی در کنار does دوباره have می‌آید؛ مسئول نشانهٔ سوم‌شخص در سؤال، خودِ does است.
```

### L03-050 — آرتین — en

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: متن اصلی
- فایل: `L03-050.weba`
- voice: `sage`
- slot: `data-audio-id="L03-050"`
- SHA256 متن UTF-8: `4b6c2c081f7a708391cd2b512d1ace81f87834375d73f17a2c7eb625d344c117`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He has many friends. Does he have many friends?
```

### L03-118 — آرتین — fa

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-118.weba`
- voice: `sage`
- slot: `data-audio-id="L03-118"`
- SHA256 متن UTF-8: `0808581464eebe1421e3c626c8face16eade44916d98343223cb4407a522981f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای my brother جمله‌ای با study و برای my friends جمله‌ای با play بساز. تغییر فاعل را به شکل فعل منتقل کن و توضیح بده چرا study به studies ولی play به plays تبدیل می‌شود.
```

### L03-119 — آرتین — en

- بخش: حال ساده؛ کار تکراری و رسم (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-119.weba`
- voice: `sage`
- slot: `data-audio-id="L03-119"`
- SHA256 متن UTF-8: `1e92e43de7c56113f0c649f382c0d1769da2b9d92087ae7dd5a73c4212183273`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We visit our relatives. She visits her relatives.
```

### L03-051 — آرتین — fa

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-051.weba`
- voice: `sage`
- slot: `data-audio-id="L03-051"`
- SHA256 متن UTF-8: `9be973fe0b9117839057223e6bbeff255cfff62cb5ae046aa432a073ec0f83f7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای منفیِ فعل اصلی، don’t یا doesn’t را قبل از شکل پایهٔ فعل بگذار. اگر فاعل he یا she باشد، s در doesn’t بیان شده و روی فعل اصلی تکرار نمی‌شود.
```

### L03-052 — آرتین — en

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-052.weba`
- voice: `sage`
- slot: `data-audio-id="L03-052"`
- SHA256 متن UTF-8: `aaafb931e898a8cb0f9ca2084c7f891d0ec03f084ce1717b21e53cb9c633e78a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I don’t buy goldfish. She doesn’t buy goldfish.
```

### L03-053 — آرتین — fa

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-053.weba`
- voice: `sage`
- slot: `data-audio-id="L03-053"`
- SHA256 متن UTF-8: `78cb4e86918c4877e73e0afd2f26346e560a57e070bbcfbc5bc0c3f49a3eae01`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در سؤال، do یا does در ابتدای جمله می‌آید؛ پس از آن فاعل و شکل پایهٔ فعل قرار می‌گیرد. جواب کوتاه نیز همان فعل کمکی را نگه می‌دارد.
```

### L03-054 — آرتین — en

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-054.weba`
- voice: `sage`
- slot: `data-audio-id="L03-054"`
- SHA256 متن UTF-8: `e1fd945dd3065b7baa9699347f453a133703d80016a5a6072a458f8b1b23c857`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do they visit you? Yes, they do. Does he cook? No, he doesn’t.
```

### L03-055 — آرتین — fa

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-055.weba`
- voice: `sage`
- slot: `data-audio-id="L03-055"`
- SHA256 متن UTF-8: `16363e22ed74d5d90a1541d1192a94c1ab78ce4730a50735e9c921e129397cba`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
be را با این الگو مخلوط نکن. برای She is happy می‌گویی Is she happy?؛ برای She likes holidays می‌گویی Does she like holidays? انتخاب از روی فعل جمله است، نه از روی اسمِ فاعل.
```

### L03-056 — آرتین — en

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: متن اصلی
- فایل: `L03-056.weba`
- voice: `sage`
- slot: `data-audio-id="L03-056"`
- SHA256 متن UTF-8: `c09959067a8c260f02f06a49f31ebf2deb96c188ddf3b3cf0b2e76ba150b076a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Is she happy? Does she like holidays?
```

### L03-120 — آرتین — fa

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-120.weba`
- voice: `sage`
- slot: `data-audio-id="L03-120"`
- SHA256 متن UTF-8: `730eec8fc191c3538ccf5227e0d5c58c196096ffef9533fdff44e6beb0d08c03`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
جملهٔ She has a gift را منفی و پرسشی کن. در هر دو، has باید به have برگردد؛ اگر همان has باقی ماند، نقش does را دوباره بررسی کن.
```

### L03-121 — آرتین — en

- بخش: منفی و سؤال با do و does (`negative`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-121.weba`
- voice: `sage`
- slot: `data-audio-id="L03-121"`
- SHA256 متن UTF-8: `aaafb931e898a8cb0f9ca2084c7f891d0ec03f084ce1717b21e53cb9c633e78a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I don’t buy goldfish. She doesn’t buy goldfish.
```

### L03-057 — آرتین — fa

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-057.weba`
- voice: `sage`
- slot: `data-audio-id="L03-057"`
- SHA256 متن UTF-8: `9a12b8ca126d301de6dc7de9d0589d0c553f9d6c7ac93902c58ff2d660e5054b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
صفت ملکی پیش از اسم می‌آید؛ به‌تنهایی جانشین اسم نمی‌شود. his برای صاحب مذکر و her برای صاحب مؤنث است. شکل صفت ملکی با جمع شدنِ چیزی که متعلق به فرد است تغییر نمی‌کند.
```

### L03-058 — آرتین — en

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-058.weba`
- voice: `sage`
- slot: `data-audio-id="L03-058"`
- SHA256 متن UTF-8: `f29f30270b5d1a11128806583254dd2ee38a052983259e6823a1309d529a5dfe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
His book. His books. Her car. Her cars.
```

### L03-059 — آرتین — fa

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-059.weba`
- voice: `sage`
- slot: `data-audio-id="L03-059"`
- SHA256 متن UTF-8: `8f6c8959c0256413d1ab50a07d86341ebc6490fc51505ad1d19e1d2f1d0ed77a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
our شامل گوینده و دست‌کم یک نفر دیگر است. their برای صاحبان جمع به کار می‌رود. عبارت my brother and I را ابتدا به we تبدیل کن تا our را درست انتخاب کنی.
```

### L03-060 — آرتین — en

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-060.weba`
- voice: `sage`
- slot: `data-audio-id="L03-060"`
- SHA256 متن UTF-8: `898f3bb3eaa89ec412ed75a54afc7f7d168afa44b819c5c8bdf930987ded3bdf`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My brother and I clean our room. The students read their books.
```

### L03-061 — آرتین — fa

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-061.weba`
- voice: `sage`
- slot: `data-audio-id="L03-061"`
- SHA256 متن UTF-8: `8b28a2852775bc0f47cca3d472430f6b0db773dba26be27a829e33ea73e57a34`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
its مالکیت را می‌رساند و آپاستروف ندارد. it’s یعنی it is؛ با بازکردن شکل کوتاه می‌توانی انتخابت را آزمایش کنی.
```

### L03-062 — آرتین — en

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: متن اصلی
- فایل: `L03-062.weba`
- voice: `sage`
- slot: `data-audio-id="L03-062"`
- SHA256 متن UTF-8: `13ef5e09aed4b7c0139f237b6552f72e91d6ac6df0f8be61e57b90dfb5da310e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The cat drinks its milk. It’s a white cat.
```

### L03-122 — آرتین — fa

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-122.weba`
- voice: `sage`
- slot: `data-audio-id="L03-122"`
- SHA256 متن UTF-8: `a916efade6bc00f62a7db57f44582232082341e4b5a044d382ede1a857e7b4d1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای یک دختر، یک پسر و یک گروه دوستی سه مالک انتخاب کن. her، his و their را پیش از book بگذار؛ بعد book را جمع کن و ببین صفت ملکی تغییر نمی‌کند.
```

### L03-123 — آرتین — en

- بخش: صفت ملکی؛ صاحب اسم چه کسی است؟ (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-123.weba`
- voice: `sage`
- slot: `data-audio-id="L03-123"`
- SHA256 متن UTF-8: `f29f30270b5d1a11128806583254dd2ee38a052983259e6823a1309d529a5dfe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
His book. His books. Her car. Her cars.
```

### L03-063 — آرتین — fa

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: متن اصلی
- فایل: `L03-063.weba`
- voice: `sage`
- slot: `data-audio-id="L03-063"`
- SHA256 متن UTF-8: `cc0b4d3944d4a5395ba847ff5357b3b8f7c315f148e0b4d4aac622dcc76b91f2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
usually و normally به عادت اشاره می‌کنند. always در توصیف رسم‌ها یعنی همیشه در محدودهٔ مورد بحث، نه ادعایی دربارهٔ همهٔ انسان‌ها. دربارهٔ خانوادهٔ خود یا یک شخصیت فرضی حرف بزن.
```

### L03-064 — آرتین — en

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: متن اصلی
- فایل: `L03-064.weba`
- voice: `sage`
- slot: `data-audio-id="L03-064"`
- SHA256 متن UTF-8: `f1df4a145831707c60c99f48730a0196520b22f4c881e3ae4a002b32f68b3bc7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We usually visit our grandparents in Norooz.
```

### L03-065 — آرتین — fa

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: متن اصلی
- فایل: `L03-065.weba`
- voice: `sage`
- slot: `data-audio-id="L03-065"`
- SHA256 متن UTF-8: `695ee668d9f9fb12fb431f7f4d57e8af570cedd4df193942e2005fd398e9bd84`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
now را کنار حال استمراری و every year را کنار حال ساده مقایسه کن. در حالت اول رخدادِ جاری و در حالت دوم رسمِ تکراری هدف است.
```

### L03-066 — آرتین — en

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: متن اصلی
- فایل: `L03-066.weba`
- voice: `sage`
- slot: `data-audio-id="L03-066"`
- SHA256 متن UTF-8: `8b02406043573f71531c7311ccf211bc88b4ed316f96bf02e282b16c166d8be3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She is setting the table now. She sets the table every evening.
```

### L03-124 — آرتین — fa

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-124.weba`
- voice: `sage`
- slot: `data-audio-id="L03-124"`
- SHA256 متن UTF-8: `391c7baae7b6a2f09f42cd57730f3f1dd0fea65ebf1e505400109a6a14d0a13c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
دو جمله دربارهٔ چیدن میز بنویس: یکی برای همین لحظه و یکی برای هر جمعه. now و every Friday را جابه‌جا نکن؛ معنی زمان باید با شکل فعل هماهنگ باشد.
```

### L03-125 — آرتین — en

- بخش: حال ساده در برابر اکنون؛ قیدها و پیوند معنی (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L03-125.weba`
- voice: `sage`
- slot: `data-audio-id="L03-125"`
- SHA256 متن UTF-8: `f1df4a145831707c60c99f48730a0196520b22f4c881e3ae4a002b32f68b3bc7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We usually visit our grandparents in Norooz.
```

### L03-067 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-067.weba`
- voice: `sage`
- slot: `data-audio-id="L03-067"`
- SHA256 متن UTF-8: `080e08d6eff47c32dff365b2131e029ec4904ec46679594d6944d0a3835a830d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پایان فعل سوم‌شخص همیشه شبیه س فارسی نیست. در likes پس از صدای بی‌واک، پایانِ سِ بی‌واک شنیده می‌شود؛ در reads پس از صدای واک‌دار، پایانِ ز داریم؛ watches یک هجای اضافی دارد.
```

### L03-068 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-068.weba`
- voice: `sage`
- slot: `data-audio-id="L03-068"`
- SHA256 متن UTF-8: `8a6b81eaa10b79d67642f1e9d2b908839c86b6e186817a90346566b32ed39de0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Likes. Reads. Watches. He likes spring. She watches TV.
```

### L03-069 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-069.weba`
- voice: `sage`
- slot: `data-audio-id="L03-069"`
- SHA256 متن UTF-8: `fb0a6726906aee011fdf34f443366909e3dff9e9d99e5d1e9647210d0c16a701`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در does، واکه مانند do نیست؛ شکل does را به‌صورت یک واژهٔ کامل یاد بگیر. در doesn’t، صدای t پایانی را بدون اضافه کردن واکهٔ تازه ادا کن.
```

### L03-070 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-070.weba`
- voice: `sage`
- slot: `data-audio-id="L03-070"`
- SHA256 متن UTF-8: `a4b6f97b26cad75f20068106edbf137294b759abf64a9990b595dd37a7188118`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do. Does. Doesn’t. Does she cook? No, she doesn’t.
```

### L03-071 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-071.weba`
- voice: `sage`
- slot: `data-audio-id="L03-071"`
- SHA256 متن UTF-8: `e2f7ae1f6d83f93ff92c8d39b55fb709d05ba94c4a17f130f60ad1d0f2faf272`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در سؤال‌های do و does، آهنگ معمولِ الگوی کتاب خیزان است. سؤال را به یک رشتهٔ واژهٔ جدا تبدیل نکن؛ فعل کمکی و فاعل را پیوسته بخوان.
```

### L03-072 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 3 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L03-072.weba`
- voice: `sage`
- slot: `data-audio-id="L03-072"`
- SHA256 متن UTF-8: `ae9577a49169d714f22c3b43f7a4049bb9d4a071bec3cfa8bcb07fcf97e7e640`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you like rainy weather? Does he like spring?
```

### L03-073 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-073.weba`
- voice: `echo`
- slot: `data-audio-id="L03-073"`
- SHA256 متن UTF-8: `70c3763f80f9e6de1c1078a9b41c598dd608e67f5ab1dee6575edb8904dbb93f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Shayan, do you like spring?
```

### L03-074 — Shayan — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-074.weba`
- voice: `nova`
- slot: `data-audio-id="L03-074"`
- SHA256 متن UTF-8: `4bb180201ac2932906357c5249ab335a9e00a9e7c77e1e24acb3c5ffb2f75380`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I like spring a lot.
```

### L03-075 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-075.weba`
- voice: `echo`
- slot: `data-audio-id="L03-075"`
- SHA256 متن UTF-8: `9f409d7b277e2c5bb4265ce83e8002d3c673477d5313ee21b8b19dae717a4e63`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you like rainy weather?
```

### L03-076 — Shayan — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-076.weba`
- voice: `nova`
- slot: `data-audio-id="L03-076"`
- SHA256 متن UTF-8: `17bf5a922126f3720e464698a32c3d44853c8a8d0281af3218f5c940f5d52238`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Oh yes! But not on Nature Day.
```

### L03-077 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-077.weba`
- voice: `echo`
- slot: `data-audio-id="L03-077"`
- SHA256 متن UTF-8: `fae1cd1b4494d53a73eb68ecbd81562ca5bbd1f77c3652bb3e1ae1a037cc86e3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why not?
```

### L03-078 — Shayan — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-078.weba`
- voice: `nova`
- slot: `data-audio-id="L03-078"`
- SHA256 متن UTF-8: `d8c73a26292d9aafce42625ede0cd9d9b3af33e4dfe532c4a993e4b8d98e85ef`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Because we always go out on 13th of Farvardin.
```

### L03-079 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-079.weba`
- voice: `sage`
- slot: `data-audio-id="L03-079"`
- SHA256 متن UTF-8: `9f409d7b277e2c5bb4265ce83e8002d3c673477d5313ee21b8b19dae717a4e63`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you like rainy weather?
```

### L03-080 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-080.weba`
- voice: `sage`
- slot: `data-audio-id="L03-080"`
- SHA256 متن UTF-8: `9ca96f5512510c34c78eb376a2f99793aa0c4e095d01284272e2950d59fe687f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does it rain a lot in Tehran?
```

### L03-081 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-081.weba`
- voice: `sage`
- slot: `data-audio-id="L03-081"`
- SHA256 متن UTF-8: `32eb40fc54d3ad684da835dd358a8fb70384de34634a6e560cca1d8dd82845c2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does she cook lunch?
```

### L03-082 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-082.weba`
- voice: `sage`
- slot: `data-audio-id="L03-082"`
- SHA256 متن UTF-8: `c530af49e276a60fbfc22746cb99d2e26318ab76e9c0ffd1b8e241f1d023f3a3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you tell stories?
```

### L03-083 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-083.weba`
- voice: `sage`
- slot: `data-audio-id="L03-083"`
- SHA256 متن UTF-8: `e5a9088bb1ae56b99f086a524e37e1a1a0085cf304fdd5b526b7ba5431e9ef7c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does he like spring?
```

### L03-084 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-084.weba`
- voice: `sage`
- slot: `data-audio-id="L03-084"`
- SHA256 متن UTF-8: `792d4e79086830190ed7b518c8818a4a5db3d7df0f7d8406d2f549ffdf09fc1c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does she eat nuts?
```

### L03-085 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L03-085.weba`
- voice: `sage`
- slot: `data-audio-id="L03-085"`
- SHA256 متن UTF-8: `b1e02e1eb3e394c899ac4dd6e790a2fa52e718f4cf4a7eeb2202c390236786e3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Wish you a great holiday! Happy New Year!
```

### L03-126 — آرتین — fa

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: تمرین تکمیلی تلفظِ جشن‌ها و مراسم
- فایل: `L03-126.weba`
- voice: `sage`
- slot: `data-audio-id="L03-126"`
- SHA256 متن UTF-8: `c2194f406617baef18a6ebc0817c531d6abaf38457f1b3a0ff7a270d9824f69d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
سه فعل likes، reads و watches را ضبط کن. بررسی کن فقط watches به خاطر پایان آوایی‌اش یک هجای اضافی دارد؛ سپس آن‌ها را در سه جملهٔ حال ساده بگو.
```

### L03-086 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L03-086.weba`
- voice: `sage`
- slot: `data-audio-id="L03-086"`
- SHA256 متن UTF-8: `0de7a81d6a4d395edaf728e7060ae209761782c037da2ac3613e62159836b13c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Ahmed is from Turkey and he lives in Istanbul. Fitr Eid is an important religious holiday in his country. He likes this day a lot. It’s on the first day of Shawwal. On Fitr Eid, Muslims don’t fast. They say their Eid prayers before noon. In all Muslim countries people hold the same ceremony.
```

### L03-127 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: ترجمهٔ خواندنی
- فایل: `L03-127.weba`
- voice: `sage`
- slot: `data-audio-id="L03-127"`
- SHA256 متن UTF-8: `41bfec206e5dc2678117d5eeaf21e7d0fa35b10970e65e708f4c9127ed6db02f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
احمد اهل ترکیه است و در استانبول زندگی می‌کند. عید فطر در کشور او مناسبت دینی مهمی است. او این روز را خیلی دوست دارد. این روز، نخستین روز شوال است. در عید فطر مسلمانان روزه نمی‌گیرند و پیش از ظهر نماز عید را می‌خوانند. متن کتاب می‌گوید در کشورهای مسلمان همین مراسم برگزار می‌شود؛ جزئیات رسم‌ها می‌تواند متفاوت باشد.
```

### L03-087 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L03-087.weba`
- voice: `sage`
- slot: `data-audio-id="L03-087"`
- SHA256 متن UTF-8: `35f269bf1ec17b621d1dfcc8e8a1742979938fbf999f0b584beb41093ee15ec4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فعل‌ها یا گروه‌های فعلیِ حال ساده را انتخاب کن؛ شکل‌های be هم حال ساده دارند.
```

### L03-128 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L03-128.weba`
- voice: `sage`
- slot: `data-audio-id="L03-128"`
- SHA256 متن UTF-8: `bb58757209e869981a32bee8993af54d3c243a29195215c79dcbca221644721a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
is / lives / likes / It’s / don’t fast / say / hold
```

### L03-129 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L03-129.weba`
- voice: `sage`
- slot: `data-audio-id="L03-129"`
- SHA256 متن UTF-8: `119c95d96e704bdefd7350c086ec39fde323e516aaaf23b3e458acd41e7d28a8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در متن عید فطر، فعل‌های be و فعل‌های اصلیِ عادت هر دو حال ساده‌اند. his و their را برای هدف دوم جدا علامت بزن؛ آن‌ها فعل نیستند.
```

### L03-130 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: هدف دوم Find it؛ صفت‌های ملکی
- فایل: `L03-130.weba`
- voice: `sage`
- slot: `data-audio-id="L03-130"`
- SHA256 متن UTF-8: `8564829206322e4e06720a4dbee8b624a7a12410709f3933326e515e980c8718`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
his در his country و their در their Eid prayers صفت ملکی‌اند. he و they ضمیر فاعلی هستند و باید از آن‌ها جدا شوند.
```

### L03-088 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن اصلی
- فایل: `L03-088.weba`
- voice: `sage`
- slot: `data-audio-id="L03-088"`
- SHA256 متن UTF-8: `362c04130ad8c7e0f112f4b6d36ead1c54143692457f859d00cb75fd43d331ac`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فایل رسمی شنیداری در PDF موجود نیست. دو متن این بخش برای تمرینِ جشن‌ها و مراسم تألیف شده‌اند و کلید آن‌ها فقط مربوط به همین متن‌هاست. بار اول اطلاعات اصلی و بار دوم جزئیات پرسش‌ها را یادداشت کن.
```

### L03-089 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی A؛ پس از گوش دادن باز کن
- فایل: `L03-089.weba`
- voice: `sage`
- slot: `data-audio-id="L03-089"`
- SHA256 متن UTF-8: `f6b0c485a6b03b7916387f2ad752600b1d8bcba30d7160f63f28a62ebebd8e12`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
On Yalda Night, we visit our grandparents. We eat nuts and watermelon. We listen to poems. We do not stay at our own home that evening.
```

### L03-131 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی A
- فایل: `L03-131.weba`
- voice: `sage`
- slot: `data-audio-id="L03-131"`
- SHA256 متن UTF-8: `614162e990e9cf2e77902fdc27990bb177b320fafb2b7781399480311071f763`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
nuts و watermelon؛ poems؛ در این متن در خانهٔ خود نمی‌مانند، به دیدن پدربزرگ و مادربزرگ می‌روند.
```

### L03-090 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی B؛ پس از گوش دادن باز کن
- فایل: `L03-090.weba`
- voice: `sage`
- slot: `data-audio-id="L03-090"`
- SHA256 متن UTF-8: `16573a4dffaa32c9b1047123551de51dc07cdf8da20153f41e36ee90c4e3fcbe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
In this description of the Chinese New Year, the date falls in January or February. It changes every year. Everyone in this family wears new clothes. Older people give children money in red envelopes.
```

### L03-132 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی B
- فایل: `L03-132.weba`
- voice: `sage`
- slot: `data-audio-id="L03-132"`
- SHA256 متن UTF-8: `0c1459db6ea4652533e30825fdd9cfc8bf141ddc3129a30e0819c191f56f16ef`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
January یا February؛ تاریخ تغییر می‌کند؛ لباس نو؛ پول در پاکت قرمز. این توصیف یک خانواده است، نه حکم دربارهٔ همه.
```

### L03-091 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-091.weba`
- voice: `sage`
- slot: `data-audio-id="L03-091"`
- SHA256 متن UTF-8: `2e32b3561d15ca38dd8de0b25d039f48830c414d010614b98de09423768b1248`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does your grandparent tell you stories?
```

### L03-092 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-092.weba`
- voice: `sage`
- slot: `data-audio-id="L03-092"`
- SHA256 متن UTF-8: `7b00bc58d47d078a230e864919a1d4dd5a45f76c844f19c541ea78dc92846c0e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you wear special clothes on New Year holidays?
```

### L03-093 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-093.weba`
- voice: `sage`
- slot: `data-audio-id="L03-093"`
- SHA256 متن UTF-8: `7a9d9baf7ac4e8d2115dcc2bc796004c22728b0dc28f6fc1bf745aaba3eadb57`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you visit your relatives?
```

### L03-094 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-094.weba`
- voice: `sage`
- slot: `data-audio-id="L03-094"`
- SHA256 متن UTF-8: `86243afe4699935eeb81cd993476cf03a7f2673ee5638a721a8df94e9a112189`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you get gifts?
```

### L03-095 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-095.weba`
- voice: `sage`
- slot: `data-audio-id="L03-095"`
- SHA256 متن UTF-8: `4fd66532873d7f42c505dee2309cdd08753308cb696f3aa79f783c24437bec39`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does your father work on holidays?
```

### L03-096 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-096.weba`
- voice: `echo`
- slot: `data-audio-id="L03-096"`
- SHA256 متن UTF-8: `a56a529b6a235d6eb88e9cc1e6fe24fa08b94fddc115fb6ae436321b6c330493`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Do you visit your cousins on holidays?
```

### L03-097 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-097.weba`
- voice: `coral`
- slot: `data-audio-id="L03-097"`
- SHA256 متن UTF-8: `a045d86b7a6d211c16b41842654471cc2472dd4b12f1b2e3ba01d31cb23078ee`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I do. We usually play together.
```

### L03-098 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-098.weba`
- voice: `echo`
- slot: `data-audio-id="L03-098"`
- SHA256 متن UTF-8: `0498d5b49c2f3ee927441be8762564d2aab40dffcc5777916b5f17e9a5c88878`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does your brother bake a cake?
```

### L03-099 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-099.weba`
- voice: `coral`
- slot: `data-audio-id="L03-099"`
- SHA256 متن UTF-8: `303f4a8fb854f57e48833dedcf562236027525ba29ef313f3dab109cbb08f263`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, he doesn’t. He sets the table.
```

### L03-100 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-100.weba`
- voice: `echo`
- slot: `data-audio-id="L03-100"`
- SHA256 متن UTF-8: `d37159b5994fd1fb3a15582eae76ac93ece65e00955f62c1ce46d1ba0b7ee299`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What do you do after lunch?
```

### L03-101 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L03-101.weba`
- voice: `coral`
- slot: `data-audio-id="L03-101"`
- SHA256 متن UTF-8: `91e31f97e2636dbf7ea3dc44d10f486b01391278ccd20acecd6b1541251a790e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We read poems and talk.
```

### L03-133 — آرتین — fa

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: معیار اجرای مستقل در جشن‌ها و مراسم
- فایل: `L03-133.weba`
- voice: `sage`
- slot: `data-audio-id="L03-133"`
- SHA256 متن UTF-8: `d6ee6d4d255b0ff06f32e2942398dd1ceba7061bb223de4f4f625a29a72f15a2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جشن فرضی، از یک نفر دربارهٔ عادت خودش و عادت یکی از اعضای خانواده‌اش بپرس؛ این تغییر فاعل باید انتخاب do و does را هم تغییر بدهد.
```

### L03-102 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-102.weba`
- voice: `sage`
- slot: `data-audio-id="L03-102"`
- SHA256 متن UTF-8: `f38b2ed16f988644930b62088a1b31cf19ec375e909a2c6c14a9168456bf80b6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای سوم‌شخص مفرد، doesn’t لازم است.
```

### L03-103 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-103.weba`
- voice: `sage`
- slot: `data-audio-id="L03-103"`
- SHA256 متن UTF-8: `2dbcf63128329d8a855704902f2c1201699182b9d55dcc0918775f459abf9592`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She doesn’t visit us.
```

### L03-104 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-104.weba`
- voice: `sage`
- slot: `data-audio-id="L03-104"`
- SHA256 متن UTF-8: `2a2b7136c8f281ef2a2e8c9634588f94b9f151fc3fef9562a6e497cf0efe593e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
بعد از does، s روی فعل اصلی نمی‌ماند.
```

### L03-105 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-105.weba`
- voice: `sage`
- slot: `data-audio-id="L03-105"`
- SHA256 متن UTF-8: `3580f33e1dea3be22560e1fcde23616a887f1d0d6c1819a7b008bab6965f499a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Does he cook?
```

### L03-106 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-106.weba`
- voice: `sage`
- slot: `data-audio-id="L03-106"`
- SHA256 متن UTF-8: `613a68fbd245497561dca8b7fdc45475f4eddf65e6016ab8b3fb967bc449b99f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
مالکیتِ its آپاستروف ندارد.
```

### L03-107 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L03-107.weba`
- voice: `sage`
- slot: `data-audio-id="L03-107"`
- SHA256 متن UTF-8: `ac47b5a2db15ce165f095c56917f8cd90468758a2b7779dff9d72ac8119d2f1d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
The cat drinks its milk.
```

### L03-108 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L03-108.weba`
- voice: `sage`
- slot: `data-audio-id="L03-108"`
- SHA256 متن UTF-8: `4d5779c36b3667d8dae294625f5eeffa742f8d3e59d9e2c616473cc50415b810`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
celebrate a religious holiday
```

### L03-109 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L03-109.weba`
- voice: `sage`
- slot: `data-audio-id="L03-109"`
- SHA256 متن UTF-8: `67cfef8434838be440c5e9729b925f1af9b7c6a99297c7a005d95b804aad0da2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
watch a military parade
```

### L03-110 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L03-110.weba`
- voice: `sage`
- slot: `data-audio-id="L03-110"`
- SHA256 متن UTF-8: `48feb17abe89ae36325144ea72460a6afa1f4454d90a74f38b4d90d6161de243`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
commemorate nuclear energy martyrs
```

### L03-111 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L03-111.weba`
- voice: `sage`
- slot: `data-audio-id="L03-111"`
- SHA256 متن UTF-8: `6ba1197fcbc52f0fbd9320c26b8124f2d2a2637b079184743765bb375ab41b6f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Islamic-Iranian culture
```

### L03-112 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L03-112.weba`
- voice: `sage`
- slot: `data-audio-id="L03-112"`
- SHA256 متن UTF-8: `6a90f650bd0d761ca636eb3cdd5af9df876a24af8926e90aed72854c2b30ac29`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Islamic revolution anniversary
```

### L03-134 — آرتین — en

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L03-134.weba`
- voice: `sage`
- slot: `data-audio-id="L03-134"`
- SHA256 متن UTF-8: `7eeb3fcdb988bc3a91adfa2138568d4b81520b5e7b69a9a907c499cd87c00938`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
We visit our relatives in Norooz. My mother makes lunch. My brother sets the table. I don’t work on holidays. We enjoy our time together.
```

### L03-135 — آرتین — fa

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L03-135.weba`
- voice: `sage`
- slot: `data-audio-id="L03-135"`
- SHA256 متن UTF-8: `9be9ff39e0a3ae6766ad3e657816d970cd33812e2206febc18344d480c4a0856`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در نوشتهٔ مراسم، فعل مثبت سوم‌شخص و شکل پایه پس از does را جدا بررسی کن. سپس صفت‌های ملکی را به صاحبِ هر اسم وصل کن تا my و his و their جابه‌جا نشده باشند.
```

### L03-113 — آرتین — fa

- بخش: جمع‌بندی و مرور فاصله‌دارِ جشن‌ها و مراسم (`summary`)
- کادر: متن اصلی
- فایل: `L03-113.weba`
- voice: `sage`
- slot: `data-audio-id="L03-113"`
- SHA256 متن UTF-8: `bcbced62e025d01a2f5d88116bcb3b7cf594fb6763a9d3215499346b9765dbfe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جمع‌بندیِ جشن‌ها و مراسم، به‌جای بازخوانی کل صفحه، سه جمله از حافظه بساز: یک خبر، یک منفی و یک پرسش. روز بعد یکی از اطلاعات را عوض کن؛ سه روز بعد گفت‌وگوی تازه اجرا کن و هفتهٔ بعد آزمون را با نمونهٔ شخصی تکمیل کن.
```

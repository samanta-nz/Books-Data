# آموزش کامل انگلیسی نهم؛ Prospect 3

هر درس یک HTML مستقل است: فونت، تصاویر برش‌خورده، CSS و JavaScript داخل همان فایل‌اند. برای استفادهٔ آموزشی نیازی به اینترنت یا پوشهٔ assets نیست. فایل‌ها را پس از استخراج ZIP با مرورگر باز کنید.

| درس | HTML مستقل | راهنمای صوت | قطعات صوتی |
|---|---|---|---|
| 1؛ شخصیت | [engl9-l01-personality.html](G09-L01-Personality/engl9-l01-personality.html) | [متن و راهنمای TTS](G09-L01-Personality/L01-TTS-guide.md) | 176 |
| 2؛ سفر | [engl9-l02-travel.html](G09-L02-Travel/engl9-l02-travel.html) | [متن و راهنمای TTS](G09-L02-Travel/L02-TTS-guide.md) | 141 |
| 3؛ جشن‌ها و مراسم | [engl9-l03-festivals-and-ceremonies.html](G09-L03-Festivals-and-Ceremonies/engl9-l03-festivals-and-ceremonies.html) | [متن و راهنمای TTS](G09-L03-Festivals-and-Ceremonies/L03-TTS-guide.md) | 135 |
| 4؛ خدمات | [engl9-l04-services.html](G09-L04-Services/engl9-l04-services.html) | [متن و راهنمای TTS](G09-L04-Services/L04-TTS-guide.md) | 144 |
| 5؛ رسانه‌ها | [engl9-l05-media.html](G09-L05-Media/engl9-l05-media.html) | [متن و راهنمای TTS](G09-L05-Media/L05-TTS-guide.md) | 140 |
| 6؛ سلامت و آسیب‌ها | [engl9-l06-health-and-injuries.html](G09-L06-Health-and-Injuries/engl9-l06-health-and-injuries.html) | [متن و راهنمای TTS](G09-L06-Health-and-Injuries/L06-TTS-guide.md) | 157 |

مجموع: 893 متن صوتی و 263 پرسش خودکار؛ علاوه بر فعالیت‌های نوشتاری، گفتاری و انتخاب ساختار. هر درس آزمون ۱۲ سؤالی و ارزیابی عملکردی جدا دارد.

صوت آموزشی نهایی در این مرحله تولید نشده است. متن تمام قطعات، گوینده، زبان، شناسه، محل پخش و SHA256 در Markdown و manifest همان درس آمده است. اسکریپت tts_pipeline.py در هر پوشه با HTML همان درس کار می‌کند؛ بعد از تولید WebA/Opus، صوت‌ها با Base64 در یک HTML تازه تزریق می‌شوند.

قواعد نهایی و گزارش بررسی فنی نیز همراه بسته‌اند. متن‌های شنیداریِ تألیفی، پاسخ رسمیِ کتاب گویا معرفی نشده‌اند.

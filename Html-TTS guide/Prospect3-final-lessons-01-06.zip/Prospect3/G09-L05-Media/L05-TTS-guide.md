# راهنمای کامل تولید و تزریق صوت؛ درس 5 — رسانه‌ها

تعداد قطعات: 140. این فایل تمام متن‌های گفتاری را دارد؛ ایجنت متن تازه ننویسد، تکرار یا خلاصه نکند. هر متن دقیقاً با p.tts-text در HTML برابر است. متن اصلی کتاب و شنیداری‌های تألیفی با هم اشتباه نشوند.

## پرامپت TTS

Read only the exact input. Do not add an introduction, summary, translation, music, or speaker label. Use fluent Iranian Persian for fa and clear General American English for en. Keep each character's voice fixed. Read dialogue as conversation. Use meaningful short pauses and a moderate teaching pace. Follow the delivery field for pronunciation and intonation. Never pronounce IDs, arrows or metadata.

## رابط و قرارداد فایل

نام مدرس آرتین و نام یادگیرنده رها است. کنترل ترجمه در همان ناحیه قرار دارد. همهٔ بخش‌های اصلی در منبع بسته‌اند؛ در اجرا فقط یکی باز و آخرین انتخاب ذخیره می‌شود. پنل فلوتر در وب‌ویو تمام‌صفحه است. هیچ پنل مدرس، تولید صوت، خوانش دستگاه، چاپ یا دانلود یادداشت به HTML اضافه نکن. هر آیکون داخل audio-block باید فقط صوت همان ID را پخش/مکث کند. پخش تازه باید صوت قبلی، از جمله ضبط شخصی، را متوقف کند.

متن‌های کادرهای کمکی، پاسخ‌های بازشونده و نکات تلفظی هم قطعات مستقل دارند. ترتیب clips ترتیب تدریس است؛ شماره‌ها را تغییر نده. برای هر قطعه یک فایل L05-NNN.weba و JSON منشأ لازم است. hash متن و فایل را کنترل کن؛ یکسان بودن نام فایل به‌تنهایی کافی نیست.

## کیفیت و حجم

ظرف WebM فقط صوتی، codec Opus، تک‌کاناله، 48000 Hz، VBR حدود 40 kb/s و application=voip. تغییر پسوند MP3 به WebA تبدیل نیست. loudness هدف حدود -18 LUFS و true peak حداکثر -2 dBTP؛ اسکریپت از loudnorm تک‌مرحله‌ای استفاده می‌کند. خروجی را برای قطع نشدن کلمات، وضوح صداها و ثبات نقش‌ها بشنو. Base64 تقریباً یک‌سوم به حجم باینری اضافه می‌کند. موسیقی و افکت اضافه نکن.

## اجرا

نیازمند Python 3.10+، ffmpeg و ffprobe با libopus است. OPENAI_API_KEY فقط در محیطِ ایجنت تولیدکننده قرار بگیرد؛ در HTML و Markdown نوشته نشود. --generate درخواست شبکه‌ای هزینه‌دار دارد؛ --embed آفلاین است. در این تحویل هنوز صوت آموزشی نهایی تولید نشده است.

```bash
python tts_pipeline.py engl9-l05-media.html
python tts_pipeline.py engl9-l05-media.html --generate --only L05-001,L05-002 --audio-dir audio-l05
python tts_pipeline.py engl9-l05-media.html --generate --audio-dir audio-l05
python tts_pipeline.py engl9-l05-media.html --embed --audio-dir audio-l05 --output engl9-l05-media-with-audio.html
```

ابتدا فارسی و انگلیسی و دو نقشِ گفت‌وگو را نمونه‌گیری و شنیداری کنترل کن. صداهای سرویس مطابق voice هر قطعه‌اند؛ اگر سرویس دیگری استفاده شد، نگاشت ثابت معادل ثبت شود. فایل خام را برای QA نگه دار. برای صوت وارداتی از ایجنت دیگر، پس از تطبیق انسانی متن می‌توان --accept-imports را هنگام embed به کار برد؛ این گزینه تشخیص خودکار صحت گفتار نیست.

```bash
ffmpeg -i source.mp3 -vn -map_metadata -1 -af loudnorm=I=-18:TP=-2:LRA=7 -ar 48000 -ac 1 -c:a libopus -b:a 40k -vbr on -application voip -f webm L05-001.weba
```

## تزریق دقیق

manifest داخلی با id=tts-manifest را بخوان. اسکریپت متن HTML، SHA256 متن و SHA256 فایل را بررسی می‌کند. هر data-audio-id دقیقاً یک audio مخفی دارد. src آن باید data:audio/webm;codecs=opus;base64,... باشد. تمام صوت‌ها داخل همان HTML هستند؛ مسیر خارجی یا iframe نگذار. اسکریپت فایل ناقص را تحویل نمی‌دهد و منبع اصلی را بازنویسی نمی‌کند.

پس از تزریق، شمار audioهای دارای src باید با شمار manifest برابر باشد. یک بخش و یک کادر کمکی را باز کن؛ دکمه باید صوت همان قسمت را اجرا کند. پخش دو قسمت پشت‌سرهم باید اولی را قطع کند. شنیداری A و B بدون باز کردن متن قابل پخش‌اند. گوشی و دسکتاپ، سرعت، توقف، منوی تمام‌صفحه و حالت آفلاین را بررسی کن. تلفظ و نوبت دیالوگ به بازبینی انسانی نیاز دارند؛ آزمون فنیِ پخش به معنی تأیید تلفظ نیست.

## متن کامل قطعات

فقط متن کادر text را به سرویس بده؛ عنوان و metadata خوانده نشوند.

### L05-001 — آرتین — fa

- بخش: درس 5؛ رسانه‌ها و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L05-001.weba`
- voice: `sage`
- slot: `data-audio-id="L05-001"`
- SHA256 متن UTF-8: `ca8fd117f01c53e8e752652deea52c885d2d213b0bf68a98a39c227fa80eb028`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس «رسانه‌ها» می‌آموزی از کارهای تمام‌شدهٔ گذشته دربارهٔ رسانه‌ها گزارش بدهی، سؤال با did بسازی و was و were را درست انتخاب کنی.
```

### L05-002 — آرتین — en

- بخش: درس 5؛ رسانه‌ها و هدف یادگیری (`goals`)
- کادر: متن اصلی
- فایل: `L05-002.weba`
- voice: `sage`
- slot: `data-audio-id="L05-002"`
- SHA256 متن UTF-8: `5c7f15f9e8a4fbf372ba4d75a3b3e320880f7417e7a394168c3ae18c26387913`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Lesson 5. Media. Use the language in a new situation.
```

### L05-120 — آرتین — fa

- بخش: درس 5؛ رسانه‌ها و هدف یادگیری (`goals`)
- کادر: مسیر پیشنهادی همین درس
- فایل: `L05-120.weba`
- voice: `sage`
- slot: `data-audio-id="L05-120"`
- SHA256 متن UTF-8: `c8a9e005bede0c2ba6b3e7ab4c2ed5abc7c94a8ea52b854a9505ac95f9947e3b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پیش از شروعِ رسانه‌ها، سنجش ورودی را انجام بده. کمتر از شش پاسخ درست از هشت یعنی مرور پل پیش‌نیاز لازم است. سپس به ترتیبِ فهرست پیش برو؛ پس از هر الگو، پاسخ خودت را پیش از باز کردن راه‌حل بساز.
```

### L05-003 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-003.weba`
- voice: `sage`
- slot: `data-audio-id="L05-003"`
- SHA256 متن UTF-8: `5d2f890368915395014f0ee9c188c8c1b54e9a002fd8c3cb0f7238843f0353e0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از هفتم و هشتم، ساعت و روز، فعل‌های روزمره و ابزارهای ارتباطی را مرور کن. از درس‌های پیشین، تفاوت be با فعل اصلی و ساخت سؤال با فعل کمکی را لازم داری؛ این بار زمان فعل کمکی به گذشته تغییر می‌کند.
```

### L05-004 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-004.weba`
- voice: `sage`
- slot: `data-audio-id="L05-004"`
- SHA256 متن UTF-8: `3c1d8d96bddd1d2df5a7e5354cd795fea510ee890a3a82fd10b4b347c48198a1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در زمان حال می‌گویی I watch TV و پرسش با do می‌سازی. برای کاری که دیروز تمام شده، watched و did لازم می‌شود. نشانهٔ زمان، به تو کمک می‌کند ساختار را انتخاب کنی.
```

### L05-005 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-005.weba`
- voice: `sage`
- slot: `data-audio-id="L05-005"`
- SHA256 متن UTF-8: `84153c15e3b95980e91dda45aee31a6c32709021de132af8446ef21e142f2e47`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watch TV every day. I watched TV yesterday.
```

### L05-006 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-006.weba`
- voice: `sage`
- slot: `data-audio-id="L05-006"`
- SHA256 متن UTF-8: `c0bc8bc5680b6fa7ec84dc30c4928fc94141b51f2387c4ea7e6b72f8e0192b5d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
دیروز، دیشب، هفتهٔ قبل و دو روز پیش به زمان تمام‌شده اشاره می‌کنند. last night با yesterday night جایگزین نمی‌شود؛ عبارت طبیعی همان last night است.
```

### L05-007 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-007.weba`
- voice: `sage`
- slot: `data-audio-id="L05-007"`
- SHA256 متن UTF-8: `8f24d74a942760142dd9851701af53de3d9e05d243c0020432d318887587c78f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yesterday. Last night. Last week. Two days ago.
```

### L05-008 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-008.weba`
- voice: `sage`
- slot: `data-audio-id="L05-008"`
- SHA256 متن UTF-8: `d71c110eea904bd534b4a3828046816aa3e7cc0c7422592d1d7cb925e65116fd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در درس یک، I am happy دربارهٔ وضعیت اکنون بود. برای وضعیت گذشته، am به was و are به were تبدیل می‌شود؛ فعل اصلیِ دیگری لازم نیست.
```

### L05-009 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: متن اصلی
- فایل: `L05-009.weba`
- voice: `sage`
- slot: `data-audio-id="L05-009"`
- SHA256 متن UTF-8: `860c4acb98007dac9a496c529b1a4508b0ca2a1f4ba9750e2894de3aee701da2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I am happy now. I was happy yesterday. They were busy last week.
```

### L05-121 — آرتین — fa

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L05-121.weba`
- voice: `sage`
- slot: `data-audio-id="L05-121"`
- SHA256 متن UTF-8: `ada82ed1a0263815c262d22ecb9cf6cf26cdfbfc2e0ff9581d2c02cab817a3fd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
سه زمانِ now، every day و yesterday را روی سه خط بنویس. برای yesterday یک کارِ تمام‌شده و برای now یک وضعیت انتخاب کن؛ شکل فعل را از روی زمان و نوع فعل تعیین کن.
```

### L05-122 — آرتین — en

- بخش: پل پایه‌های پیشین؛ دانسته‌های لازم (`bridge`)
- کادر: یک گام کوچک‌تر برای شروع
- فایل: `L05-122.weba`
- voice: `sage`
- slot: `data-audio-id="L05-122"`
- SHA256 متن UTF-8: `84153c15e3b95980e91dda45aee31a6c32709021de132af8446ef21e142f2e47`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watch TV every day. I watched TV yesterday.
```

### L05-010 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-010.weba`
- voice: `sage`
- slot: `data-audio-id="L05-010"`
- SHA256 متن UTF-8: `bde166fbb4c1b83d7aeb494ba1bb06d968ba23610cc3e53e3d83b4be880ebaff`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
interview somebody. She interviewed a writer.
```

### L05-011 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-011.weba`
- voice: `sage`
- slot: `data-audio-id="L05-011"`
- SHA256 متن UTF-8: `43137ad1e3f7b4d71dd056f3ad2964cb078bfe1a5f5036b75c4115b1c4174abc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
text a message. I texted a message to my friend.
```

### L05-012 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-012.weba`
- voice: `sage`
- slot: `data-audio-id="L05-012"`
- SHA256 متن UTF-8: `823185e18eaded24d992c5b6cd0e6789828c3219ff402715d8bc6c7531b0a2d0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
receive an e-mail. He received an e-mail yesterday.
```

### L05-013 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-013.weba`
- voice: `sage`
- slot: `data-audio-id="L05-013"`
- SHA256 متن UTF-8: `d0b53941cc6cbacb9afc83dd593ff8af8b3943df11c23562ac297f2f413249fe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
update a blog. They updated their blog.
```

### L05-014 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-014.weba`
- voice: `sage`
- slot: `data-audio-id="L05-014"`
- SHA256 متن UTF-8: `b4461417b891f81808e2827bdb33890636ecfc8e2ebcda28f9f47eb9362e314e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
participate in an online course. We participated in an online course.
```

### L05-015 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-015.weba`
- voice: `sage`
- slot: `data-audio-id="L05-015"`
- SHA256 متن UTF-8: `aa9343dcaaa883042ddc94b3ceb3662af13355c73cb5bbe8f9c4270353cd2260`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
connect to the Internet. She connected to the Internet at school.
```

### L05-016 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-016.weba`
- voice: `sage`
- slot: `data-audio-id="L05-016"`
- SHA256 متن UTF-8: `71f11b687169aaf0349190fdd9add7edbe745eadf612ddd5eefbe60240d09af7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
download something. I downloaded a book last night.
```

### L05-017 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-017.weba`
- voice: `sage`
- slot: `data-audio-id="L05-017"`
- SHA256 متن UTF-8: `0f8e8a23cc6d5fe9e0d97cbf2ad792060b434ef403f4621672775f7ac6608727`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
attend a TV program. He attended a TV program.
```

### L05-018 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-018.weba`
- voice: `sage`
- slot: `data-audio-id="L05-018"`
- SHA256 متن UTF-8: `592be00e8b6560c8c0a0ce417cd491a59b8d2e30d4e228a5c58ef642b623cecb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
use Information Technology. We used Information Technology for our project.
```

### L05-019 — آرتین — en

- بخش: واژگان تصویری و کاربرد هر عبارت (`vocabulary`)
- کادر: متن اصلی
- فایل: `L05-019.weba`
- voice: `sage`
- slot: `data-audio-id="L05-019"`
- SHA256 متن UTF-8: `22757929e79f2c8aedadc5e1accd3d366483493e0e3c65286465f7f90f977435`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
install a computer dictionary. My sister installed a computer dictionary.
```

### L05-020 — Mina — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-020.weba`
- voice: `coral`
- slot: `data-audio-id="L05-020"`
- SHA256 متن UTF-8: `bd274a75618bf49a5258d1272e801904cebe1b70961fe9a1a6f249a52fd67a2c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you enjoy your weekend?
```

### L05-021 — Mahsa — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-021.weba`
- voice: `nova`
- slot: `data-audio-id="L05-021"`
- SHA256 متن UTF-8: `a3e7a9fc2da752e349cb38d99cfe022c1cda7c1563df4d3394c2794bd5eb9ff4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, it was wonderful! I attended Fajr International Film Festival.
```

### L05-022 — Mina — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-022.weba`
- voice: `coral`
- slot: `data-audio-id="L05-022"`
- SHA256 متن UTF-8: `1f609d318d4712146d19655b556ae16ca71105efea1bc3b96f4c181d3a39a6bc`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Really? I am also interested in its events and movies.
```

### L05-023 — Mahsa — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-023.weba`
- voice: `nova`
- slot: `data-audio-id="L05-023"`
- SHA256 متن UTF-8: `7485e83ba727f4aa63d07989bf313cc16c10c7b1e6700065d229aad52adc9609`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Oh, did you watch the reports on TV last night?
```

### L05-024 — Mina — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-024.weba`
- voice: `coral`
- slot: `data-audio-id="L05-024"`
- SHA256 متن UTF-8: `15cccb3aba5d22b57fc1f8ee814b1151a9f78589789bad31b661e629e738eabe`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I did, but I like to read about them.
```

### L05-025 — Mahsa — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-025.weba`
- voice: `nova`
- slot: `data-audio-id="L05-025"`
- SHA256 متن UTF-8: `62b8104c06bbbc36cd08e128cf77c3e5693054f5c706990c85e02262747aaaf8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Well, you can surf its website if you like. There are many interesting things there.
```

### L05-026 — Mina — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-026.weba`
- voice: `coral`
- slot: `data-audio-id="L05-026"`
- SHA256 متن UTF-8: `784188efe6cb5a4c62e8869c863d45ef2f7b67907605c5f06dd3f5e1dc9b77bd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
That’s great! Could you please give me the website address?
```

### L05-027 — Mahsa — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-027.weba`
- voice: `nova`
- slot: `data-audio-id="L05-027"`
- SHA256 متن UTF-8: `54466a10b68f085a6ce83295e98768f3d4040ee40be765d964e85174192a2e87`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Why not! Just a moment. Umm… I just texted it.
```

### L05-028 — Mina — en

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: متن اصلی
- فایل: `L05-028.weba`
- voice: `coral`
- slot: `data-audio-id="L05-028"`
- SHA256 متن UTF-8: `9239b546d1a424fab541c17763aed1b3bdbaa6c5c35e9bb72fe1202762b258b1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Thanks a lot.
```

### L05-123 — آرتین — fa

- بخش: مکالمهٔ کتاب؛ معنی و نقش‌ها (`conversation`)
- کادر: اجرای گفت‌وگو بدون وابستگی به متن
- فایل: `L05-123.weba`
- voice: `sage`
- slot: `data-audio-id="L05-123"`
- SHA256 متن UTF-8: `b67c4000c96aeb7f78c20034ec663a6419c5d16ba7556859e2017cd4b3eff7e9`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گفت‌وگوی رسانه، نام رویداد و روش فرستادن نشانی را تغییر بده. طرف مقابل یک سؤال با did دربارهٔ تجربه و یک سؤال دربارهٔ اطلاعات کنونی بپرسد تا دو زمان را در بافت جدا نگه دارید.
```

### L05-029 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-029.weba`
- voice: `sage`
- slot: `data-audio-id="L05-029"`
- SHA256 متن UTF-8: `bca4fcc14f05eb776744d92c508bb403f0c0b028486f2677fc3989f96320931a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did the girls listen to the radio?
```

### L05-030 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-030.weba`
- voice: `coral`
- slot: `data-audio-id="L05-030"`
- SHA256 متن UTF-8: `d946bf21fd9186ba31ca3dac02a52c7492c1b7cab2c6d6c7cd0c823030bebd4f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, they did.
```

### L05-031 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-031.weba`
- voice: `sage`
- slot: `data-audio-id="L05-031"`
- SHA256 متن UTF-8: `2d015e7ce447107552d6d909f44c0f36e2c09dc0690e479f91902dc3586c834d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did Mina surf the Internet?
```

### L05-032 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-032.weba`
- voice: `coral`
- slot: `data-audio-id="L05-032"`
- SHA256 متن UTF-8: `3deb27925e9423f084cd91aebec8ac19a646c4375f8cba40aaad254cf6ed5ee2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, she didn’t.
```

### L05-033 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-033.weba`
- voice: `sage`
- slot: `data-audio-id="L05-033"`
- SHA256 متن UTF-8: `f9f37850b74553e2bed3f9eeb3408e9a491492f59991dcf754355f9bb9e9f074`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you watch the cartoon?
```

### L05-034 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-034.weba`
- voice: `coral`
- slot: `data-audio-id="L05-034"`
- SHA256 متن UTF-8: `f05d2893531af567f81dce3dc8053c27733e6ef2f7e467d7085832a5193ae23c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, we watched it.
```

### L05-035 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-035.weba`
- voice: `sage`
- slot: `data-audio-id="L05-035"`
- SHA256 متن UTF-8: `4edc9e022e57a707c9dd84cd997d202091d5a6c37d0f0ae050d044c6b6d13299`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did Amir work with his computer?
```

### L05-036 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-036.weba`
- voice: `coral`
- slot: `data-audio-id="L05-036"`
- SHA256 متن UTF-8: `db60cbda4f1b03995ab5665e75b4ae6e88b39775899038e5055ea0f940b1f82f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, he worked with his mobile.
```

### L05-037 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-037.weba`
- voice: `sage`
- slot: `data-audio-id="L05-037"`
- SHA256 متن UTF-8: `6ab0a8f735b98287ab3618db1e161b036e18ccfc01643c0259ec9a017b31b4c2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who watched the movie last night?
```

### L05-038 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-038.weba`
- voice: `coral`
- slot: `data-audio-id="L05-038"`
- SHA256 متن UTF-8: `cb9fb74200a6c4a776d74c75cc09dc71b5dacbd7375946e2a4981b0055118a61`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
My sister.
```

### L05-039 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-039.weba`
- voice: `sage`
- slot: `data-audio-id="L05-039"`
- SHA256 متن UTF-8: `a6a11d8e0d261f8d57a4872e43cee9604cc283dc2cf7ace590bb242d1c6f3543`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What did you do last week?
```

### L05-040 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-040.weba`
- voice: `coral`
- slot: `data-audio-id="L05-040"`
- SHA256 متن UTF-8: `122969ca5504ddb6218274a39b823f12a2b8136a2434b33a26372556c6b39a8c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I attended Fajr International Film Festival.
```

### L05-041 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-041.weba`
- voice: `sage`
- slot: `data-audio-id="L05-041"`
- SHA256 متن UTF-8: `df4c1f39761ab9aa544823cbd665ef1f54cb443b02ef38d67ef3647ac38835f3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What did Ali receive?
```

### L05-042 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-042.weba`
- voice: `coral`
- slot: `data-audio-id="L05-042"`
- SHA256 متن UTF-8: `aa5bbba39be6926ba03f86b6fb9584d472892f4ff58b773bb5807eb38cd22688`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
He received an email.
```

### L05-043 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-043.weba`
- voice: `sage`
- slot: `data-audio-id="L05-043"`
- SHA256 متن UTF-8: `3149cbc8d03f2db0d09c6bb3698d183d8e73ae6a7d114b702b6f0ffa54997a35`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
When did they download the book?
```

### L05-044 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-044.weba`
- voice: `coral`
- slot: `data-audio-id="L05-044"`
- SHA256 متن UTF-8: `fe1891221be561ea4765b5843cc158ab1f8cdd52a14ddd15c3632970061b711f`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They downloaded it yesterday.
```

### L05-045 — آرتین — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-045.weba`
- voice: `sage`
- slot: `data-audio-id="L05-045"`
- SHA256 متن UTF-8: `52829b30f8d04888249193b557a39bc08597742864c91a2c0a66311b79ba4493`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did she connect to the Internet?
```

### L05-046 — رها — en

- بخش: الگوهای Practice؛ پرسش و جواب کامل (`patterns`)
- کادر: متن اصلی
- فایل: `L05-046.weba`
- voice: `coral`
- slot: `data-audio-id="L05-046"`
- SHA256 متن UTF-8: `97d3ba44af6936afd53baa7f2e51615049dbe189e1d69798d2b527b56c7c19b1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She connected to the Internet at school.
```

### L05-047 — آرتین — fa

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-047.weba`
- voice: `sage`
- slot: `data-audio-id="L05-047"`
- SHA256 متن UTF-8: `c914f4f1a0f20e83ce9fb365514f11fd068b39b45e709c04f7b65acf031ce4b7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای کاری که در زمان گذشته انجام شده و تمام شده، شکل گذشتهٔ فعل را به کار می‌بریم. در فعل باقاعده معمولاً ed می‌آید. این شکل برای همهٔ فاعل‌ها یکسان است؛ در گذشته برای he یا she، s جداگانه نداریم.
```

### L05-048 — آرتین — en

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-048.weba`
- voice: `sage`
- slot: `data-audio-id="L05-048"`
- SHA256 متن UTF-8: `71c6c0cd3fe3ed55b9db42395c62d3fb651189d7bb52c78aebb87125279198db`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watched TV. She watched TV. They watched TV.
```

### L05-049 — آرتین — fa

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-049.weba`
- voice: `sage`
- slot: `data-audio-id="L05-049"`
- SHA256 متن UTF-8: `40325f72ad305d8b1b9964252531eb5ccadb97543943b5ec65c2859e0124df64`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
اگر فعل به e ختم شود فقط d می‌افزاییم. در study، y پس از همخوان به ied تبدیل می‌شود؛ در play فقط ed اضافه می‌شود. فعل کوتاهِ plan در این الگو حرف آخر را دو برابر می‌کند، اما visited چنین تغییری ندارد.
```

### L05-050 — آرتین — en

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-050.weba`
- voice: `sage`
- slot: `data-audio-id="L05-050"`
- SHA256 متن UTF-8: `6204ad5e271c1315cff3788a6d7615e94752a81227b7c6fdfca0071ecd1ec5ff`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Receive, received. Study, studied. Play, played. Plan, planned. Visit, visited.
```

### L05-051 — آرتین — fa

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-051.weba`
- voice: `sage`
- slot: `data-audio-id="L05-051"`
- SHA256 متن UTF-8: `b7088fe80b4ced554bd37f24e3b52bd1b3a07a358757a4181186ac4d62ffafe6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
yesterday، last week و two days ago زمان گذشته را روشن می‌کنند. ago پس از مقدار زمان می‌آید. در جملهٔ پاسخ، به سؤال when همان اطلاعات زمانی را بده، نه مکان.
```

### L05-052 — آرتین — en

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: متن اصلی
- فایل: `L05-052.weba`
- voice: `sage`
- slot: `data-audio-id="L05-052"`
- SHA256 متن UTF-8: `2b56587b73e8ac5e339a997cdbcf15b350b53c9a06c70127c1ecbf97a490f1f7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They downloaded it two days ago. When did they download it? Two days ago.
```

### L05-124 — آرتین — fa

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-124.weba`
- voice: `sage`
- slot: `data-audio-id="L05-124"`
- SHA256 متن UTF-8: `700323217a2fd4459769394acf52ec4f2bc46cbd05266f6b6f26af75f73e4e08`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
study، receive و visit را به گذشته ببر و در سه جمله با yesterday به کار ببر. y، e و تکیهٔ فعل را جدا بررسی کن؛ نمی‌توان برای همه یک تغییر املایی یکسان نوشت.
```

### L05-125 — آرتین — en

- بخش: گذشتهٔ سادهٔ باقاعده؛ فعلِ تمام‌شده (`grammar`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-125.weba`
- voice: `sage`
- slot: `data-audio-id="L05-125"`
- SHA256 متن UTF-8: `71c6c0cd3fe3ed55b9db42395c62d3fb651189d7bb52c78aebb87125279198db`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watched TV. She watched TV. They watched TV.
```

### L05-053 — آرتین — fa

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-053.weba`
- voice: `sage`
- slot: `data-audio-id="L05-053"`
- SHA256 متن UTF-8: `1f4d77f1558967c1001175da86d07c1756289671d665a77ce3afb1a6b42314a4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در منفی از didn’t و شکل پایهٔ فعل استفاده می‌کنیم. پایان ed از فعل اصلی برداشته می‌شود چون گذشته بودن در did بیان شده است.
```

### L05-054 — آرتین — en

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-054.weba`
- voice: `sage`
- slot: `data-audio-id="L05-054"`
- SHA256 متن UTF-8: `885e0d3bd32cb2635cdabba088e898bf86841458b14c33cf6cf8db160c95d324`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She downloaded it. She didn’t download it.
```

### L05-055 — آرتین — fa

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-055.weba`
- voice: `sage`
- slot: `data-audio-id="L05-055"`
- SHA256 متن UTF-8: `cd28844c86e85f3185d6316fda1beec24911613f613979859fcb2abb4b1ac841`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای سؤال بله یا خیر، did را پیش از فاعل می‌گذاریم. فاعل هرچه باشد did ثابت می‌ماند. پاسخ کوتاه با did یا didn’t تمام می‌شود.
```

### L05-056 — آرتین — en

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-056.weba`
- voice: `sage`
- slot: `data-audio-id="L05-056"`
- SHA256 متن UTF-8: `d2153e733f6fd6fdbbeac6169aa0de811d0f4f5ee2f4e8efaaa5373253f52fa7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did he receive an e-mail? Yes, he did. Did they call? No, they didn’t.
```

### L05-057 — آرتین — fa

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-057.weba`
- voice: `sage`
- slot: `data-audio-id="L05-057"`
- SHA256 متن UTF-8: `1ac7b33605a841bbd68f9efb2a6464ef066554fa9a28169d2dc8abf2991f0e29`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در پرسش Wh، واژهٔ پرسشی پیش از did می‌آید. وقتی who خودش فاعل است، معمولاً did نداریم و فعل به شکل گذشته باقی می‌ماند.
```

### L05-058 — آرتین — en

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: متن اصلی
- فایل: `L05-058.weba`
- voice: `sage`
- slot: `data-audio-id="L05-058"`
- SHA256 متن UTF-8: `ade259a478494f8a5dfeaabaf220f141837b6ee13984b8a0959a3d5a00a2bf9c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What did she update? Who updated the blog?
```

### L05-126 — آرتین — fa

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-126.weba`
- voice: `sage`
- slot: `data-audio-id="L05-126"`
- SHA256 متن UTF-8: `2590eb3cfabb070ea13c34fbb99c751f7a9bf5214b68fa60b37428921fff8f63`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
از She updated the blog هم سؤال بله یا خیر و هم پرسش با what بساز. در هر دو، update پس از did به پایه برمی‌گردد. برای فاعل نامعلوم، Who updated the blog را بساز.
```

### L05-127 — آرتین — en

- بخش: did؛ یک فعل کمکی برای همهٔ فاعل‌ها (`negative`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-127.weba`
- voice: `sage`
- slot: `data-audio-id="L05-127"`
- SHA256 متن UTF-8: `885e0d3bd32cb2635cdabba088e898bf86841458b14c33cf6cf8db160c95d324`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
She downloaded it. She didn’t download it.
```

### L05-059 — آرتین — fa

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-059.weba`
- voice: `sage`
- slot: `data-audio-id="L05-059"`
- SHA256 متن UTF-8: `8fadac80116167bec945bff2c0081032b35e7421471c915c21a1460346dd28c4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
I و he و she و it در گذشته با was می‌آیند. you و we و they با were. این ساختار وضعیت، هویت یا مکان در گذشته را بیان می‌کند و به ed یا did نیاز ندارد.
```

### L05-060 — آرتین — en

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-060.weba`
- voice: `sage`
- slot: `data-audio-id="L05-060"`
- SHA256 متن UTF-8: `4640644286c5e28efd56d7e165ef2562a31c83ceee8702818444a50c34a33d99`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I was busy. She was happy. They were at school.
```

### L05-061 — آرتین — fa

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-061.weba`
- voice: `sage`
- slot: `data-audio-id="L05-061"`
- SHA256 متن UTF-8: `739abd70206fcccc9fc86a60f28d545981079f30d7ebcd5f32a57f55f8f47fdd`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای منفی، not پس از was یا were قرار می‌گیرد؛ برای سؤال، همان فعل جلو می‌رود. Did she was happy? نادرست است چون دو روش را با هم مخلوط کرده‌ای.
```

### L05-062 — آرتین — en

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-062.weba`
- voice: `sage`
- slot: `data-audio-id="L05-062"`
- SHA256 متن UTF-8: `a90bc2d5378dd7e4c1422645f447b5de07cd270b3b5fe5e38b12bcc20aae2c98`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Was she happy? No, she wasn’t. Were they busy? Yes, they were.
```

### L05-063 — آرتین — fa

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-063.weba`
- voice: `sage`
- slot: `data-audio-id="L05-063"`
- SHA256 متن UTF-8: `ad0cb91641ea4d2c3477fd048715463241ae03dfde63a1c57c646be877e9275b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
there was و there were وجود چیزی را در گذشته معرفی می‌کنند. مانند زمان حال، مفرد و جمع مهم است.
```

### L05-064 — آرتین — en

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: متن اصلی
- فایل: `L05-064.weba`
- voice: `sage`
- slot: `data-audio-id="L05-064"`
- SHA256 متن UTF-8: `002a4dab54f47cc7066aafe8ae8d26a4384cced34116fadbd90d0d6f46b5b633`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
There was a newspaper in the library. There were many messages in my mailbox.
```

### L05-128 — آرتین — fa

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-128.weba`
- voice: `sage`
- slot: `data-audio-id="L05-128"`
- SHA256 متن UTF-8: `ed3eb1fb0882ace06c5861e4baf4cfce08444e70d2cdccbd4b571bf38c2710be`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای I و they دو وضعیت در گذشته بنویس. سپس همان دو جمله را منفی کن؛ was یا were را نگه دار و did را وارد ساختار be نکن.
```

### L05-129 — آرتین — en

- بخش: گذشتهٔ be؛ was و were (`extension`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-129.weba`
- voice: `sage`
- slot: `data-audio-id="L05-129"`
- SHA256 متن UTF-8: `4640644286c5e28efd56d7e165ef2562a31c83ceee8702818444a50c34a33d99`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I was busy. She was happy. They were at school.
```

### L05-065 — آرتین — fa

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: متن اصلی
- فایل: `L05-065.weba`
- voice: `sage`
- slot: `data-audio-id="L05-065"`
- SHA256 متن UTF-8: `e29af1d3b2c6371bd61c61cd62ac76e8473be223b7a3983bc624a4f8dd3067b6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در مکالمهٔ کتاب، Did you enjoy دربارهٔ آخر هفتهٔ تمام‌شده است، اما I am interested علاقهٔ فعلی را می‌گوید. در یک گفت‌وگو ممکن است چند زمان وجود داشته باشد؛ هر جمله را با هدف خودش بسنج.
```

### L05-066 — آرتین — en

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: متن اصلی
- فایل: `L05-066.weba`
- voice: `sage`
- slot: `data-audio-id="L05-066"`
- SHA256 متن UTF-8: `228b9407b90c2b75ece0ebde4c175dcf31e176900a59dc68ec5efbcf99f9cc80`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watched the report last night. I am interested in movies.
```

### L05-067 — آرتین — fa

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: متن اصلی
- فایل: `L05-067.weba`
- voice: `sage`
- slot: `data-audio-id="L05-067"`
- SHA256 متن UTF-8: `c1befebec70856906f1c43c93417b628a57755aa39f80d6b39bcbf639e3f975b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
was wonderful دربارهٔ کیفیت یک تجربه است؛ attended یک کارِ گذشته را نام می‌برد. برای کیفیت می‌پرسی How was it? و برای فعالیت می‌پرسی What did you do?
```

### L05-068 — آرتین — en

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: متن اصلی
- فایل: `L05-068.weba`
- voice: `sage`
- slot: `data-audio-id="L05-068"`
- SHA256 متن UTF-8: `66a3ae8f0e7755528a9fb65bad43803dd91a2a2e5c8aae921e1d474b5b773ea6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How was your weekend? It was wonderful. What did you do? I attended a festival.
```

### L05-130 — آرتین — fa

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-130.weba`
- voice: `sage`
- slot: `data-audio-id="L05-130"`
- SHA256 متن UTF-8: `f4dda89214642040f0b44d73814a3af7a5a707bbf58ed8b37d4ff44a9dfa05f0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
دو پاسخ به How was your weekend? و What did you do? بنویس. یکی باید کیفیت تجربه را با was بگوید و دیگری یک فعالیت تمام‌شده را با فعل گذشته نام ببرد.
```

### L05-131 — آرتین — en

- بخش: گذشته را با گزارش اکنون مخلوط نکن (`meaning`)
- کادر: آزمایشِ الگو با پاسخ
- فایل: `L05-131.weba`
- voice: `sage`
- slot: `data-audio-id="L05-131"`
- SHA256 متن UTF-8: `228b9407b90c2b75ece0ebde4c175dcf31e176900a59dc68ec5efbcf99f9cc80`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watched the report last night. I am interested in movies.
```

### L05-069 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-069.weba`
- voice: `sage`
- slot: `data-audio-id="L05-069"`
- SHA256 متن UTF-8: `3324dbbdbd9bad5321ec868f3640db418aebbbb4ee32d95e75c0b3bb6f2ceeaa`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
پایان ed را همیشه «اِد» نخوان. watched با صدای ت، played با صدای د و wanted با یک هجای اضافه تمام می‌شود. انتخاب بر پایهٔ آخرین صداست، نه صرفاً آخرین حرف.
```

### L05-070 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-070.weba`
- voice: `sage`
- slot: `data-audio-id="L05-070"`
- SHA256 متن UTF-8: `5ad43dfff4445aaa12a3a5f7b94f9f264bd50c0f656811a7fb769900cff54a7b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Watched. Played. Wanted. I watched TV. She wanted a book.
```

### L05-071 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-071.weba`
- voice: `sage`
- slot: `data-audio-id="L05-071"`
- SHA256 متن UTF-8: `b9dc70263c895fad2956de1c13e01f0d6d7e3dcd7e461dc8879d87fd55a68f0b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در texted به خاطر پایان t، یک هجای اضافی شنیده می‌شود. در received، ed هجای تازه نمی‌سازد. این دو را کنار هم تکرار کن تا تعداد هجاها را تشخیص بدهی.
```

### L05-072 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-072.weba`
- voice: `sage`
- slot: `data-audio-id="L05-072"`
- SHA256 متن UTF-8: `b8f67e09ecac03299e403900e4cd151c750219872ddcd836ef2f41f3014ef371`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Texted. Received. She texted it. He received it.
```

### L05-073 — آرتین — fa

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-073.weba`
- voice: `sage`
- slot: `data-audio-id="L05-073"`
- SHA256 متن UTF-8: `2b5a960d82cb5cd7b764cb95309b209778e1b3eb368f24949f5337deb1f967c3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
کتاب برای بیان شگفتی، آهنگ خیزان معرفی می‌کند. جملهٔ That’s great ممکن است با توجه به حس و موقعیت آهنگ دیگری هم داشته باشد. اینجا نمونهٔ شگفتی را با دامنهٔ زیر و بمی بیشتر اجرا کن.
```

### L05-074 — آرتین — en

- بخش: آموزش نکات تلفظی؛ ویژهٔ درس 5 (`pronunciation`)
- کادر: متن اصلی
- فایل: `L05-074.weba`
- voice: `sage`
- slot: `data-audio-id="L05-074"`
- SHA256 متن UTF-8: `6bc1e8a65c7f9f36bdfb45446277fb3f098cf262ea2d26f2b1d41bf05a075446`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
How fantastic! That’s great! What a wonderful day!
```

### L05-075 — Mahdi — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-075.weba`
- voice: `echo`
- slot: `data-audio-id="L05-075"`
- SHA256 متن UTF-8: `f98cc7bf8e8458c4deb5bec1be7d7e6590cc673efb162bbaa38ba8b35220f44d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
There is a football match on TV tonight.
```

### L05-076 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-076.weba`
- voice: `echo`
- slot: `data-audio-id="L05-076"`
- SHA256 متن UTF-8: `ac9f700898f51943e660bb3d2a26f23e23f18a33358d55dc3c523e6f90200622`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
That’s great news! When?
```

### L05-077 — Mahdi — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-077.weba`
- voice: `echo`
- slot: `data-audio-id="L05-077"`
- SHA256 متن UTF-8: `e8d29b9575adb9d326855408875339386542337fd2b0dbc29941bd0e9f50cad0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
Around 7, I think.
```

### L05-078 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-078.weba`
- voice: `echo`
- slot: `data-audio-id="L05-078"`
- SHA256 متن UTF-8: `17f38fc7e4a69120a63438486f2a38bd858539458bf6a97482674886b0d55c2d`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
Really?! I get home at 6. We can watch it together.
```

### L05-079 — Mahdi — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-079.weba`
- voice: `echo`
- slot: `data-audio-id="L05-079"`
- SHA256 متن UTF-8: `56c852ca80e0a262cbf178268898fbe9ca4fdd7e301dc94b2914b13428542903`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
It’s excellent! Please buy some fruits.
```

### L05-080 — Sam — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-080.weba`
- voice: `echo`
- slot: `data-audio-id="L05-080"`
- SHA256 متن UTF-8: `9aa67527a7dbb66b1b49fafde668a974fc701f7981029c1ecf6951573602d383`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
Ok. That’ll be all fun!
```

### L05-081 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-081.weba`
- voice: `sage`
- slot: `data-audio-id="L05-081"`
- SHA256 متن UTF-8: `a7457d69b72508e66973525b83ad3544fbabb76742b05bc7b1b63dad98e0fea6`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
How fantastic!
```

### L05-082 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-082.weba`
- voice: `sage`
- slot: `data-audio-id="L05-082"`
- SHA256 متن UTF-8: `0a6dc221ace77500348b43e3545dade25655543a2ef6b4a0577170f371b60675`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
That’s great!
```

### L05-083 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-083.weba`
- voice: `sage`
- slot: `data-audio-id="L05-083"`
- SHA256 متن UTF-8: `0a6f6c5ad3bdd557304b2237b5d9157a583019e4d1b2d67657dd0bf70b2f7763`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
That’s really nice!
```

### L05-084 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-084.weba`
- voice: `sage`
- slot: `data-audio-id="L05-084"`
- SHA256 متن UTF-8: `63f38bc2121ed4b4373077c61ed56286f73ab9608c64c4be71ea1bb2b0d18fb2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
It’s brilliant!
```

### L05-085 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-085.weba`
- voice: `sage`
- slot: `data-audio-id="L05-085"`
- SHA256 متن UTF-8: `462164a0645e1ed27e1b1970082fe070d84b343179217a59cfc2d788999c225e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
Well done!
```

### L05-086 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-086.weba`
- voice: `sage`
- slot: `data-audio-id="L05-086"`
- SHA256 متن UTF-8: `7c79e5c8c20a20535dd541e211e24203ece58830a5b85129b5d55312a2a00302`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
It’s amazing!
```

### L05-087 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-087.weba`
- voice: `sage`
- slot: `data-audio-id="L05-087"`
- SHA256 متن UTF-8: `99645b38ff103516a86ade43cffa0116d31f6136a83f99d4fa5b6c19e29c20cf`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
What a wonderful day!
```

### L05-088 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-088.weba`
- voice: `sage`
- slot: `data-audio-id="L05-088"`
- SHA256 متن UTF-8: `a9c8d621ac5127b8510be36a28489ba2ed7e29c3dc563e2d56651c6323bd2db2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
What a beautiful flower!
```

### L05-089 — آرتین — en

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: متن اصلی
- فایل: `L05-089.weba`
- voice: `sage`
- slot: `data-audio-id="L05-089"`
- SHA256 متن UTF-8: `a29de867131825b01c1ba40a8e97af0d4e49ec2a7efc723437824d7ae2e8b704`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
Could you please give it to me?
```

### L05-132 — آرتین — fa

- بخش: آهنگ و گفت‌وگوی Language Melody (`melody`)
- کادر: تمرین تکمیلی تلفظِ رسانه‌ها
- فایل: `L05-132.weba`
- voice: `sage`
- slot: `data-audio-id="L05-132"`
- SHA256 متن UTF-8: `c6d57eb7382b3b68c7d31352266e1b9acb5270a5a3cb954ed523338cf867f0e0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately. This exercise expresses pleasant surprise; use an appropriate lively, often rising contour.

```text
worked، played و wanted را در سه جملهٔ گذشته بخوان. تعداد هجاها را بشمار؛ اگر همه را با یک پایان یکسان گفتی، جدول تلفظ ed را دوباره ببین.
```

### L05-090 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L05-090.weba`
- voice: `sage`
- slot: `data-audio-id="L05-090"`
- SHA256 متن UTF-8: `38add619072f7526cc6c4d6b4d3320e925a22a2f855a001565bc915a5f4dee8c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Last weekend, something happened to our TV. It didn’t work. At first, we were upset. But then we talked about our day. It was really fun! Later, we helped our mother and cleaned the house. In the afternoon, my grandfather showed us how to play an old game. We enjoyed it a lot. All day we were busy doing different things. At night, we all were happy. No one talked about TV!
```

### L05-133 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: ترجمهٔ خواندنی
- فایل: `L05-133.weba`
- voice: `sage`
- slot: `data-audio-id="L05-133"`
- SHA256 متن UTF-8: `007ff5086aed7e76345ea44434b50451c5565790872dbb81e26314d5562fdaee`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
آخر هفتهٔ قبل تلویزیون خراب شد. اول ناراحت بودیم؛ بعد دربارهٔ روزمان صحبت کردیم و خوش گذشت. به مادرمان کمک کردیم و خانه را تمیز کردیم. بعدازظهر پدربزرگ بازی قدیمی‌ای یادمان داد. روز را با کارهای گوناگون گذراندیم و شب خوشحال بودیم. دیگر کسی دربارهٔ تلویزیون حرف نزد.
```

### L05-091 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: متن اصلی
- فایل: `L05-091.weba`
- voice: `sage`
- slot: `data-audio-id="L05-091"`
- SHA256 متن UTF-8: `cb85bc8846d802bc016813113e27922b0f7a032ad322dcead306670dc63f23c2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
صورت‌های گذشتهٔ فعل را انتخاب کن؛ عبارت مصدری to play و شکل doing به‌تنهایی فعل گذشته نیستند.
```

### L05-134 — آرتین — en

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L05-134.weba`
- voice: `sage`
- slot: `data-audio-id="L05-134"`
- SHA256 متن UTF-8: `534f17d1bae2ad12c9322e4917677a69403360e15f090be9a59536afc3a9f3c7`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
happened / didn’t work / were / talked / was / helped / cleaned / showed / enjoyed
```

### L05-135 — آرتین — fa

- بخش: خواندنِ کتاب؛ پیدا کردن شاهد و ساختار (`reading`)
- کادر: کلید ساختارهای هدف
- فایل: `L05-135.weba`
- voice: `sage`
- slot: `data-audio-id="L05-135"`
- SHA256 متن UTF-8: `a9a0440ed57ed2292bf551d0814457fb6c5a5c2cb3cfae430bd79ded5ce2ca1e`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در داستان تلویزیون، were و was هم گذشته‌اند. doing و to play بدون فعلِ صرف‌شدهٔ خودشان، نمونهٔ گذشتهٔ ساده محسوب نمی‌شوند.
```

### L05-092 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن اصلی
- فایل: `L05-092.weba`
- voice: `sage`
- slot: `data-audio-id="L05-092"`
- SHA256 متن UTF-8: `b99233519340d4dd788fff72253668e3e464895a480294260fecfce033bb7690`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
فایل رسمی شنیداری در PDF موجود نیست. دو متن این بخش برای تمرینِ رسانه‌ها تألیف شده‌اند و کلید آن‌ها فقط مربوط به همین متن‌هاست. بار اول اطلاعات اصلی و بار دوم جزئیات پرسش‌ها را یادداشت کن.
```

### L05-093 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی A؛ پس از گوش دادن باز کن
- فایل: `L05-093.weba`
- voice: `sage`
- slot: `data-audio-id="L05-093"`
- SHA256 متن UTF-8: `84b9b45ab6e04bd3e57ddf496185d01cc0686297effdbf10f753efe5124913ba`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Behnam had a useful summer. He learned to use a computer for doing his homework. He also learned to use the Internet for his English classes. He practiced every week.
```

### L05-136 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی A
- فایل: `L05-136.weba`
- voice: `sage`
- slot: `data-audio-id="L05-136"`
- SHA256 متن UTF-8: `88f0863637fab0d569342b04e1ab70aeed7d8f3d71068f85a5a458c0ad440759`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
useful؛ استفاده از رایانه برای تکلیف؛ بله، برای کلاس انگلیسی هم یاد گرفت.
```

### L05-094 — آرتین — en

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: متن تألیفی B؛ پس از گوش دادن باز کن
- فایل: `L05-094.weba`
- voice: `sage`
- slot: `data-audio-id="L05-094"`
- SHA256 متن UTF-8: `3720bb67760a6550761d6e783108985cbe64ab2269702e3b04214858df15bed0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
There were five movies in the cinemas this summer in our practice story. Laleh watched a science film in the cinema. She watched a comedy at home with her family.
```

### L05-137 — آرتین — fa

- بخش: شنیداری A و B؛ متن‌های تألیفی با هدف کتاب (`listening`)
- کادر: کلید متن تألیفی B
- فایل: `L05-137.weba`
- voice: `sage`
- slot: `data-audio-id="L05-137"`
- SHA256 متن UTF-8: `7e37e87e2e5bdeaf3055efb55a0fb7192e2a7d62b7586620ea6e2f2dccb52e66`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
five؛ یک فیلم علمی در سینما؛ کمدی در خانه.
```

### L05-095 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-095.weba`
- voice: `sage`
- slot: `data-audio-id="L05-095"`
- SHA256 متن UTF-8: `4e08396f9c3366a8a05d6bf86ac4c756e020651f5b8d50b9ba299406b3956078`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you connect to the Internet yesterday?
```

### L05-096 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-096.weba`
- voice: `sage`
- slot: `data-audio-id="L05-096"`
- SHA256 متن UTF-8: `27cc9d2be1537fafa397d0b6738073a403532b19074ff572302934739925432b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you call your grandmother last night?
```

### L05-097 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-097.weba`
- voice: `sage`
- slot: `data-audio-id="L05-097"`
- SHA256 متن UTF-8: `0faaa2ad22039a6cb9989a3fef8a744d30777c37793e4c7840db764efc0d20a2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What did your teacher do this morning?
```

### L05-098 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-098.weba`
- voice: `sage`
- slot: `data-audio-id="L05-098"`
- SHA256 متن UTF-8: `c4d32fff45f87235621f19e13d82c1c69b1cbdd5f7cc897749e52cbe511a5d78`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Where did you watch your favorite movie?
```

### L05-099 — آرتین — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-099.weba`
- voice: `sage`
- slot: `data-audio-id="L05-099"`
- SHA256 متن UTF-8: `52428dba81616780c3215cf9a74c681318f6f307fac26e0a672c736fdfbbc1d0`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Who used Information Technology in your class?
```

### L05-100 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-100.weba`
- voice: `coral`
- slot: `data-audio-id="L05-100"`
- SHA256 متن UTF-8: `7d87d34883fc8bdc45521597ee61972a7bee000dde202261499c2938433647df`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you watch the science program last night?
```

### L05-101 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-101.weba`
- voice: `echo`
- slot: `data-audio-id="L05-101"`
- SHA256 متن UTF-8: `8cf1954d9a787d0d3f5bbcfe819c858f41b9d09da5ed87f74c3d56f4ec896ce4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
No, I didn’t. I listened to a podcast.
```

### L05-102 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-102.weba`
- voice: `coral`
- slot: `data-audio-id="L05-102"`
- SHA256 متن UTF-8: `d9fa908f6fd3f037cd92810bf4d17bb0a0f00e10178abb3282d6e63d21c7e094`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
What was it about?
```

### L05-103 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-103.weba`
- voice: `echo`
- slot: `data-audio-id="L05-103"`
- SHA256 متن UTF-8: `097bf954cc0b1f1b58d18160de5ad9b43a60c30695c5b757b2af77dea5f9cc83`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
It was about the sea.
```

### L05-104 — رها — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-104.weba`
- voice: `coral`
- slot: `data-audio-id="L05-104"`
- SHA256 متن UTF-8: `b7c7ca0af4f7cddd1ed1bc213c99e478b530148dee17ad177aea1eed6f9408ea`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did you enjoy it?
```

### L05-105 — Nika — en

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: متن اصلی
- فایل: `L05-105.weba`
- voice: `echo`
- slot: `data-audio-id="L05-105"`
- SHA256 متن UTF-8: `45b9f298c49908381911c90e8151d4be05bfd5c138a1f457f6ebe8b7f1bcb273`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Yes, I did. I texted the title to my friend.
```

### L05-138 — آرتین — fa

- بخش: مصاحبهٔ کتاب و گفت‌وگوی تازه (`roleplay`)
- کادر: معیار اجرای مستقل در رسانه‌ها
- فایل: `L05-138.weba`
- voice: `sage`
- slot: `data-audio-id="L05-138"`
- SHA256 متن UTF-8: `f241cc2650b6e38b1c89a9d43dbb19a8a6ce744507424d560b77553c8e0ea6b4`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای رسانه، دو فعالیت دیروز و یک وضعیت گذشته را انتخاب کن. مصاحبه‌گر با did دربارهٔ کارها و با was یا were دربارهٔ وضعیت سؤال کند.
```

### L05-106 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-106.weba`
- voice: `sage`
- slot: `data-audio-id="L05-106"`
- SHA256 متن UTF-8: `b7f4fab07a6cdabb97917a143889f16dfbfa9afd710eb4faec1c7d1f68fa8cc5`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
بعد از did، watch پایه می‌آید.
```

### L05-107 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-107.weba`
- voice: `sage`
- slot: `data-audio-id="L05-107"`
- SHA256 متن UTF-8: `2a695d035bf2721d23e50052439394475c9f1f8cf380314a2ca5a2c942736b3b`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Did she watch it?
```

### L05-108 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-108.weba`
- voice: `sage`
- slot: `data-audio-id="L05-108"`
- SHA256 متن UTF-8: `970f66f9ece00243f20091f9fd992e9d903681c88eabe38b59a3d2a1f0abecd3`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
they با were هماهنگ است.
```

### L05-109 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-109.weba`
- voice: `sage`
- slot: `data-audio-id="L05-109"`
- SHA256 متن UTF-8: `67c95e1787fbe38f076ab9de365d720e46c1bf0929812589a56c928d8392a0a1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
They were busy.
```

### L05-110 — آرتین — fa

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-110.weba`
- voice: `sage`
- slot: `data-audio-id="L05-110"`
- SHA256 متن UTF-8: `509922e1d44fd23bcddeb9cc6b0350980f8b54eb785a99d8264206b12efc0441`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای be گذشته از خود was سؤال می‌سازیم.
```

### L05-111 — آرتین — en

- بخش: مثال‌های تازه و ترمیم خطا؛ سه سطح (`examples`)
- کادر: متن اصلی
- فایل: `L05-111.weba`
- voice: `sage`
- slot: `data-audio-id="L05-111"`
- SHA256 متن UTF-8: `a6c03ec30e9a0cd5ba3d04f1d5a166bf0cc7a43fdf6773129c25547d6cd9bfc8`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Was he happy?
```

### L05-112 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L05-112.weba`
- voice: `sage`
- slot: `data-audio-id="L05-112"`
- SHA256 متن UTF-8: `bc138a2b86c7b6d960e42c063a2cadbf1d67661844b591475fd3222ce1e1b32a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
look at the newsstand
```

### L05-113 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L05-113.weba`
- voice: `sage`
- slot: `data-audio-id="L05-113"`
- SHA256 متن UTF-8: `915a0f6fa5655896332733531c94fd609bbc6635d6928954e525ba3dadb723ec`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
watch a quiz show
```

### L05-114 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L05-114.weba`
- voice: `sage`
- slot: `data-audio-id="L05-114"`
- SHA256 متن UTF-8: `29324a90af976f8daa4d80c88b179895abec1f04e492e14c2e259c731f91e80a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
see a war movie
```

### L05-115 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L05-115.weba`
- voice: `sage`
- slot: `data-audio-id="L05-115"`
- SHA256 متن UTF-8: `23cafce0e297befb83d5c83caddf65c1f383fc6308683c3d86521f8e0a833e7c`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
change the TV channels
```

### L05-116 — آرتین — en

- بخش: واژگان تکمیلیِ فرهنگ تصویری کتاب (`dictionary`)
- کادر: متن اصلی
- فایل: `L05-116.weba`
- voice: `sage`
- slot: `data-audio-id="L05-116"`
- SHA256 متن UTF-8: `4bf101c4618edae4d1e45839965711191cfc52548e04fdba74f91eb6d4780306`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
install an antivirus program
```

### L05-117 — آرتین — fa

- بخش: سه تلفظ ed؛ قاعدهٔ دقیق و تمرین شنیدن (`ed-pronunciation`)
- کادر: متن اصلی
- فایل: `L05-117.weba`
- voice: `sage`
- slot: `data-audio-id="L05-117"`
- SHA256 متن UTF-8: `7989ef6a36c7b8a87bd3b364170ffa9182c36b5be8403454fadd9ac9122e23f1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
اگر آخرین صدای فعل پایه، ت یا د باشد، برای ed یک هجای اضافه مانند پایان wanted شنیده می‌شود. پس از دیگر صداهای واک‌دار، پایان د است؛ پس از دیگر همخوان‌های بی‌واک، پایان ت می‌آید. صدای آخر را ملاک بگیر، نه نامِ حرف آخر را.
```

### L05-118 — آرتین — en

- بخش: سه تلفظ ed؛ قاعدهٔ دقیق و تمرین شنیدن (`ed-pronunciation`)
- کادر: متن اصلی
- فایل: `L05-118.weba`
- voice: `sage`
- slot: `data-audio-id="L05-118"`
- SHA256 متن UTF-8: `3e3f75f9793979d2deb080ee3d5bb5370c3d0405be2b62dbeb0cf2291b1c93bb`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
Wanted. Needed. Played. Enjoyed. Worked. Watched.
```

### L05-139 — آرتین — en

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L05-139.weba`
- voice: `sage`
- slot: `data-audio-id="L05-139"`
- SHA256 متن UTF-8: `f1b5cd904afe300a8d620b26c83fea2a7cdd27641b7dd70da31bd943bab5d6c1`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Clear General American English. Keep contractions natural. Follow the lesson context for intonation.

```text
I watched a documentary yesterday. I received an e-mail. My sister updated her blog. We didn’t use the computer at night. We were happy with our project.
```

### L05-140 — آرتین — fa

- بخش: تمرین ساختنی و نوشتن مستقل (`practice`)
- کادر: نمونهٔ تألیفی برای مقایسه، نه رونویسی
- فایل: `L05-140.weba`
- voice: `sage`
- slot: `data-audio-id="L05-140"`
- SHA256 متن UTF-8: `7819077f0ab88871d53d0f1a8cb61ec4e11c893bcef596b8287e9c8f99ad6fa2`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
در گزارش رسانه، فعل خبریِ گذشته و فعل پایه پس از did را جدا کنترل کن. اگر وضعیت را وصف می‌کنی، هماهنگی was و were با فاعل مهم است.
```

### L05-119 — آرتین — fa

- بخش: جمع‌بندی و مرور فاصله‌دارِ رسانه‌ها (`summary`)
- کادر: متن اصلی
- فایل: `L05-119.weba`
- voice: `sage`
- slot: `data-audio-id="L05-119"`
- SHA256 متن UTF-8: `b8e03e241caa204c3e64c053adf348274d12c0b41618bd357549e78963498d9a`
- اجرا: Speak only the exact input; never announce IDs, labels or symbols. Fluent Iranian Persian, moderate teaching pace; pronounce embedded English accurately.

```text
برای جمع‌بندیِ رسانه‌ها، به‌جای بازخوانی کل صفحه، سه جمله از حافظه بساز: یک خبر، یک منفی و یک پرسش. روز بعد یکی از اطلاعات را عوض کن؛ سه روز بعد گفت‌وگوی تازه اجرا کن و هفتهٔ بعد آزمون را با نمونهٔ شخصی تکمیل کن.
```

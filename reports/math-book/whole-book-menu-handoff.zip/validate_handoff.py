"""Read-only validation of the unpacked handoff; no application changes."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'handoff-manifest.json').read_text())
for name,expected in manifest['files'].items():
    p=root/name
    assert p.is_file(), 'Missing handoff file: '+name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected, 'Changed handoff file: '+name
routes=json.loads((root/'math-practice-routes.whole-book.json').read_text())['routes']
assert len(routes)==28 and all(r['packId']=='C905_E00-SUM' for r in routes)
for route in routes:
    p=root/'assets'/route['assetPath']
    assert p.is_file()
    assert (p.parent/'assets/css/theme'/(p.stem+'.theme.css')).is_file()
subprocess.run([sys.executable,str(root/'teaching - template/tools/verify_locked.py')],check=True)
print('OK: portable whole-book handoff; 28 HTML, 28 themes, menu and bridge inputs intact.')

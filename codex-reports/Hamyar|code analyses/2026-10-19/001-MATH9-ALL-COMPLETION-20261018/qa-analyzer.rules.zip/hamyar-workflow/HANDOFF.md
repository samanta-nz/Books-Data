# قرارداد بسته، پذیرش و نتیجهٔ ارجاعی
نسخه: 2026-10-18.contracts-2
قواعد مشترک WORKFLOW_RULES.md و مسیرهای routes.json بر همهٔ بسته‌ها اعمال می‌شوند.

## درخواست و پاسخ‌های متناظر
| درخواست | گیرنده | پاسخ نهایی | برگشت |
|---|---|---|---|
| WORK_ORDER | نقش تعیین‌شده | WORK_RESULT | دقیقاً سفارش‌دهندهٔ مدیر/کاربر |
| SOURCE_REQUEST | Local Processor | SOURCE_BUNDLE | درخواست‌کنندهٔ همان منبع |
| AUDIO_REQUEST | Audio Production | AUDIO_BUNDLE | مؤلف/Exam درخواست‌کنندهٔ همان روایت |
| QA_REQUEST | QA | QA_REPORT | درخواست‌کنندهٔ همان آزمون |
| SYNC_REQUEST | Sync | SYNC_RECEIPT | درخواست‌کنندهٔ همان بستهٔ محتوا |
| CODE_REQUEST | App Development | CODE_DELIVERY | درخواست‌کنندهٔ همان اصلاح |
| RELEASE_REQUEST | Release | RELEASE_RECEIPT | مدیر/کاربر درخواست‌کنندهٔ همان انتشار |

INPUT_ACK فقط تصمیم پذیرش ورودی است؛ هیچ‌یک از پاسخ‌های نهایی بالا نیست.
RETURN_REPORT برای رد، ابهام، مسدودی یا ارجاع صاحبِ ایراد با expected/actual است.
STATUS_EVENT فقط وضعیت برای مدیر است و نباید چرخهٔ ACK یا کار تازه ایجاد کند.
برای سفارش مستقیم کاربر، پاسخ و ACK در همان چت داده شود؛ پیام فرستاده‌شده از مدیر جعل نشود.
اگر یک WORK_ORDER کلان چند زیرکار دارد، هر زیرکار handoff جدا دارد و WORK_RESULT کلان به نتایج همان زیرکارها ارجاع می‌دهد.
BOOTSTRAP_ACK.schema.json فقط payload نتیجهٔ راه‌اندازی رشته‌های تدریس در WORK_RESULT را توصیف می‌کند؛ نام تاریخی فایل به معنی INPUT_ACK یا رسید ارسال نیست. RULES_READY صرفاً خواندن و تطبیق قواعد را نشان می‌دهد؛ وضعیت ابزار انتقال و blockers جدا گزارش می‌شوند.

## اجزای packet
- handoff_id، revision، task_id، packet_type، in_reply_to.
- from و to و reply_to: role_id، thread_id، host_id؛ نقش user فقط برای منشأ/پاسخ کاربر واقعی.
- scope: رشته، پایه، کتاب، فصل/درس و accepted_scope/blocked_scope در نتیجهٔ جزئی.
- expected_action و origin_instruction_ref: اقدام دقیق و ارجاع به اختیار معتبر؛ مجوز قدیمیِ معتبر حفظ می‌شود.
- acceptance_criteria: شناسه/شرح هر معیار؛ معیار ساختگی برای PASS آسان اضافه نشود.
- rules: نسخه/hash فایل پایه و پروفایل در تدریس؛ قرارداد گردش و TEMPLATE_POLICY برای ورودی HTML.
- repositories: URL، branch، source_commit، target_commit و نقش runtime/report در صورت نیاز.
- artifacts: نوع، owner_role، path یا URL قابل دریافت، bytes، SHA-256 و وابستگی‌های واقعی.
- mapping: source → منو/شناسه → bucketKey → assetPath؛ N/A فقط با دلیل.
- dependencies: REQUIRED/OPTIONAL/N/A، وضعیت، owner و evidence؛ audio script و audio file نوع جدا دارند.
- validation: نوع QA، artifact/manifest hash، source commit، verdict و evidence هر معیار.
- payload: دادهٔ مخصوص نوع بسته؛ فایل/دامنه/expected_action نباید فقط در یک متن مبهم پنهان باشد.

## تمامیت و وضعیت
packet_sha256 از JSON قطعیِ خود packet محاسبه شود: UTF-8، ensure_ascii=False، sort_keys=True، separators=(',', ':')، allow_nan=False.
رشته‌ها یا حروف عربی/فارسی برای این کار normalize نشوند؛ مقدار علمی یا URL تغییر نکند.
state و رسیدهای انتقال بیرون packet نگهداری شوند تا تغییر مرحله، محتوای بستهٔ پذیرفته‌شده را عوض نکند.
شاخص جلوگیری از اجرای تکراری: handoff_id + revision + packet_sha256.

state شامل سه وضعیت مستقل transport، input_decision و work_status است؛ publication نیز جدا ثبت می‌شود.
هیچ artifact آینده‌ای با hash/URL جعلی به این قرارداد اضافه نشود. مثال/پیش‌نویس ناقص باید DRAFT/BLOCKED بماند.

## رسید ورودی
INPUT_ACK باید in_reply_to، revision و hash بستهٔ دریافتی را ارجاع دهد و شامل این موارد باشد:
decision، accepted_scope، blocked_scope، checks performed، reason_codes، owner رفع و next_action.
بدون بازیابی ورودی و تطبیق دامنه/نوع/نسخه، ACCEPTED صادر نشود.
ACK به ACK، ACK برای STATUS_EVENT یا اجرای خودکار ناشی از گزارش صرف ممنوع است.

## نتیجه و برگشت ایراد
نتیجه به همان requester پاسخ دهد؛ به «بخش پردازش محتوا»ی نامعلوم نرود.
RETURN_REPORT باید مسئله، artifact/finding ID، expected/actual، evidence، محدودهٔ متأثر، owner_role/thread/host و اقدام بعدی را مشخص کند.
برای ایراد علمی، owner همان تولیدکنندهٔ رشته/Exam است؛ برای فایل/برش Local؛ برای encode/باکت Sync؛ برای منو/Kotlin/bridge توسعه؛ برای ارزیابی QA؛ برای انتشار Release.
اگر owner معلوم نیست، مدیر صاحب تعیین می‌کند؛ تا آن زمان مقصد فرضی و SENT ثبت نشود.

## قرارداد اختصاصی صوت
AUDIO_REQUEST و AUDIO_BUNDLE باید generation_platform=arena.ai و hash روایت/HTML تأییدشده داشته باشند. AUDIO_BUNDLE افزون بر فایل واقعی، مدت/hash/نگاشت و QC، origin_evidence واقعیِ دریافت از Arena را ثبت می‌کند؛ مدل/شناسهٔ تولید فقط اگر واقعاً معلوم باشد. نبود دسترسی خودکار به Arena باعث آماده‌سازی بستهٔ ورودی و انتظار برای فایل واقعی برگشتی می‌شود؛ موتور دیگر یا موفقیت فرضی جایگزین نیست. جزئیات و مسیر برگشت در AUDIO_POLICY.md آمده است.

## کدهای علت
MISSING_FIELD، WRONG_ROLE، WRONG_PACKET_TYPE، MISSING_RULES، RULES_VERSION_CONFLICT،
SOURCE_UNAVAILABLE، WRONG_BASE_COMMIT، INTEGRITY_MISMATCH، BROKEN_MAPPING،
BLOCKED_DEPENDENCY، STALE_QA، TEMPLATE_MISMATCH، INSUFFICIENT_AUTH_SCOPE،
NO_DESTINATION، NO_TRANSPORT، PLATFORM_MISMATCH، SOURCE_UNVERIFIED.
جزئیات فنی و شاهد کنار کد ثبت شود؛ کد عمومی به‌تنهایی گزارش کافی نیست.

## شرط بستن کار
پاسخ نهایی با in_reply_to و artifactهای واقعی داده شده، requester نتیجه را تطبیق داده،
موارد REQUIRED انجام شده یا با تصمیم معتبر دامنه‌شان تغییر کرده و owner موارد باز روشن باشد.
گزارش QA و انتشار فقط برای همان بایت‌ها/commit معتبرند. GitHub، باکت و APK رسید جدا می‌خواهند.


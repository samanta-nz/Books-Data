# فایل‌های آمادهٔ ریاضی نهم با ساختار جدید باکت

این پوشه طبق درخواست مستقیم کاربر، فقط فایل‌های مرور/آزمونِ قبلاً ساخته‌شده را با قرارداد نام‌گذاری `bucket-sync-g09-39.09.03.zip` نگه می‌دارد: **۲۵۲ HTML با Theme امبد؛ بدون CSS جانبی**؛ شامل **۲۱۶ آزمون مستقل** برای هشت فصل و کل کتاب.

ریشهٔ فایل‌ها در این ریپو: `grades/g09/Bucket/Content/G09/g9-math/`.
کلید متناظر باکت: `Bucket/Content/G09/g9-math/`؛ یعنی فقط پیشوند `grades/g09/` حذف شود. بزرگی/کوچکی `Bucket`، `Content`، `G09`، `F01` تا `F08`، `ALL` و `Hits` دقیق است.

| کاربرد | نمونهٔ فصل اول | نمونهٔ کل کتاب |
|---|---|---|
| فلش‌کارت | [ryazif01-cards.html](Content/G09/g9-math/F01/ryazif01-cards.html) | [ryazi-all-cards.html](Content/G09/g9-math/ALL/ryazi-all-cards.html) |
| خلاصه و نکات | [ryazif01-Hits.html](Content/G09/g9-math/F01/ryazif01-Hits.html) | [ryazi-all-Hits.html](Content/G09/g9-math/ALL/ryazi-all-Hits.html) |
| نمونه‌سؤالات | [ryazif01-Q.html](Content/G09/g9-math/F01/ryazif01-Q.html) | [ryazi-all-Q.html](Content/G09/g9-math/ALL/ryazi-all-Q.html) |
| انتخاب خودآزمایی | [ryazif01-selftest.html](Content/G09/g9-math/F01/ryazif01-selftest.html) | [ryazi-all-selftest.html](Content/G09/g9-math/ALL/ryazi-all-selftest.html) |
| آزمون مستقل | [selftest/ryazif01-selftest-easy-01.html](Content/G09/g9-math/F01/selftest/ryazif01-selftest-easy-01.html) | [selftest/ryazi-all-selftest-easy-01.html](Content/G09/g9-math/ALL/selftest/ryazi-all-selftest-easy-01.html) |

هر فصل و ALL چهار سطح `easy/medium/hard/brilliant` با شش نسخهٔ `01..06` دارد. Theme و تمام اسکریپت‌های اجرایی داخل خود HTML امبد هستند؛ ۲۵۲ فایل CSS جداگانه پس از تطبیق بایت‌ها حذف شدند. برای حفظ فایل‌های مستقلِ سفارش قبلی، مسیر `selftest/` به قرارداد فایل‌های اصلی ZIP افزوده شده است؛ ۲۴ برگه در ریشهٔ ALL انباشته نشده‌اند.

[manifest کامل نگاشت قدیم/جدید، شناسه‌ها، اندازه و SHA-256](math9-layout-manifest.json).

فقط ارجاع نام Theme و لینک‌های نسبی انتخاب آزمون تغییر کرده‌اند؛ دادهٔ علمی، سؤال‌ها، پاسخ‌ها، scriptها، شناسهٔ document/pack/question و contentVersion حفظ شده‌اند. فایل تدریس درس‌ها، PDF یا یک آزمون EX جداگانه که در این بانک موجود نبوده، با جای‌نگهدار یا نسخهٔ تکراری ساخته نشده است؛ مقصدهای خارج از این تحویل در manifest مشخص‌اند. بخش‌های صوتی دستور ZIP به‌عنوان سفارش جدید اجرا نشده‌اند؛ این تحویل مربوط به فایل‌های موجود مرور و آزمون است.

HTMLها نسخهٔ خوانای موجود هستند. `HtmlCodec` همین مبنای اپ، HTML ساده را پشتیبانی می‌کند؛ این کار دستور مستقلی برای رمزگذاری، دریافت کلید یا بارگذاری پارس‌پک نبوده است. هیچ کلید یا دادهٔ کاربر به این پوشه اضافه نشده است.

کنترل مرورگر روی همهٔ ۲۵۲ مسیر جدید و لینک‌ها، ذخیره با bridge ساختگی، پنهان‌بودن نتیجه تا پایان و فرم/بارم برگه‌ها موفق است؛ اجرای واقعی اپ نصب‌شده انجام نشده است. ۳۶ مقصد اصلی با grade-server-map فعلی منطبق‌اند؛ ۲۱۶ مسیر برگه از لینک‌های HTML قابل دسترسی‌اند و در map صریح فعلی entry جدا ندارند. مصرف‌کنندهٔ RemoteHtmlPage و نگاشت شناسه/ذخیرهٔ native باید پیش از فعال‌سازی واقعی توسط توسعه/QA بررسی شوند؛ افزودن فایل به این ریپو به معنی تأیید ثبت نتیجه در نسخهٔ نصب‌شده نیست.

[گزارش تاریخ‌دار و دستور هماهنگی ادامه](https://github.com/samanta-nz/Books-Data/tree/main/codex-reports/Exam-Content-Builder/2026-10-23/002-MATH9-STANDALONE).

این تغییر فقط فایل‌های همین پوشهٔ GitHub را اضافه می‌کند؛ سورس native، منوهای اپ، نسخهٔ انتشار و ZIP مرجع را تغییر نمی‌دهد. آپلود به object storage واقعی، فعال‌سازی remoteMenu و انتشار APK انجام نشده‌اند.

[راهنمای کامل اپ، مدل ذخیره و متن اسکریپت‌ها](G9-Math-APP-INTEGRATION.md). پنجرهٔ منوی شناور در تمام viewport محتوای WebView باز می‌شود. [ZIP مستقل](https://github.com/samanta-nz/com.hamyareman.final/raw/refs/heads/migration/modular-grades/grades/g09/Bucket/G9-Math.zip) همین HTMLها و راهنما را با ساختار Bucket در خود دارد.
